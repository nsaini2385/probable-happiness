param([string]$Prefix = 'WL11-', [string]$Domain = 'melb.ad')
$ErrorActionPreference = 'Stop'
$WorkDir = 'C:\ProgramData\Rename'
$ResultFile = Join-Path $WorkDir 'result.json'
function PLog($m){ try { "$(Get-Date -Format s) [popup] $m" | Add-Content (Join-Path $WorkDir 'Rename.log') } catch {} }
trap { PLog "ERROR: $($_.Exception.Message) | line $($_.InvocationInfo.ScriptLineNumber)"; exit 1 }
PLog "Popup started. User=$env:USERNAME Session=$([System.Diagnostics.Process]::GetCurrentProcess().SessionId)"
try { $cfg = Get-Content (Join-Path $WorkDir 'config.json') -Raw | ConvertFrom-Json; if ($cfg.Prefix) { $Prefix = $cfg.Prefix }; if ($cfg.Domain) { $Domain = $cfg.Domain } } catch {}
if ([Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') {
    PLog 'Not STA, relaunching in STA'
    & "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -STA -ExecutionPolicy Bypass -File $PSCommandPath
    exit $LASTEXITCODE
}

Add-Type -AssemblyName System.Windows.Forms, System.Drawing, System.Security, System.DirectoryServices.AccountManagement
[System.Windows.Forms.Application]::EnableVisualStyles()

# ShiftF10.exe (AutoHotkey) opens the OOBE command prompt so our window can take the foreground (as in OOBEPrompt).
# Never wait on it for more than 15s.
try {
    $sf = Start-Process (Join-Path $WorkDir 'ShiftF10.exe') -PassThru
    if (-not $sf.WaitForExit(15000)) { $sf.Kill() }
} catch { PLog "ShiftF10 failed: $($_.Exception.Message)" }

$MaxLen = 15 - $Prefix.Length   # NetBIOS limit

# ---- Pre-fill: 1) Dell BIOS asset tag, 2) serial number, 3) empty ----
. (Join-Path $WorkDir 'Dell-Asset.ps1')
$junk = 'To Be Filled By O.E.M.','Default string','System Serial Number','None','N/A','Not Specified','Not Applicable','Unknown','No Asset Tag','No Asset Information','0'
function Clean-Name($v) {
    if ($junk -contains $v) { return '' }
    $v = ($v -replace '[^A-Za-z0-9\-]','').ToUpper().Trim('-')
    if ($v -match '^0*$') { return '' }
    return $v
}
$script:serial = ''; $source = ''

$detected = ''
try { $detected = (Get-DellAssetTag) } catch {}
$cand = Clean-Name $detected
if ($cand.StartsWith($Prefix.ToUpper())) { $cand = Clean-Name $cand.Substring($Prefix.Length) }   # tag holds the full name: strip our prefix
if ($cand.Length -gt $MaxLen) { $cand = $cand.Substring($cand.Length - $MaxLen) }
if ($cand) { $script:serial = $cand; $source = 'BIOS asset tag' }

if (-not $script:serial) {
    $sn = ''
    try { $sn = ((Get-CimInstance Win32_BIOS).SerialNumber | Out-String).Trim() } catch {}
    if (-not $sn) { try { $sn = ((Get-CimInstance Win32_SystemEnclosure).SerialNumber | Out-String).Trim() } catch {} }
    $cand = Clean-Name $sn
    if ($cand.Length -gt $MaxLen) { $cand = $cand.Substring($cand.Length - $MaxLen) }
    if ($cand) { $script:serial = $cand; $source = 'serial number' }
}
PLog "BIOS asset tag '$detected' -> prefill '$($script:serial)' (source: $source)"

$blue = [System.Drawing.Color]::FromArgb(15,76,129)
$grey = [System.Drawing.Color]::FromArgb(85,85,85)
function New-Ctl($type, $x, $y, $w, $h, $text) {
    $c = New-Object $type; $c.Location = New-Object System.Drawing.Point($x,$y); $c.Size = New-Object System.Drawing.Size($w,$h)
    if ($null -ne $text) { $c.Text = $text }; $c
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Device Information'; $form.ClientSize = New-Object System.Drawing.Size(520,560)
$form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'; $form.ControlBox = $false
$form.MinimizeBox = $false; $form.MaximizeBox = $false; $form.TopMost = $true; $form.ShowInTaskbar = $false
$form.Font = New-Object System.Drawing.Font('Segoe UI',10); $form.BackColor = [System.Drawing.Color]::White

$hdr = New-Ctl System.Windows.Forms.Label 0 0 520 50 '  Device Information'
$hdr.BackColor = $blue; $hdr.ForeColor = [System.Drawing.Color]::White; $hdr.TextAlign = 'MiddleLeft'
$hdr.Font = New-Object System.Drawing.Font('Segoe UI',16,[System.Drawing.FontStyle]::Bold)

$h1 = New-Ctl System.Windows.Forms.Label 24 66 470 24 'Computer Name'
$h1.ForeColor = $blue; $h1.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold)
$lblPrefix = New-Ctl System.Windows.Forms.Label 24 98 70 28 $Prefix; $lblPrefix.TextAlign = 'MiddleLeft'; $lblPrefix.Font = New-Object System.Drawing.Font('Segoe UI',12)
$txtTag = New-Ctl System.Windows.Forms.TextBox 96 98 250 28 ''; $txtTag.MaxLength = $MaxLen; $txtTag.CharacterCasing = 'Upper'; $txtTag.Font = New-Object System.Drawing.Font('Segoe UI',12)
$note = New-Ctl System.Windows.Forms.Label 24 134 470 22 'Pre-filled. Tick the box to change it.'; $note.ForeColor = $grey
$chk = New-Ctl System.Windows.Forms.CheckBox 24 160 470 24 'Override detected value'
if ($source) { $note.Text = "Pre-filled from the $source. Tick the box to change it." } else { $note.Text = 'No asset tag or serial number found. Enter the name.' }
$lblPreview = New-Ctl System.Windows.Forms.Label 24 190 470 22 ''; $lblPreview.ForeColor = $blue

$h2 = New-Ctl System.Windows.Forms.Label 24 226 470 24 'Domain Credentials'
$h2.ForeColor = $blue; $h2.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold)
$lblDom = New-Ctl System.Windows.Forms.Label 24 252 470 22 "Domain: $Domain"; $lblDom.ForeColor = $grey
$l3 = New-Ctl System.Windows.Forms.Label 24 282 470 20 'Username'
$txtUser = New-Ctl System.Windows.Forms.TextBox 24 304 470 28 ''
$l4 = New-Ctl System.Windows.Forms.Label 24 340 470 20 'Password'
$txtPass = New-Ctl System.Windows.Forms.TextBox 24 362 470 28 ''; $txtPass.UseSystemPasswordChar = $true

$lblErr = New-Ctl System.Windows.Forms.Label 24 400 470 56 ''; $lblErr.ForeColor = [System.Drawing.Color]::FromArgb(176,0,32)
$btn = New-Ctl System.Windows.Forms.Button 344 480 150 36 'Finish'; $btn.Enabled = $false

$form.Controls.AddRange(@($hdr,$h1,$lblPrefix,$txtTag,$note,$chk,$lblPreview,$h2,$lblDom,$l3,$txtUser,$l4,$txtPass,$lblErr,$btn))
$form.AcceptButton = $btn
$script:allowClose = $false
$script:skipCheck = $false

function Update-State {
    $t = $txtTag.Text
    $nameOk = ($t -match "^[A-Za-z0-9\-]{1,$MaxLen}$") -and -not $t.EndsWith('-')
    $credOk = ($txtUser.Text.Trim().Length -gt 0) -and ($txtPass.Text.Length -gt 0)
    $btn.Enabled = ($nameOk -and $credOk)
    $lblPreview.Text = if ($nameOk) { "Computer name will be: $Prefix$t" } else { '' }
    if ($t -and -not $nameOk) { $lblErr.Text = "Letters, numbers and hyphens only, maximum $MaxLen characters." }
    elseif ($lblErr.Text -like 'Letters*') { $lblErr.Text = '' }
}

if ($script:serial) { $txtTag.Text = $script:serial; $txtTag.ReadOnly = $true; $chk.Checked = $false }
else { $chk.Checked = $true; $chk.Enabled = $false; $txtTag.ReadOnly = $false }   # nothing detected: empty, must type
$chk.Add_CheckedChanged({
    if ($chk.Checked) { $txtTag.ReadOnly = $false; $txtTag.Focus() | Out-Null }
    elseif ($script:serial) { $txtTag.Text = $script:serial; $txtTag.ReadOnly = $true }
})
$txtTag.Add_TextChanged({ Update-State })
$txtUser.Add_TextChanged({ $script:skipCheck = $false; $btn.Text = 'Finish'; Update-State })
$txtPass.Add_TextChanged({ $script:skipCheck = $false; $btn.Text = 'Finish'; Update-State })

$btn.Add_Click({
    $lblErr.Text = ''; $btn.Enabled = $false; $form.Refresh()
    $user = $txtUser.Text.Trim()
    $upn  = if ($user -match '[\\@]') { $user } else { "$user@$Domain" }

    if (-not $script:skipCheck) {
        $btn.Text = 'Checking...'; $form.Refresh()
        $valid = $false; $badCreds = $false; $why = ''
        # Method 1: AccountManagement
        try {
            $sam = if ($user -match '\\') { $user.Split('\')[-1] } else { $user }
            $ctx = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('Domain', $Domain)
            $valid = $ctx.ValidateCredentials($sam, $txtPass.Text)
            if (-not $valid) { $badCreds = $true }
        } catch {
            $why = "$($_.Exception.GetType().Name): $($_.Exception.Message)"
            PLog "ValidateCredentials error: $why"
            # Method 2: plain LDAP bind
            try {
                $de = New-Object System.DirectoryServices.DirectoryEntry("LDAP://$Domain", $upn, $txtPass.Text)
                $null = $de.NativeObject
                $valid = $true
            } catch {
                $m = $_.Exception.Message
                PLog "LDAP bind error: $m"
                if ($m -match 'user name or password|logon failure|credentials') { $badCreds = $true } else { $why = $m }
            }
        }
        if (-not $valid) {
            if ($badCreds) {
                $lblErr.Text = 'Invalid domain username or password.'
                $btn.Text = 'Finish'; Update-State; return
            }
            # Domain not reachable: log diagnostics, let the user continue (the rename will try again with these credentials)
            try { PLog ('nltest /dsgetdc: ' + ((& nltest.exe "/dsgetdc:$Domain" 2>&1 | Out-String) -replace '\s+',' ')) } catch { PLog "nltest failed: $($_.Exception.Message)" }
            try { PLog ('DNS ' + $Domain + ' -> ' + ((Resolve-DnsName $Domain -ErrorAction Stop | Where-Object IPAddress | Select-Object -ExpandProperty IPAddress) -join ',')) } catch { PLog "DNS lookup failed: $($_.Exception.Message)" }
            $script:skipCheck = $true
            $lblErr.Text = "Cannot reach domain $Domain to check the credentials (network/DNS). Click 'Continue anyway' to use them without the check."
            $btn.Text = 'Continue anyway'; $btn.Enabled = $true; return
        }
    } else { PLog 'Credential check skipped by user (domain unreachable)' }

    # Machine-scope DPAPI: Launch.ps1 (SYSTEM, same machine) decrypts it. Never stored in clear text.
    $enc = [Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($txtPass.Text), $null, 'LocalMachine')
    $obj = [pscustomobject]@{ Name = "$Prefix$($txtTag.Text)"; AssetTag = $detected; Override = $chk.Checked; User = $user; Pw = [Convert]::ToBase64String($enc) }
    $obj | ConvertTo-Json | Set-Content -Path $ResultFile -Encoding UTF8
    $script:allowClose = $true; $form.Close()
})
$form.Add_FormClosing({ if (-not $script:allowClose) { $_.Cancel = $true } })
$form.Add_Shown({ $form.Activate(); $form.BringToFront(); Update-State })
[void]$form.ShowDialog()
PLog 'Popup closed normally'
