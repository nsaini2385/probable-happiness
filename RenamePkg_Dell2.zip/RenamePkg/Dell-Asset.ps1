# Dell-Asset.ps1 - read/write the Dell BIOS asset tag. Dot-sourced by Launch.ps1 and Show-DeviceInfo.ps1.
# Write order: Dell Command | Configure (cctk.exe), then the Dell Command | PowerShell Provider (DellBIOSProvider module).

function Find-Cctk {
    $paths = @(
        "$env:ProgramFiles\Dell\Command Configure\X86_64\cctk.exe",
        "${env:ProgramFiles(x86)}\Dell\Command Configure\X86_64\cctk.exe",
        "${env:ProgramFiles(x86)}\Dell\Command Configure\X86\cctk.exe"
    )
    foreach ($p in $paths) { if ($p -and (Test-Path $p)) { return $p } }
    $g = Get-Command cctk.exe -ErrorAction SilentlyContinue
    if ($g) { return $g.Source }
    return $null
}

function Get-DellAssetTag {
    # Default: SMBIOS via WMI (fast, no Dell tool needed; only refreshes after a reboot).
    # -Live: ask the BIOS through the Dell tool, so a value just written is visible straight away.
    param([switch]$Live)
    if (-not $Live) {
        $tag = ''
        try { $tag = ((Get-CimInstance Win32_SystemEnclosure).SMBIOSAssetTag | Out-String).Trim() } catch {}
        if ($tag) { return $tag }
    }
    $cctk = Find-Cctk
    if ($cctk) {
        try {
            $o = & $cctk --asset 2>&1 | Out-String
            if ($o -match '(?im)^\s*Asset\s*=\s*(.*?)\s*$') { return $Matches[1].Trim() }
        } catch {}
    }
    if (Get-Module -ListAvailable -Name DellBIOSProvider) {
        try {
            Import-Module DellBIOSProvider -ErrorAction Stop
            return ((Get-Item 'DellSmbios:\SystemInformation\AssetTag' -ErrorAction Stop).CurrentValue | Out-String).Trim()
        } catch {}
    }
    if ($Live) { try { return ((Get-CimInstance Win32_SystemEnclosure).SMBIOSAssetTag | Out-String).Trim() } catch {} }
    return ''
}

function Set-DellAssetTag {
    param([Parameter(Mandatory)][string]$Value, [string]$BiosPassword = '')
    $mfr = ''
    try { $mfr = (Get-CimInstance Win32_ComputerSystem).Manufacturer } catch {}
    if ($mfr -notmatch 'Dell') { return [pscustomobject]@{ Ok = $false; Msg = "Not a Dell device ($mfr), skipped" } }
    if ($Value.Length -gt 64) { return [pscustomobject]@{ Ok = $false; Msg = 'Value longer than the 64 character BIOS limit' } }

    $cctk = Find-Cctk
    if ($cctk) {
        $a = @("--asset=$Value"); if ($BiosPassword) { $a += "--valsetuppwd=$BiosPassword" }
        $out  = & $cctk @a 2>&1 | Out-String
        $code = $LASTEXITCODE
        $msg  = "cctk exit $code : $(($out -replace '\s+',' ').Trim())"
        if ($BiosPassword) { $msg = $msg.Replace($BiosPassword, '***') }
        return [pscustomobject]@{ Ok = ($code -eq 0); Msg = $msg }
    }
    if (Get-Module -ListAvailable -Name DellBIOSProvider) {
        try {
            Import-Module DellBIOSProvider -ErrorAction Stop
            $p = @{ Path = 'DellSmbios:\SystemInformation\AssetTag'; Value = $Value; ErrorAction = 'Stop' }
            if ($BiosPassword) { $p.Password = $BiosPassword }
            Set-Item @p
            return [pscustomobject]@{ Ok = $true; Msg = 'Written with DellBIOSProvider' }
        } catch { return [pscustomobject]@{ Ok = $false; Msg = "DellBIOSProvider error: $($_.Exception.Message)" } }
    }
    return [pscustomobject]@{ Ok = $false; Msg = 'No Dell tool found (cctk.exe or DellBIOSProvider). Install Dell Command | Configure before this app.' }
}
