RENAME POPUP v2 - Intune Win32 app (ServiceUI session method + ShiftF10, based on Michael Niehaus' OOBEPrompt)

ServiceUI.exe and ShiftF10.exe are already in this folder.
1. Package:  IntuneWinAppUtil.exe -c . -s Launch.ps1 -o ..\out
2. Intune app settings
   Install:    %SystemRoot%\sysnative\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File Launch.ps1
   Uninstall:  Uninstall.cmd
   Install behaviour: System
   Return codes: 0 success, 3010 soft reboot, 1 failed
   Detection:  custom script Detection.ps1 (run as 64-bit: Yes, signature check: No)
3. Assign as REQUIRED to the Autopilot device group and add it to the ESP profile "Block device use until these required apps are installed".
4. The popup pre-fills the BIOS serial number, asks for domain credentials (validated against melb.ad) and renames with
   Rename-Computer -DomainCredential. Password is only kept machine-DPAPI encrypted in result.json, deleted right after use.
Logs: C:\ProgramData\Rename\Rename.log (also IME logs in C:\ProgramData\Microsoft\IntuneManagementExtension\Logs)
Local test (as admin, on a desktop): psexec -s -i 1 powershell -STA -File C:\ProgramData\Rename\Show-DeviceInfo.ps1

DELL ASSET TAG (v4)
- Popup pre-fills from the Dell BIOS asset tag (strips the WL11- prefix if present); if empty, from the serial number; if neither, empty.
- After the rename, the full computer name is written to the BIOS asset tag (cctk.exe --asset=<name>, or DellBIOSProvider as fallback).
- install.bat (.NET 10 runtime + DCECMI.msi) runs once from Launch.ps1. Put dotnet-runtime-10.0.14-win-x64.exe and DCECMI.msi in this folder.
- If the BIOS has a setup password, set $BiosPassword at the top of Launch.ps1.
- WMI shows the new tag only after a reboot; the log verifies it live through the Dell tool.
