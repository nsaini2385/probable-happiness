@echo off
setlocal
echo ============================================================
echo  Dell prerequisites: .NET Runtime 10 + Dell Command Endpoint Configure
echo  %DATE% %TIME%
echo ============================================================

echo [1/2] Installing .NET Runtime 10...
"%~dp0dotnet-runtime-10.0.14-win-x64.exe" /install /quiet /norestart
set RC=%ERRORLEVEL%
if %RC% EQU 0 ( echo [1/2] .NET Runtime installed. ) else if %RC% EQU 1638 ( echo [1/2] .NET Runtime already installed. ) else if %RC% EQU 3010 ( echo [1/2] .NET Runtime installed, reboot pending. ) else ( echo [1/2] ERROR: .NET Runtime exit code %RC% & exit /b 1 )

echo [2/2] Installing Dell Command Endpoint Configure...
msiexec /i "%~dp0DCECMI.msi" /qn /norestart /log "%ProgramData%\Rename\DCECMI_Install.log"
set RC=%ERRORLEVEL%
if %RC% EQU 0 ( echo [2/2] DCECMI installed. ) else if %RC% EQU 1638 ( echo [2/2] DCECMI already installed. ) else if %RC% EQU 3010 ( echo [2/2] DCECMI installed, reboot pending. ) else ( echo [2/2] ERROR: DCECMI exit code %RC% - see %ProgramData%\Rename\DCECMI_Install.log & exit /b 1 )

echo Done.
exit /b 0
