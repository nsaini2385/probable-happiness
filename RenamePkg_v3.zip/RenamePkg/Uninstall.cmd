reg delete "HKLM\SOFTWARE\Rename" /f
exit /b 0
