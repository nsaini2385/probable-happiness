$v = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Rename' -Name Done -ErrorAction SilentlyContinue
if ($v -and $v.Done -eq 1) { Write-Output 'Detected'; exit 0 } else { exit 1 }
