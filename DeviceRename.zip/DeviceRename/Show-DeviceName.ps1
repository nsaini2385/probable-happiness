# Runs in the logged-on USER session (scheduled task, AtLogOn, Users group). No admin needed.
$Base    = 'C:\ProgramData\DeviceRename'
$Drop    = Join-Path $Base 'Drop'
$Request = Join-Path $Drop 'request.json'
$Done    = Join-Path $Base 'done.flag'

if ($env:USERNAME -eq 'defaultuser0') { exit 0 }                 # skip ESP/OOBE account
if ((Test-Path $Done) -or (Test-Path $Request)) { exit 0 }       # already done / pending

# Wait for the real desktop (explorer in this session), not ESP
$session = (Get-Process -Id $PID).SessionId
while (-not (Get-Process explorer -ErrorAction SilentlyContinue | Where-Object SessionId -eq $session)) { Start-Sleep -Seconds 5 }
Start-Sleep -Seconds 10

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ---- Prefix: W + T/L/D + 11- (same logic as the task sequence) ----
$cs    = Get-CimInstance Win32_ComputerSystem
$model = $cs.Model
$type  = $cs.PCSystemTypeEx
if ($model -like '*Latitude 7320 Detachable*' -or $model -like '*Latitude 7350 Detachable*' -or $type -eq 8) { $kind = 'T' }
elseif ($type -eq 2) { $kind = 'L' }
else { $kind = 'D' }
$Prefix = "W${kind}11-"

# ---- Detected asset tag (digits only, last 10 chars) ----
$raw = (Get-CimInstance Win32_SystemEnclosure).SMBIOSAssetTag
$tag = ("$raw" -replace '\s', '')
if ([string]::IsNullOrWhiteSpace($tag) -or $tag -in 'noassetinformation', 'noassettag') { $tag = '' }
elseif ($tag.Length -gt 10) { $tag = $tag.Substring($tag.Length - 10) }

# ---- Form ----
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Device Information'
$form.Size = New-Object System.Drawing.Size(500, 300)
$form.StartPosition = 'CenterScreen'
$form.TopMost = $true
$form.ControlBox = $false
$form.FormBorderStyle = 'FixedDialog'

$title = New-Object System.Windows.Forms.Label
$title.Text = 'Device Information'
$title.Font = New-Object System.Drawing.Font('Georgia', 15, [System.Drawing.FontStyle]::Bold)
$title.TextAlign = 'MiddleCenter'
$title.ForeColor = 'White'
$title.BackColor = [System.Drawing.Color]::Gray
$title.Dock = 'Top'
$title.Height = 40
$form.Controls.Add($title)

$hdr = New-Object System.Windows.Forms.Label
$hdr.Text = 'Computer Name:'
$hdr.Font = New-Object System.Drawing.Font('Arial', 12, [System.Drawing.FontStyle]::Bold)
$hdr.ForeColor = [System.Drawing.Color]::DarkBlue
$hdr.AutoSize = $true
$hdr.Location = New-Object System.Drawing.Point(30, 60)
$form.Controls.Add($hdr)

$lblPrefix = New-Object System.Windows.Forms.Label
$lblPrefix.Text = $Prefix
$lblPrefix.Font = New-Object System.Drawing.Font('Arial', 12, [System.Drawing.FontStyle]::Bold)
$lblPrefix.AutoSize = $true
$lblPrefix.Location = New-Object System.Drawing.Point(40, 96)
$form.Controls.Add($lblPrefix)

$txt = New-Object System.Windows.Forms.TextBox
$txt.Location = New-Object System.Drawing.Point(115, 94)
$txt.Width = 200
$txt.Font = New-Object System.Drawing.Font('Arial', 11, [System.Drawing.FontStyle]::Bold)
$txt.Text = $tag
$txt.Enabled = ($tag -eq '')
$form.Controls.Add($txt)

$chk = New-Object System.Windows.Forms.CheckBox
$chk.Text = 'Override detected asset tag'
$chk.AutoSize = $true
$chk.Location = New-Object System.Drawing.Point(40, 130)
$chk.Enabled = ($tag -ne '')
$form.Controls.Add($chk)

$info = New-Object System.Windows.Forms.Label
$info.Text = 'Asset tag number only (see the sticker on the device).'
$info.Location = New-Object System.Drawing.Point(40, 160)
$info.Size = New-Object System.Drawing.Size(420, 20)
$form.Controls.Add($info)

$preview = New-Object System.Windows.Forms.Label
$preview.Font = New-Object System.Drawing.Font('Arial', 10, [System.Drawing.FontStyle]::Bold)
$preview.Location = New-Object System.Drawing.Point(40, 190)
$preview.Size = New-Object System.Drawing.Size(420, 20)
$form.Controls.Add($preview)

$err = New-Object System.Windows.Forms.Label
$err.ForeColor = 'Red'
$err.Location = New-Object System.Drawing.Point(40, 215)
$err.Size = New-Object System.Drawing.Size(320, 20)
$form.Controls.Add($err)

$btn = New-Object System.Windows.Forms.Button
$btn.Text = 'Finish'
$btn.Size = New-Object System.Drawing.Size(75, 25)
$btn.Location = New-Object System.Drawing.Point(390, 225)
$btn.Enabled = $false
$form.Controls.Add($btn)

$validate = {
    $text = $txt.Text.Trim()
    $name = $Prefix + $text
    $preview.Text = "Name will be: $name"
    $ok = $false
    if ($text -eq '')                           { $err.Text = 'Enter the asset tag.' }
    elseif ($name.Length -gt 15)                { $err.Text = "Too long ($($name.Length)/15 characters)." }
    elseif ($name -notmatch '^[A-Za-z0-9-]+$')  { $err.Text = 'Letters, numbers and hyphens only.' }
    else                                        { $err.Text = ''; $ok = $true }
    $btn.Enabled = $ok
}
$txt.Add_TextChanged($validate)

$chk.Add_CheckedChanged({
    if ($chk.Checked) { $txt.Enabled = $true; $txt.Text = '' }
    else              { $txt.Text = $tag; $txt.Enabled = ($tag -eq '') }
})

$btn.Add_Click({
    $name = $Prefix + $txt.Text.Trim()
    [pscustomobject]@{
        ComputerName = $name
        AssetTag     = $txt.Text.Trim()
        Requested    = (Get-Date).ToString('o')
        User         = $env:USERNAME
    } | ConvertTo-Json | Set-Content -Path $Request -Encoding UTF8
    [System.Windows.Forms.MessageBox]::Show("This PC will be renamed to $name and restart in about 1-2 minutes. Save your work.", 'Device Information') | Out-Null
    $form.Close()
})

& $validate
[void]$form.ShowDialog()
