@echo off
rem Runs as SYSTEM from Intune. Use the 64-bit PowerShell (IME is a 32-bit process).
if exist "%windir%\sysnative\WindowsPowerShell\v1.0\powershell.exe" (
    set "PSEXE=%windir%\sysnative\WindowsPowerShell\v1.0\powershell.exe"
) else (
    set "PSEXE=%windir%\System32\WindowsPowerShell\v1.0\powershell.exe"
)
"%PSEXE%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Invoke-AppDeployToolkit.ps1" -DeploymentType Install
exit /b %ERRORLEVEL%
