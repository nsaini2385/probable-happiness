# Runs as SYSTEM (scheduled task, every minute). Picks up the request, renames, restarts.
$Base     = 'C:\ProgramData\DeviceRename'
$Request  = Join-Path $Base 'Drop\request.json'
$Done     = Join-Path $Base 'done.flag'
$LogDir   = Join-Path $Base 'Logs'
$Log      = Join-Path $LogDir 'apply.log'
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
function Write-Log($m) { "$((Get-Date).ToString('s'))  $m" | Add-Content -Path $Log }

function Remove-Tasks {
    foreach ($t in 'DeviceRename-Prompt', 'DeviceRename-Apply') {
        Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction SilentlyContinue
    }
}

if (Test-Path $Done) { Remove-Tasks; exit 0 }
if (-not (Test-Path $Request)) { exit 0 }

try {
    $r    = Get-Content $Request -Raw | ConvertFrom-Json
    $name = "$($r.ComputerName)".Trim()

    # Never trust the drop folder: users can write there
    if ($name.Length -gt 15 -or $name -notmatch '^W[TLD]11-[A-Za-z0-9-]+$') {
        Write-Log "Rejected invalid name '$name'"
        Move-Item $Request "$Request.rejected" -Force
        exit 1
    }

    if ($env:COMPUTERNAME -ne $name) {
        Write-Log "Renaming $env:COMPUTERNAME -> $name"
        Rename-Computer -NewName $name -Force -ErrorAction Stop
    } else {
        Write-Log "Name already $name"
    }

    New-Item -ItemType File -Path $Done -Force | Out-Null
    Remove-Item $Request -Force
    Remove-Tasks
    & shutdown.exe /r /t 90 /c "This PC has been renamed to $name and will restart in 90 seconds. Save your work."
    Write-Log "Rename complete, restart scheduled"
}
catch {
    Write-Log "ERROR: $_"
    exit 1
}
