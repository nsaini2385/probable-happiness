<#
.SYNOPSIS
    WPF device-name popup. Launched into the interactive session by ServiceUI.exe during ESP.
    Writes C:\ProgramData\DeviceRename\Drop\request.json; the SYSTEM-side script does the rename.
    Run with -Preview to test the layout on any PC (no files written, nothing renamed).
#>
[CmdletBinding()]
param([switch]$Preview)

$Base    = 'C:\ProgramData\DeviceRename'
$Drop    = Join-Path $Base 'Drop'
$Request = Join-Path $Drop 'request.json'
$Done    = Join-Path $Base 'done.flag'

if (-not $Preview) {
    if ((Test-Path $Done) -or (Test-Path $Request)) { exit 0 }
    New-Item -ItemType Directory -Path $Drop -Force | Out-Null
}

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase

# ---- Prefix: W + T/L/D + 11- (same logic as the task sequence) ----
$cs    = Get-CimInstance Win32_ComputerSystem
$model = $cs.Model
$type  = $cs.PCSystemTypeEx
if ($model -like '*Latitude 7320 Detachable*' -or $model -like '*Latitude 7350 Detachable*' -or $type -eq 8) { $kind = 'T' }
elseif ($type -eq 2) { $kind = 'L' }
else { $kind = 'D' }
$Prefix = "W${kind}11-"

# ---- Detected asset tag (last 10 chars, blanks/placeholders ignored) ----
$raw = (Get-CimInstance Win32_SystemEnclosure).SMBIOSAssetTag
$DetectedTag = ("$raw" -replace '\s', '')
if ([string]::IsNullOrWhiteSpace($DetectedTag) -or $DetectedTag -in 'noassetinformation', 'noassettag') { $DetectedTag = '' }
elseif ($DetectedTag.Length -gt 10) { $DetectedTag = $DetectedTag.Substring($DetectedTag.Length - 10) }

function Test-DeviceName([string]$Prefix, [string]$Tag) {
    $t    = $Tag.Trim()
    $name = $Prefix + $t
    if ($t -eq '')                          { return @{ Ok = $false; Name = $name; Message = 'Enter the asset tag number.' } }
    if ($name.Length -gt 15)                { return @{ Ok = $false; Name = $name; Message = "Too long ($($name.Length) of 15 characters)." } }
    if ($name -notmatch '^[A-Za-z0-9-]+$')  { return @{ Ok = $false; Name = $name; Message = 'Letters, numbers and hyphens only.' } }
    return @{ Ok = $true; Name = $name; Message = '' }
}

$xaml = @'
<Window
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    Title="Device Setup"
    Width="520" SizeToContent="Height"
    WindowStartupLocation="CenterScreen"
    Topmost="True" ShowInTaskbar="True"
    ResizeMode="NoResize" WindowStyle="None"
    Background="#FFFFFF" FontFamily="Segoe UI">
    <Window.Resources>
        <Style x:Key="PrimaryBtn" TargetType="Button">
            <Setter Property="Background" Value="#1B3A6B"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="bd" Background="{TemplateBinding Background}" CornerRadius="4">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="bd" Property="Background" Value="#2A528F"/>
                            </Trigger>
                            <Trigger Property="IsEnabled" Value="False">
                                <Setter TargetName="bd" Property="Background" Value="#B8C0CC"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>
    <Border BorderBrush="#AAAAAA" BorderThickness="1">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="56"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="60"/>
            </Grid.RowDefinitions>

            <Rectangle Grid.Row="0" Fill="#1B3A6B"/>
            <StackPanel Grid.Row="0" Orientation="Horizontal" VerticalAlignment="Center" Margin="20,0,0,0">
                <TextBlock Text="&#xE770;" FontFamily="Segoe MDL2 Assets" FontSize="22"
                           Foreground="White" VerticalAlignment="Center" Margin="0,0,12,0"/>
                <StackPanel VerticalAlignment="Center">
                    <TextBlock Text="Device Setup" Foreground="White" FontSize="16" FontWeight="Bold"/>
                    <TextBlock Text="Name this device to continue provisioning" Foreground="#C9D6EC" FontSize="11"/>
                </StackPanel>
            </StackPanel>

            <StackPanel Grid.Row="1" Margin="24,20,24,12">
                <TextBlock TextWrapping="Wrap" FontSize="12" Foreground="#444444" Margin="0,0,0,14"
                           Text="Enter the asset tag number from the sticker on the device. Setup continues automatically once you click Finish."/>

                <TextBlock Text="ASSET TAG" FontSize="10" FontWeight="SemiBold" Foreground="#7A8599" Margin="0,0,0,4"/>
                <Grid Margin="0,0,0,8">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <Border Grid.Column="0" Background="#EEF2F8" BorderBrush="#C9D3E3" BorderThickness="1,1,0,1"
                            CornerRadius="4,0,0,4" Padding="12,0">
                        <TextBlock Name="TxtPrefix" FontSize="15" FontWeight="Bold" Foreground="#1B3A6B"
                                   VerticalAlignment="Center"/>
                    </Border>
                    <TextBox Name="TxtTag" Grid.Column="1" FontSize="15" FontWeight="SemiBold" Height="38"
                             VerticalContentAlignment="Center" Padding="8,0" BorderBrush="#C9D3E3"/>
                </Grid>
                <CheckBox Name="ChkOverride" Content="Override detected asset tag" FontSize="12"
                          Foreground="#444444" Margin="0,0,0,2"/>
                <TextBlock Name="TxtHint" FontSize="11" Foreground="#B26A00" Visibility="Collapsed"
                           Text="No asset tag was found in the BIOS. Please type it in."/>

                <Border Background="#F5F8FC" BorderBrush="#D6DEEA" BorderThickness="1" CornerRadius="6"
                        Padding="14,10" Margin="0,16,0,0">
                    <StackPanel>
                        <TextBlock Text="COMPUTER NAME" FontSize="10" FontWeight="SemiBold" Foreground="#7A8599"/>
                        <TextBlock Name="TxtPreview" FontSize="24" FontWeight="Bold" Foreground="#1B3A6B" Margin="0,2,0,0"/>
                    </StackPanel>
                </Border>
                <TextBlock Name="TxtError" FontSize="11" Foreground="#C0392B" Margin="0,8,0,0" MinHeight="16"/>
            </StackPanel>

            <Border Grid.Row="2" Background="#F0F0F0" BorderBrush="#DDDDDD" BorderThickness="0,1,0,0">
                <Grid Margin="24,0">
                    <TextBlock Text="The PC restarts once to apply the name." FontSize="11" Foreground="#777777"
                               VerticalAlignment="Center" HorizontalAlignment="Left"/>
                    <Button Name="BtnFinish" Content="Finish" Width="110" Height="34"
                            HorizontalAlignment="Right" VerticalAlignment="Center"
                            Style="{StaticResource PrimaryBtn}" IsEnabled="False"/>
                </Grid>
            </Border>
        </Grid>
    </Border>
</Window>
'@

$reader        = [System.Xml.XmlReader]::Create([System.IO.StringReader]$xaml)
$script:Win    = [System.Windows.Markup.XamlReader]::Load($reader)
$script:TxtPrefix   = $script:Win.FindName('TxtPrefix')
$script:TxtTag      = $script:Win.FindName('TxtTag')
$script:ChkOverride = $script:Win.FindName('ChkOverride')
$script:TxtHint     = $script:Win.FindName('TxtHint')
$script:TxtPreview  = $script:Win.FindName('TxtPreview')
$script:TxtError    = $script:Win.FindName('TxtError')
$script:BtnFinish   = $script:Win.FindName('BtnFinish')
$script:AllowClose  = $false
$script:Result      = $null

$script:TxtPrefix.Text = $Prefix
$script:TxtTag.MaxLength = [Math]::Max(1, 15 - $Prefix.Length)

$update = {
    $r = Test-DeviceName -Prefix $Prefix -Tag $script:TxtTag.Text
    $script:TxtPreview.Text = $r.Name
    $script:TxtError.Text   = $r.Message
    $script:BtnFinish.IsEnabled = $r.Ok
}

if ($DetectedTag -ne '') {
    $script:TxtTag.Text      = $DetectedTag
    $script:TxtTag.IsEnabled = $false
} else {
    $script:ChkOverride.Visibility = 'Collapsed'
    $script:TxtHint.Visibility     = 'Visible'
}

$script:TxtTag.Add_TextChanged($update)

$script:ChkOverride.Add_Checked({
    $script:TxtTag.IsEnabled = $true
    $script:TxtTag.Text = ''
    $script:TxtTag.Focus() | Out-Null
})
$script:ChkOverride.Add_Unchecked({
    $script:TxtTag.Text = $DetectedTag
    $script:TxtTag.IsEnabled = $false
})

$script:BtnFinish.Add_Click({
    $name = $Prefix + $script:TxtTag.Text.Trim()
    if (-not $Preview) {
        [pscustomobject]@{
            ComputerName = $name
            AssetTag     = $script:TxtTag.Text.Trim()
            Requested    = (Get-Date).ToString('o')
            User         = $env:USERNAME
        } | ConvertTo-Json | Set-Content -Path $Request -Encoding UTF8
    }
    $script:Result     = $name
    $script:AllowClose = $true
    $script:Win.Close()
})

# No close button, no Alt+F4 escape
$script:Win.Add_Closing({ if (-not $script:AllowClose) { $_.Cancel = $true } })
$script:Win.Add_ContentRendered({
    $script:Win.Activate() | Out-Null
    if ($script:TxtTag.IsEnabled) { $script:TxtTag.Focus() | Out-Null }
})

& $update
[void]$script:Win.ShowDialog()

if ($Preview) { Write-Host "Preview result: $script:Result" }
exit 0
