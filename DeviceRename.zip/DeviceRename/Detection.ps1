# Intune custom detection: installed once the rename has completed.
if (Test-Path 'C:\ProgramData\DeviceRename\done.flag') {
    Write-Output 'Device rename completed'
    exit 0
}
exit 1
