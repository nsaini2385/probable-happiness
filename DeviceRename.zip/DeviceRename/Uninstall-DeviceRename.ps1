foreach ($t in 'DeviceRename-Prompt', 'DeviceRename-Apply') {
    Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction SilentlyContinue
}
Remove-Item 'C:\ProgramData\DeviceRename' -Recurse -Force -ErrorAction SilentlyContinue
exit 0
