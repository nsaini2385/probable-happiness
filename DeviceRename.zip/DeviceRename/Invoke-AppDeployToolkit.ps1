<#
.SYNOPSIS
    Device rename orchestrator for Autopilot ESP (replaces the Office 365 orchestrator).

    DeploymentType "Install"   = show the WPF name popup, validate, Rename-Computer, exit 3010
    DeploymentType "Uninstall" = remove the scheduled artefacts and C:\ProgramData\DeviceRename

    Works whether it is started from Intune in session 0 (SYSTEM) or already inside the
    interactive session (e.g. via ServiceUI in install.bat):
      - Session 0   -> launches Show-DeviceNamePrompt.ps1 through ServiceUI.exe
      - Session 1+  -> launches Show-DeviceNamePrompt.ps1 directly
    The rename always runs in THIS process (SYSTEM/admin), never in the popup.

    Log: C:\Windows\Logs\Software\DeviceRename_Install.log
    Exit codes: 0 done | 3010 renamed, restart needed | 1618 retry | 1 hard failure
#>

[CmdletBinding()]
param(
    [string]$DeploymentType = 'Install',
    [string]$DeployMode     = 'Interactive'   # kept for compatibility with the old package; unused
)

# ============================================================
# PSADT stub - same logging pattern as the Office package
# ============================================================
if (-not (Get-Command 'Write-ADTLogEntry' -ErrorAction SilentlyContinue)) {
    function Write-ADTLogEntry {
        param([string]$Message, [string]$Source)
        $timestamp = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        $line      = "[$timestamp][$Source] $Message"
        Write-Host $line
        $logDir = 'C:\Windows\Logs\Software'
        if (-not (Test-Path $logDir)) { New-Item -Path $logDir -ItemType Directory -Force | Out-Null }
        $line | Out-File "$logDir\DeviceRename_Install.log" -Append -Encoding UTF8
    }
}

# ============================================================
# Paths
# ============================================================
$scriptRoot = if ($PSScriptRoot -and $PSScriptRoot -ne '') { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }

$Base      = 'C:\ProgramData\DeviceRename'
$Scripts   = Join-Path $Base 'Scripts'
$Drop      = Join-Path $Base 'Drop'
$Request   = Join-Path $Drop 'request.json'
$Done      = Join-Path $Base 'done.flag'
$ps        = "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe"
$serviceUI = Join-Path $scriptRoot 'ServiceUI.exe'
$popupSrc  = Join-Path $scriptRoot 'Show-DeviceNamePrompt.ps1'
$WaitMins  = 40     # keep below the ESP timeout (default 60 min)

Write-ADTLogEntry -Message "=== Device Rename Started === Type: $DeploymentType | Current name: $env:COMPUTERNAME" -Source 'Main'
Write-ADTLogEntry -Message "Script root: $scriptRoot" -Source 'Main'

# ============================================================
# UNINSTALL
# ============================================================
if ($DeploymentType -eq 'Uninstall') {
    foreach ($t in 'DeviceRename-Prompt', 'DeviceRename-Apply') {
        Unregister-ScheduledTask -TaskName $t -Confirm:$false -ErrorAction SilentlyContinue
    }
    Remove-Item $Base -Recurse -Force -ErrorAction SilentlyContinue
    Write-ADTLogEntry -Message 'Uninstall complete.' -Source 'Main'
    exit 0
}

# ============================================================
# INSTALL
# ============================================================
if (Test-Path $Done) {
    Write-ADTLogEntry -Message 'done.flag present - nothing to do.' -Source 'Main'
    exit 0
}

if (-not (Test-Path $popupSrc)) { Write-ADTLogEntry -Message "ERROR: missing $popupSrc" -Source 'Main'; exit 1 }

$sessionId = [System.Diagnostics.Process]::GetCurrentProcess().SessionId
Write-ADTLogEntry -Message "Running in session $sessionId" -Source 'Main'
if ($sessionId -eq 0 -and -not (Test-Path $serviceUI)) {
    Write-ADTLogEntry -Message "ERROR: ServiceUI.exe not found at $serviceUI" -Source 'Main'
    exit 1
}

# The popup must be readable from the interactive session (IMECache is not).
# Base is locked down; only Drop is user-writable, so the SYSTEM-side code never runs user-editable scripts.
New-Item -ItemType Directory -Path $Scripts, $Drop -Force | Out-Null
Copy-Item $popupSrc -Destination $Scripts -Force
icacls $Base /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' | Out-Null
icacls $Drop /grant '*S-1-5-32-545:(OI)(CI)M' | Out-Null
Remove-Item $Request -Force -ErrorAction SilentlyContinue

$cs = Get-CimInstance Win32_ComputerSystem
Write-ADTLogEntry -Message "PartOfDomain: $($cs.PartOfDomain) | Domain: $($cs.Domain)" -Source 'Main'

$popupArgs = "-STA -NoProfile -ExecutionPolicy Bypass -File `"$Scripts\Show-DeviceNamePrompt.ps1`""

function Start-Popup {
    if ($sessionId -ne 0) {
        Write-ADTLogEntry -Message 'Launching popup directly (interactive session).' -Source 'Main'
        return Start-Process $ps -ArgumentList $popupArgs -PassThru -WindowStyle Hidden
    }
    $target = $null
    foreach ($p in 'explorer', 'CloudExperienceHostBroker') {
        if (Get-Process $p -ErrorAction SilentlyContinue) { $target = "$p.exe"; break }
    }
    if (-not $target) {
        Write-ADTLogEntry -Message 'No interactive process found to attach the UI to.' -Source 'Main'
        return $null
    }
    Write-ADTLogEntry -Message "Launching popup via ServiceUI on $target" -Source 'Main'
    return Start-Process $serviceUI -ArgumentList "-process:$target $ps $popupArgs" -PassThru -WindowStyle Hidden
}

# ============================================================
# Wait for the technician to submit the name.
# If the popup process dies without a result it is relaunched (max 5 times).
# ============================================================
$deadline = (Get-Date).AddMinutes($WaitMins)
$launches = 0
$proc     = $null
while (-not (Test-Path $Request)) {
    if ((Get-Date) -gt $deadline) {
        Write-ADTLogEntry -Message 'Timed out waiting for input.' -Source 'Main'
        exit 1618
    }
    if ((-not $proc -or $proc.HasExited) -and $launches -lt 5) {
        $proc = Start-Popup
        $launches++
        if (-not $proc) { Start-Sleep -Seconds 15 }
    }
    Start-Sleep -Seconds 3
}

# ============================================================
# Validate (Drop is user-writable - never trust it) and rename
# ============================================================
try {
    $r    = Get-Content $Request -Raw | ConvertFrom-Json
    $name = "$($r.ComputerName)".Trim()
    Write-ADTLogEntry -Message "Request received: $name" -Source 'Main'

    if ($name.Length -gt 15 -or $name -notmatch '^W[TLD]11-[A-Za-z0-9-]+$') {
        Write-ADTLogEntry -Message "Rejected invalid name '$name'." -Source 'Main'
        Move-Item $Request "$Request.rejected" -Force
        exit 1618
    }

    if ($env:COMPUTERNAME -eq $name) {
        Write-ADTLogEntry -Message "Name already $name." -Source 'Main'
    } else {
        $ok = $false
        for ($i = 1; $i -le 6 -and -not $ok; $i++) {
            try {
                Write-ADTLogEntry -Message "Rename attempt ${i}: $env:COMPUTERNAME -> $name" -Source 'Main'
                Rename-Computer -NewName $name -Force -ErrorAction Stop
                $ok = $true
            } catch {
                Write-ADTLogEntry -Message "Attempt $i failed: $_" -Source 'Main'
                Start-Sleep -Seconds 30
            }
        }
        if (-not $ok) {
            Write-ADTLogEntry -Message 'Rename failed after retries (check DC reachability and the SELF delegation on the OU).' -Source 'Main'
            exit 1618
        }
    }

    New-Item -ItemType File -Path $Done -Force | Out-Null
    Remove-Item $Request -Force -ErrorAction SilentlyContinue
    Write-ADTLogEntry -Message '=== Rename complete. Exit 3010 so ESP restarts the device. ===' -Source 'Main'
    exit 3010
}
catch {
    Write-ADTLogEntry -Message "ERROR: $_" -Source 'Main'
    exit 1618
}
