WHAT TO DO IN YOUR EXISTING OFFICE PACKAGE FOLDER
  Replace:  Invoke-AppDeployToolkit.ps1, Detection.ps1, install.bat, Uninstall.bat
  Add:      Show-DeviceNamePrompt.ps1
  Keep:     ServiceUI.exe (same folder as the scripts)
  Delete:   Files\ (Office installer), Show-DeferralPrompt.ps1, Show-ProgressWindow.ps1,
            download.png, Error.png, New folder, New Text Document.txt, old .intunewin
  The PSAppDeployToolkit folder and Invoke-AppDeployToolkit.exe are not used by this script.
  Re-run IntuneWinAppUtil: IntuneWinAppUtil.exe -c <folder> -s install.bat -o <out>

INTUNE
  Install command:   install.bat
  Uninstall command: Uninstall.bat
  Install behavior:  System
  Return codes:      defaults (0 success, 3010 soft reboot, 1618 retry)
  Detection:         custom script - Detection.ps1
  Assignment:        Required, Autopilot DEVICE group; add to ESP blocking apps
  Unassign the old logon-time rename app (if installed) first.

PREVIEW THE UI ON ANY PC (no rename, no files written)
  powershell.exe -STA -ExecutionPolicy Bypass -File .\Show-DeviceNamePrompt.ps1 -Preview

LOG
  C:\Windows\Logs\Software\DeviceRename_Install.log
