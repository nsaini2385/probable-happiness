# Intune Win32 app install (run as SYSTEM). Copies scripts, locks ACLs, registers the two tasks.
if (-not [Environment]::Is64BitProcess -and $env:PROCESSOR_ARCHITEW6432) {
    & "$env:windir\sysnative\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit $LASTEXITCODE
}

$Base    = 'C:\ProgramData\DeviceRename'
$Scripts = Join-Path $Base 'Scripts'
$Drop    = Join-Path $Base 'Drop'

# Already renamed on a previous run? Don't re-arm.
if (Test-Path (Join-Path $Base 'done.flag')) { exit 0 }

New-Item -ItemType Directory -Path $Scripts, $Drop -Force | Out-Null
Copy-Item "$PSScriptRoot\Show-DeviceName.ps1", "$PSScriptRoot\Apply-DeviceName.ps1" -Destination $Scripts -Force

# Scripts that run as SYSTEM must not be writable by users.
# Base: SYSTEM/Admins full, Users read. Drop: Users can write the request file.
icacls $Base /inheritance:r /grant:r '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F' '*S-1-5-32-545:(OI)(CI)RX' | Out-Null
icacls $Drop /grant '*S-1-5-32-545:(OI)(CI)M' | Out-Null

$ps = "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe"

# Task 1: popup, in the user's session at logon
$a1 = New-ScheduledTaskAction -Execute $ps -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Scripts\Show-DeviceName.ps1`""
$t1 = New-ScheduledTaskTrigger -AtLogOn
$p1 = New-ScheduledTaskPrincipal -GroupId 'S-1-5-32-545' -RunLevel Limited
$s1 = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Hours 8)
Register-ScheduledTask -TaskName 'DeviceRename-Prompt' -Action $a1 -Trigger $t1 -Principal $p1 -Settings $s1 -Force | Out-Null

# Task 2: rename as SYSTEM, polls every minute for the request
$a2 = New-ScheduledTaskAction -Execute $ps -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$Scripts\Apply-DeviceName.ps1`""
$t2 = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 7)
$p2 = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$s2 = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 5)
Register-ScheduledTask -TaskName 'DeviceRename-Apply' -Action $a2 -Trigger $t2 -Principal $p2 -Settings $s2 -Force | Out-Null

# Detection marker (install is "done" when tasks exist; rename happens later)
New-Item -ItemType File -Path (Join-Path $Base 'installed.flag') -Force | Out-Null
exit 0
