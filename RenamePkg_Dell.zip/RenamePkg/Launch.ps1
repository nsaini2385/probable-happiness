# Launch.ps1 - runs as SYSTEM from Intune. Shows the popup in the OOBE/ESP session via ServiceUI (session-based,
# same technique as Michael Niehaus' OOBEPrompt), then renames the computer with the domain credentials entered.
[CmdletBinding()]
Param([Int32]$SessionID = 0)

$ErrorActionPreference = 'Stop'
$Domain   = 'melb.ad'
$Prefix   = 'WL11-'
$WorkDir  = 'C:\ProgramData\Rename'
$Log      = Join-Path $WorkDir 'Rename.log'
$Result   = Join-Path $WorkDir 'result.json'
$RegPath  = 'HKLM:\SOFTWARE\Rename'
$BiosPassword = ''   # Dell BIOS setup/admin password, only if one is set (leave empty otherwise)
New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null
function Write-Log($m){ "$(Get-Date -Format 's') $m" | Add-Content $Log }

# Must be 64-bit (Intune agent is 32-bit)
if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {
    $ps64 = "$env:windir\sysnative\WindowsPowerShell\v1.0\powershell.exe"
    & $ps64 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit $LASTEXITCODE
}

try {
    Write-Log "Start. Current name: $env:COMPUTERNAME"
    $here = Split-Path -Parent $PSCommandPath
    foreach ($f in 'ServiceUI.exe','ShiftF10.exe','Show-DeviceInfo.ps1','Dell-Asset.ps1') {
        if (-not (Test-Path (Join-Path $here $f))) { throw "$f missing from package" }
        # Copy to a space-free path: ServiceUI mangles quoted arguments
        Copy-Item (Join-Path $here $f) (Join-Path $WorkDir $f) -Force
    }
    $serviceUI = Join-Path $WorkDir 'ServiceUI.exe'
    $popup     = Join-Path $WorkDir 'Show-DeviceInfo.ps1'
    $psExe     = "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe"

    # Session to show the UI in: active console session (1 in OOBE/ESP), fallback 1
    if ($SessionID -le 0) {
        Add-Type -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint WTSGetActiveConsoleSessionId();' -Name K32 -Namespace Win -ErrorAction SilentlyContinue
        $sid = [Win.K32]::WTSGetActiveConsoleSessionId()
        $SessionID = if ($sid -eq [uint32]::MaxValue -or $sid -eq 0) { 1 } else { [int]$sid }
    }
    Write-Log "Using session $SessionID"

    Remove-Item $Result -Force -ErrorAction SilentlyContinue
    # Settings go via file so the ServiceUI command line stays minimal (same shape as the working OOBEPrompt pattern)
    @{ Prefix = $Prefix; Domain = $Domain } | ConvertTo-Json | Set-Content (Join-Path $WorkDir 'config.json') -Encoding UTF8
    Set-Location $WorkDir

    # Variants tried in turn if ServiceUI fails: explicit session, console default, session of winlogon.exe
    $variants = @("-session:$SessionID", '', '-process:winlogon.exe')
    $deadline = (Get-Date).AddMinutes(30)
    $fails = 0
    while (-not (Test-Path $Result) -and (Get-Date) -lt $deadline) {
        $v = $variants[$fails % $variants.Count]
        $svcArgs = @(); if ($v) { $svcArgs += $v }
        $svcArgs += @($psExe, '-ExecutionPolicy', 'Bypass', '-NoProfile', '-File', $popup)
        Write-Log "Running: ServiceUI $($svcArgs -join ' ')"
        $out  = & $serviceUI @svcArgs 2>&1 | Out-String
        $code = $LASTEXITCODE
        Write-Log "ServiceUI exit code $code"
        Write-Log "ServiceUI output: $(($out -replace '\s+',' ').Trim())"
        if (-not (Test-Path $Result)) {
            $fails++
            if ($fails -ge 6) { throw "Popup produced no result after $fails attempts (last ServiceUI exit $code). See $WorkDir\Rename.log" }
            Start-Sleep 5
        }
    }
    if (-not (Test-Path $Result)) { throw 'Popup timed out, no result' }

    $r = Get-Content $Result -Raw | ConvertFrom-Json
    Remove-Item $Result -Force -ErrorAction SilentlyContinue   # holds the protected password, don't leave it on disk
    $newName = ($r.Name).Trim().ToUpper()
    if ($newName -notmatch '^[A-Z0-9\-]{1,15}$' -or -not $newName.StartsWith($Prefix)) { throw "Invalid name '$newName'" }
    Write-Log "Requested name $newName (detected serial '$($r.AssetTag)', override=$($r.Override))"

    Add-Type -AssemblyName System.Security
    $plain = [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($r.Pw), $null, 'LocalMachine'))
    $acct  = if ($r.User -match '[\\@]') { $r.User } else { "$($r.User)@$Domain" }
    $cred  = New-Object System.Management.Automation.PSCredential($acct, (ConvertTo-SecureString $plain -AsPlainText -Force))
    $plain = $null

    if ($env:COMPUTERNAME -ne $newName) {
        $joined = (Get-CimInstance Win32_ComputerSystem).PartOfDomain
        if ($joined) {
            Write-Log "Domain joined, renaming with domain credentials ($acct)"
            Rename-Computer -NewName $newName -DomainCredential $cred -Force -ErrorAction Stop
        } else {
            Write-Log 'Not domain joined yet, local rename only'
            Rename-Computer -NewName $newName -Force -ErrorAction Stop
        }
        Write-Log "Renamed to $newName"
    } else { Write-Log 'Name already correct' }

    # Write the computer name into the Dell BIOS asset tag (non-fatal: a failure here never blocks the rename)
    try {
        . (Join-Path $WorkDir 'Dell-Asset.ps1')
        $cur = Get-DellAssetTag -Live
        if ($cur -ieq $newName) { Write-Log 'BIOS asset tag already matches the name' }
        else {
            $res = Set-DellAssetTag -Value $newName -BiosPassword $BiosPassword
            Write-Log "Asset tag write: ok=$($res.Ok) | $($res.Msg)"
            if ($res.Ok) { Write-Log "Asset tag now reads: '$(Get-DellAssetTag -Live)'" }
        }
    } catch { Write-Log "Asset tag step failed (non-fatal): $($_.Exception.Message)" }

    New-Item -Path $RegPath -Force | Out-Null
    New-ItemProperty -Path $RegPath -Name Done -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $RegPath -Name Name -Value $newName -PropertyType String -Force | Out-Null
    exit 3010   # soft reboot, treated as success by Intune
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    exit 1
}
