﻿<#
.SYNOPSIS
	This script performs the installation or uninstallation of an application(s).
	# LICENSE #
	PowerShell App Deployment Toolkit - Provides a set of functions to perform common application deployment tasks on Windows.
	Copyright (C) 2017 - Sean Lillis, Dan Cunningham, Muhammad Mashwani, Aman Motazedian.
	This program is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
	You should have received a copy of the GNU Lesser General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.
.DESCRIPTION
	The script is provided as a template to perform an install or uninstall of an application(s).
	The script either performs an "Install" deployment type or an "Uninstall" deployment type.
	The install deployment type is broken down into 3 main sections/phases: Pre-Install, Install, and Post-Install.
	The script dot-sources the AppDeployToolkitMain.ps1 script which contains the logic and functions required to install or uninstall an application.
.PARAMETER DeploymentType
	The type of deployment to perform. Default is: Install.
.PARAMETER DeployMode
	Specifies whether the installation should be run in Interactive, Silent, or NonInteractive mode. Default is: Interactive. Options: Interactive = Shows dialogs, Silent = No dialogs, NonInteractive = Very silent, i.e. no blocking apps. NonInteractive mode is automatically set if it is detected that the process is not user interactive.
.PARAMETER AllowRebootPassThru
	Allows the 3010 return code (requires restart) to be passed back to the parent process (e.g. SCCM) if detected from an installation. If 3010 is passed back to SCCM, a reboot prompt will be triggered.
.PARAMETER TerminalServerMode
	Changes to "user install mode" and back to "user execute mode" for installing/uninstalling applications for Remote Destkop Session Hosts/Citrix servers.
.PARAMETER DisableLogging
	Disables logging to file for the script. Default is: $false.
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeployMode 'Silent'; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -AllowRebootPassThru; Exit $LastExitCode }"
.EXAMPLE
    powershell.exe -Command "& { & '.\Deploy-Application.ps1' -DeploymentType 'Uninstall'; Exit $LastExitCode }"
.EXAMPLE
    Deploy-Application.exe -DeploymentType "Install" -DeployMode "Silent"
.NOTES
	Toolkit Exit Code Ranges:
	60000 - 68999: Reserved for built-in exit codes in Deploy-Application.ps1, Deploy-Application.exe, and AppDeployToolkitMain.ps1
	69000 - 69999: Recommended for user customized exit codes in Deploy-Application.ps1
	70000 - 79999: Recommended for user customized exit codes in AppDeployToolkitExtensions.ps1
.LINK
	http://psappdeploytoolkit.com
#>
[CmdletBinding()]
Param (
	[Parameter(Mandatory=$false)]
	[ValidateSet('Install','Uninstall', 'Repair')]
	[string]$DeploymentType = 'Install',
	[Parameter(Mandatory=$false)]
	[ValidateSet('Interactive','Silent','NonInteractive')]
	[string]$DeployMode = 'Interactive',
	[Parameter(Mandatory=$false)]
	[switch]$AllowRebootPassThru = $false,
	[Parameter(Mandatory=$false)]
	[switch]$TerminalServerMode = $false,
	[Parameter(Mandatory=$false)]
	[switch]$DisableLogging = $false,
    [Parameter(Mandatory=$false)]
    [ValidateSet("ENUS","ALL")]
    [string]$Language = "ENUS"
)

Try {
	## Set the script execution policy for this process
	Try { Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Scope 'Process' -Force -ErrorAction 'Stop' } Catch {}

	##*===============================================
	##* VARIABLE DECLARATION
	##*===============================================
	## Variables: Application
	[string]$appVendor = 'Microsoft'
	[string]$appName = 'Office 365'
	[string]$appVersion = ''
	[string]$appArch = 'x64'
	[string]$appLang = 'EN'
	[string]$appRevision = '003'
	[string]$appScriptVersion = '1.0.0'
	[string]$appScriptDate = '10/04/2024'
	[string]$appScriptAuthor = 'kundv1'
	##*===============================================
	## Variables: Install Titles (Only set here to override defaults set by the toolkit)
	[string]$installName = ''
	[string]$installTitle = ''

	##* Do not modify section below
	#region DoNotModify

	## Variables: Exit Code
	[int32]$mainExitCode = 0

	## Variables: Script
	[string]$deployAppScriptFriendlyName = 'Deploy-Office365x64'
	[version]$deployAppScriptVersion = [version]'3.8.0'
	[string]$deployAppScriptDate = '23/09/2019'
	[hashtable]$deployAppScriptParameters = $psBoundParameters

	## Variables: Environment
	If (Test-Path -LiteralPath 'variable:HostInvocation') { $InvocationInfo = $HostInvocation } Else { $InvocationInfo = $MyInvocation }
	[string]$scriptDirectory = Split-Path -Path $InvocationInfo.MyCommand.Definition -Parent

	## Dot source the required App Deploy Toolkit Functions
	Try {
		[string]$moduleAppDeployToolkitMain = "$scriptDirectory\AppDeployToolkit\AppDeployToolkitMain.ps1"
		If (-not (Test-Path -LiteralPath $moduleAppDeployToolkitMain -PathType 'Leaf')) { Throw "Module does not exist at the specified location [$moduleAppDeployToolkitMain]." }
		If ($DisableLogging) { . $moduleAppDeployToolkitMain -DisableLogging } Else { . $moduleAppDeployToolkitMain }
	}
	Catch {
		If ($mainExitCode -eq 0){ [int32]$mainExitCode = 60008 }
		Write-Error -Message "Module [$moduleAppDeployToolkitMain] failed to load: `n$($_.Exception.Message)`n `n$($_.InvocationInfo.PositionMessage)" -ErrorAction 'Continue'
		## Exit the script, returning the exit code to SCCM
		If (Test-Path -LiteralPath 'variable:HostInvocation') { $script:ExitCode = $mainExitCode; Exit } Else { Exit $mainExitCode }
	}

	#endregion
	##* Do not modify section above
	##*===============================================
	##* END VARIABLE DECLARATION
	##*===============================================

# Set the initial Office folder
[string] $dirOffice = Join-Path -Path "$envProgramFilesX86" -ChildPath "Microsoft Office"
[string] $dirOfficeC2R = Join-Path -Path "$envProgramFiles" -ChildPath "Microsoft Office 15"
[string] $dirOfficeX64 = Join-Path -Path "$envProgramFiles" -ChildPath "Microsoft Office"
[string] $dirOfficeC2RX86 = Join-Path -Path "$envProgramFilesX86" -ChildPath "Microsoft Office 15"

	If (($deploymentType -ine 'Uninstall') -and ($deploymentType -ine 'Repair')) {
		##*===============================================
		##* PRE-INSTALLATION
		##*===============================================
		[string]$installPhase = 'Pre-Installation'
# Defines the specific tracking key for your Office deployment
$AppKey = "Microsoft_Office365_x64_EN_003"
$RegPath = "HKLM:\SOFTWARE\PSADT_Deferrals\$AppKey"
$DeferUntil = (Get-Date).AddHours(1)

# Creates the registry path and writes the 1-hour expiration time
if (-not (Test-Path $RegPath)) { New-Item -Path $RegPath -Force | Out-Null }
New-ItemProperty -Path $RegPath -Name "DeferUntil" -Value ($DeferUntil.ToString("o")) -PropertyType String -Force | Out-Null

		## Show Welcome Message, close Internet Explorer if required, allow up to 6 deferrals, verify there is enough disk space to complete the install, and persist the prompt
		Show-InstallationWelcomeWPF -CloseApps "excel,groove,onenote,outlook,powerpnt,winword,winproj,visio,teams" -AllowDefer -MinimizeWindows $false -TopMost $true -DeferTimes 3

		## Show Progress Message (with the default message)
		Show-InstallationProgressWPF -StatusMessage "Microsoft Office 365 Installation in Progress…The Installation may take up to 25 minutes to complete." -TopMost $False




		## <Perform Pre-Installation tasks here>

		##*===============================================
		##* INSTALLATION
		##*===============================================
		[string]$installPhase = 'Installation'

           Write-Log -Message "Starting Office removal and upgrade process..." -Source $deployAppScriptFriendlyName

        # Define Setup Path using PSADT's built-in $dirFiles path
        $SetupExe = Join-Path -Path $dirFiles -ChildPath "setup.exe"

        # Inline Helper Function for Office Click-to-Run configuration
        Function Invoke-OfficeConfig {
            param([string]$XmlName)
            $XmlPath = Join-Path -Path $dirFiles -ChildPath $XmlName
            If (Test-Path -Path $XmlPath) {
                Write-Log -Message "Running configuration with XML: $XmlName" -Source "Invoke-OfficeConfig"
                Execute-Process -Path $SetupExe -Parameters "/configure `"$XmlPath`""
            } Else {
                Write-Log -Message "XML Configuration file not found at: $XmlPath" -Severity 2 -Source "Invoke-OfficeConfig"
            }
        }

        # 1. Remove older Visio / Project Click-to-Run if present
        If (Test-Path -Path "$env:ProgramFilesX86\Microsoft Office\root\Office16\Visio.exe") { Invoke-OfficeConfig "RemoveVisioStd.xml" }
        If (Test-Path -Path "$env:ProgramFilesX86\Microsoft Office\root\Office16\WinProj.exe") { Invoke-OfficeConfig "Uninstall-ProjStdXVolume.xml" }

        # 2. Handle legacy MSI Office 2016 uninstallation
        $MsiSetup86 = "C:\Program Files (x86)\Common Files\Microsoft Shared\OFFICE16\Office Setup Controller\setup.exe"
        $MsiConfig  = Join-Path -Path $dirFiles -ChildPath "O2016\remove2016.xml"

        If (Test-Path -Path $MsiSetup86) {
            Write-Log -Message "Legacy Office 2016 MSI installation detected. Executing removal controller..." -Source $deployAppScriptFriendlyName
            Execute-Process -Path $MsiSetup86 -Parameters "/uninstall PROPLUS /config `"$MsiConfig`""
        }

        # 3. Target remaining cleanups
        If (Test-Path -Path "$env:ProgramFilesX86\Microsoft Office\root\Office16\winproj.exe") { Invoke-OfficeConfig "removeprj.xml" }
        If (Test-Path -Path "$env:ProgramFilesX86\Microsoft Office\root\Office16\Visio.exe")  { Invoke-OfficeConfig "RemoveVisioStd2021.xml" }
        If (Test-Path -Path "$env:ProgramFilesX86\Microsoft Office\root\Office16\outlook.exe") { Invoke-OfficeConfig "remove.xml" }

        # 4. Install the new Office deployment profile
        Write-Log -Message "Initiating final Office Suite deployment installation..." -Source $deployAppScriptFriendlyName
        Invoke-OfficeConfig "configuration.xml"
		##*===============================================
		##* POST-INSTALLATION
		##*===============================================
		[string]$installPhase = 'Post-Installation'

		## <Perform Post-Installation tasks here>

        ## Display a message at the end of the install
       ## Show-InstallationPromptWPF -Message "Microsoft Project Online Professional Installation is complete." -ButtonRightText "OK" -Icon Information -NoWait
        Show-InstallationPrompt -Message 'Microsoft Office 365 Installation is complete.' -ButtonRightText 'OK' -Icon Information -NoWait

		## Show Installation restart prompt with 240 minute countdown.
		#  Show-InstallationRestartPromptWPF -CountdownMinutes 240 -CountdownNoHideMinutes 10

	}
	ElseIf ($deploymentType -ieq 'Uninstall')
	{
		##*===============================================
		##* PRE-UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Pre-Uninstallation'

		## Show Welcome Message, close Internet Explorer if required, allow up to 6 deferrals, verify there is enough disk space to complete the install, and persist the prompt
		Show-InstallationWelcomeWPF -CloseApps "officeclicktorun,ose,osppsvc,sppsvc,msoia,excel,groove,onenote,infopath,onenote,outlook,mspub,powerpnt,winword,winproj,visio,iexplore,lync,communicator,teams,ONENOTEM,msaccess" -AllowDefer -MinimizeWindows $false -TopMost $true -DeferTimes 3

		## Show Progress Message (with the default message)
		# Show-InstallationProgressWPF

		## <Perform Pre-Uninstallation tasks here>


		##*===============================================
		##* UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Uninstallation'
        ## Handle Zero-Config MSI Uninstallations
        If ($useDefaultMsi) { Execute-MSI -Action "Uninstall" -Path $defaultMsiFile }

		# <Perform Uninstallation tasks here>
        Show-InstallationProgressWPF -StatusMessage "Uninstalling Microsoft Project Standard. This may take some time. Please wait…"
        Execute-Process -Path "$dirFiles\uninstall.bat" -WindowStyle "Hidden"

		##*===============================================
		##* POST-UNINSTALLATION
		##*===============================================
		[string]$installPhase = 'Post-Uninstallation'

		## <Perform Post-Uninstallation tasks here>
		## Show Installation restart prompt with 240 minute countdown.
		#  Show-InstallationRestartPromptWPF -CountdownMinutes 240 -CountdownNoHideMinutes 10

	}
	ElseIf ($deploymentType -ieq 'Repair')
	{
		##*===============================================
		##* PRE-REPAIR
		##*===============================================
		[string]$installPhase = 'Pre-Repair'

		## Show Welcome Message, close Internet Explorer if required, allow up to 6 deferrals, verify there is enough disk space to complete the install, and persist the prompt
		Show-InstallationWelcomeWPF -CloseApps "officeclicktorun,ose,osppsvc,sppsvc,msoia,excel,groove,onenote,infopath,onenote,outlook,mspub,powerpnt,winword,winproj,visio,iexplore,lync,communicator,teams,ONENOTEM,msaccess" -AllowDefer -MinimizeWindows $false -TopMost $true -DeferTimes 3

		## Show Progress Message (with the default message)
		# Show-InstallationProgress

		## <Perform Pre-Repair tasks here>


		##*===============================================
		##* REPAIR
		##*===============================================
		[string]$installPhase = 'Repair'

        ## Handle Zero-Config MSI Uninstallations
        If ($useDefaultMsi) { Execute-MSI -Action "Repair" -Path $defaultMsiFile }


		# <Perform Repair tasks here>

        Show-InstallationProgressWPF -StatusMessage "Repairing Microsoft Project Online Professional. This may take some time. Please wait…"
        Execute-Process -Path "$dirFiles\install.bat" -WindowStyle "Hidden"

		##*===============================================
		##* POST-REPAIR
		##*===============================================
		[string]$installPhase = 'Post-Repair'

		## <Perform Post-Repair tasks here>
		## Show Installation restart prompt with 240 minute countdown.
		#  Show-InstallationRestartPromptWPF -CountdownMinutes 240 -CountdownNoHideMinutes 10

	}

	##*===============================================
	##* END SCRIPT BODY
	##*===============================================

	## Call the Exit-Script function to perform final cleanup operations
	Exit-Script -ExitCode $mainExitCode
}
Catch {
	[int32]$mainExitCode = 60001
	[string]$mainErrorMessage = "$(Resolve-Error)"
	Write-Log -Message $mainErrorMessage -Severity 3 -Source $deployAppScriptFriendlyName
	Show-DialogBox -Text $mainErrorMessage -Icon 'Stop'
	Exit-Script -ExitCode $mainExitCode
}
