Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show(
    'Your computer is about to upgrade Microsoft Office. Office 2016 will be removed and Microsoft 365 Apps will be installed. Please save your work.',
    'Office Upgrade',
    'OK',
    'Warning'
)