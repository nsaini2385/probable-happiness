@echo off
setlocal EnabledDelayedExpansion

del /f /q "C:\ProgramData\OfficeUpgradeSnooze.txt" 2>nul
if not exist "C:\ProgramData\OfficeUpgradeDefer.txt" (
    echo Defer > "C:\ProgramData\OfficeUpgradeDefer.txt"
)

:PROMPT_LOOP
echo Displaying mandatory upgrade prompt...

"%~dp0ServiceUI.exe" -process:explorer.exe %SYSTEMROOT%\System32\WindowsPowerShell\v1.0\powershell.exe -WindowStyle Hidden -NonInteractive -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Upgrade6.ps1"

set "ExitStatus=%errorlevel%"

:: If PowerShell returns 1618, user gracefully hit Snooze. Exit script cleanly.
if %ExitStatus% EQU 1618 (
    echo User selected Snooze. Exiting script to allow Intune deferral.
    exit /b 0
)

:: If exit status is 5 (or any unexpected close error), wait and relaunch
if %ExitStatus% NEQ 0 (
    echo User closed the prompt aggressively. Relaunching in 2 seconds...
    timeout /t 2 /nobreak >nul
    goto PROMPT_LOOP
)

echo Success confirmation received.
exit /b 0
