# 1. FORCE POPUP WINDOW UNTIL USER CLICKS OK (Using OK/Cancel to trap the 'X' button)
Add-Type -AssemblyName PresentationFramework

$Title   = "Mandatory Action Required"
$Message = "Your computer requires a critical Microsoft Office upgrade. Please close all active Office documents and click OK to begin the installation process."

while ($true) {
    # Using OkCancel instead of OK. This forces 'X' to mean 'Cancel' instead of 'OK'.
    $Selection = [System.Windows.MessageBox]::Show($Message, $Title, [System.Windows.MessageBoxButton]::OKCancel, [System.Windows.MessageBoxImage]::Warning)
    
    # Only break the loop if they explicitly click the OK button
    if ($Selection -eq "OK") {
        break
    }
    
    # If they clicked 'Cancel' or the 'X' button, the loop skips this and pops up again!
    Write-Host "User tried to close the window. Relaunching prompt..."
}

Write-Host "User clicked OK. Commencing file uninstallation steps..."

# 2. DEFINE SYSTEM ENVIRONMENT PATHS
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$SetupExe  = Join-Path $ScriptDir "setup.exe"
$Prog86    = ${env:ProgramFiles(x86)}
$Prog64    = ${env:ProgramFiles}

# Helper function to safely execute the Office Deployment Tool (setup.exe)
function Invoke-OfficeConfig {
    param ([string]$XmlName)
    $XmlPath = Join-Path $ScriptDir $XmlName
    if (Test-Path $SetupExe) {
        Start-Process -FilePath $SetupExe -ArgumentList "/configure `"$XmlPath`"" -Wait -NoNewWindow
    }
}

# 3. CONVERTED REMOVAL LOGIC
# Remove Visio Standard
if (Test-Path "$Prog86\Microsoft Office\root\Office16\Visio.exe") { Invoke-OfficeConfig "RemoveVisioStd.xml" }
if (Test-Path "$Prog64\Microsoft Office\root\Office16\Visio.exe") { Invoke-OfficeConfig "RemoveVisioStd.xml" }

# Remove Project Standard Volume
if (Test-Path "$Prog86\Microsoft Office\root\Office16\Winproj.exe") { Invoke-OfficeConfig "Uninstall-ProjStdXVolume.xml" }
if (Test-Path "$Prog64\Microsoft Office\root\Office16\Winproj.exe") { Invoke-OfficeConfig "Uninstall-ProjStdXVolume.xml" }

# Remove Office 2016 ProPlus Legacy MSI Installations
$MsiSetup86 = "C:\Program Files (x86)\Common Files\Microsoft Shared\OFFICE16\Office Setup Controller\setup.exe"
$MsiSetup64 = "C:\Program Files\Common Files\Microsoft Shared\OFFICE16\Office Setup Controller\setup.exe"
$MsiConfig  = Join-Path $ScriptDir "O2016\remove2016.xml"

if (Test-Path $MsiSetup86) {
    Start-Process -FilePath $MsiSetup86 -ArgumentList "/uninstall PROPLUS /config `"$MsiConfig`"" -Wait -NoNewWindow
}
if (Test-Path $MsiSetup64) {
    Start-Process -FilePath $MsiSetup64 -ArgumentList "/uninstall PROPLUS /config `"$MsiConfig`"" -Wait -NoNewWindow
}

# Remaining Office Component Cleanups
if (Test-Path "$Prog86\Microsoft Office\root\Office16\winproj.exe") { Invoke-OfficeConfig "removeprj.xml" }
if (Test-Path "$Prog86\Microsoft Office\root\Office16\Visio.exe")  { Invoke-OfficeConfig "RemoveVisioStd2021.xml" }
if (Test-Path "$Prog86\Microsoft Office\root\Office16\outlook.exe")    { Invoke-OfficeConfig "remove.xml" }


# 4. INSTALL THE NEW OFFICE PACKAGE
Invoke-OfficeConfig "configuration.xml"

# Exit cleanly with success code for Intune
Exit 0
