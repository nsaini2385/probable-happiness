Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# 1. SETUP ENVIRONMENT CONFIGURATION PATHS
$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Definition
$SnoozeFile  = Join-Path $env:ProgramData "OfficeUpgradeSnooze.txt"
$SetupExe    = Join-Path $ScriptDir "setup.exe"
$Prog86      = ${env:ProgramFiles(x86)}
$Prog64      = ${env:ProgramFiles}

# --- BYPASS SNOOZE IF TESTING MANUALLY ---
if (Test-Path $SnoozeFile) {
    if ([Environment]::UserInteractive -eq $false -or $env:USERNAME -eq "SYSTEM") {
        $SnoozeTime = Get-Date (Get-Content $SnoozeFile)
        if ((Get-Date) -lt $SnoozeTime) {
            Write-Host "Snooze window active until $SnoozeTime. Exiting gracefully."
            Exit 0
        }
    }
}

# 2. PERSISTENT SYSTEM LOOP
# This loop runs forever. The script CANNOT bypass or run the installations unless 'OK' or 'Snooze' is handled.
while ($true) {

    # Render Custom Graphical User Interface
    $Form = New-Object System.Windows.Forms.Form
    $Form.Text = "Mandatory Action Required"
    $Form.Size = New-Object System.Drawing.Size(460, 200)
    $Form.StartPosition = "CenterScreen"
    $Form.FormBorderStyle = "FixedDialog"
    $Form.MaximizeBox = $false
    $Form.MinimizeBox = $false
    $Form.TopMost = $true

    # Message Layout
    $Label = New-Object System.Windows.Forms.Label
    $Label.Text = "Your computer requires a critical Microsoft Office upgrade.`n`nPlease close all active Office documents and click OK to begin the installation process."
    $Label.Location = New-Object System.Drawing.Point(20, 20)
    $Label.Size = New-Object System.Drawing.Size(400, 60)
    $Label.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    # OK Button
    $BtnOK = New-Object System.Windows.Forms.Button
    $BtnOK.Text = "OK"
    $BtnOK.Location = New-Object System.Drawing.Point(100, 100)
    $BtnOK.Size = New-Object System.Drawing.Size(100, 35)
    $BtnOK.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
    $BtnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK

    # Snooze Button
    $BtnSnooze = New-Object System.Windows.Forms.Button
    $BtnSnooze.Text = "Snooze (1 Hour)"
    $BtnSnooze.Location = New-Object System.Drawing.Point(220, 100)
    $BtnSnooze.Size = New-Object System.Drawing.Size(140, 35)
    $BtnSnooze.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $BtnSnooze.DialogResult = [System.Windows.Forms.DialogResult]::No # Mapped to 'No' to differentiate from 'Cancel'/'X'

    $Form.Controls.Add($Label)
    $Form.Controls.Add($BtnOK)
    $Form.Controls.Add($BtnSnooze)

    # Show window and capture selection
    $Selection = $Form.ShowDialog()

    # --- ACTION EVALUATION ---
    
    if ($Selection -eq [System.Windows.Forms.DialogResult]::OK) {
        # User explicitly clicked OK -> Break the loop and proceed to installation
        if (Test-Path $SnoozeFile) { Remove-Item $SnoozeFile -Force }
        Write-Host "User clicked OK. Proceeding to uninstallation."
        break
    }
    
    if ($Selection -eq [System.Windows.Forms.DialogResult]::No) {
        # User explicitly clicked Snooze -> Write file and stop execution completely
        $ResumeTime = (Get-Date).AddHours(1).ToString("o")
        Set-Content -Path $SnoozeFile -Value $ResumeTime
        Write-Host "Snooze button clicked. Action deferred until $ResumeTime. Stopping script."
        Exit 0
    }

    # IF THEY CLICKED THE 'X' CROSS BUTTON:
    # The selection evaluates to 'Cancel'. The script will hit this line, ignore it, 
    # and the while($true) loop will instantly redraw the window on screen!
    Write-Host "User closed window with X. Relaunching popup..."
}


# 3. CORE UNINSTALLATION COMMAND BLOCKS (Wrapped safely outside the loop)
Write-Host "Commencing file uninstallation steps..."

function Invoke-OfficeConfig {
    param ([string]$XmlName)
    $XmlPath = Join-Path $ScriptDir $XmlName
    if (Test-Path $SetupExe) {
        Start-Process -FilePath $SetupExe -ArgumentList "/configure `"$XmlPath`"" -Wait -NoNewWindow
    }
}

if (Test-Path "$Prog86\Microsoft Office\root\Office16\Visio.exe") { Invoke-OfficeConfig "RemoveVisioStd.xml" }
if (Test-Path "$Prog64\Microsoft Office\root\Office16\Visio.exe") { Invoke-OfficeConfig "RemoveVisioStd.xml" }

if (Test-Path "$Prog86\Microsoft Office\root\Office16\Winproj.exe") { Invoke-OfficeConfig "Uninstall-ProjStdXVolume.xml" }
if (Test-Path "$Prog64\Microsoft Office\root\Office16\Winproj.exe") { Invoke-OfficeConfig "Uninstall-ProjStdXVolume.xml" }

$MsiSetup86 = "C:\Program Files (x86)\Common Files\Microsoft Shared\OFFICE16\Office Setup Controller\setup.exe"
$MsiSetup64 = "C:\Program Files\Common Files\Microsoft Shared\OFFICE16\Office Setup Controller\setup.exe"
$MsiConfig  = Join-Path $ScriptDir "O2016\remove2016.xml"

if (Test-Path $MsiSetup86) { Start-Process -FilePath $MsiSetup86 -ArgumentList "/uninstall PROPLUS /config `"$MsiConfig`"" -Wait -NoNewWindow }
if (Test-Path $MsiSetup64) { Start-Process -FilePath $MsiSetup64 -ArgumentList "/uninstall PROPLUS /config `"$MsiConfig`"" -Wait -NoNewWindow }

if (Test-Path "$Prog86\Microsoft Office\root\Office16\winproj.exe") { Invoke-OfficeConfig "removeprj.xml" }
if (Test-Path "$Prog86\Microsoft Office\root\Office16\Visio.exe")  { Invoke-OfficeConfig "RemoveVisioStd2021.xml" }
if (Test-Path "$Prog86\Microsoft Office\root\Office16\outlook.exe")    { Invoke-OfficeConfig "remove.xml" }

# INSTALL THE NEW MICROSOFT OFFICE PACKAGE
Invoke-OfficeConfig "configuration.xml"
Exit 0
