Set objShell = CreateObject("WScript.Shell")
Set objFSO = CreateObject("Scripting.FileSystemObject")

' Get the exact folder where this VBScript is saved
strScriptDir = objFSO.GetParentFolderName(WScript.ScriptFullName)

strPath = strScriptDir & "\ServiceUI.exe"
strPS = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
strScript = strScriptDir & "\Start-Upgrade6.ps1"

' Launches ServiceUI hidden (0) and waits for it to finish (True)
Dim exitCode
exitCode = objShell.Run("""" & strPath & """ -process:explorer.exe """ & strPS & """ -WindowStyle Hidden -NoProfile -ExecutionPolicy Bypass -File """ & strScript & """", 0, True)

' Passes the 1618 snooze code or 0 success code back to Intune cleanly
WScript.Quit(exitCode)

