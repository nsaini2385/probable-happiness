Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# 1. SETUP ENVIRONMENT CONFIGURATION PATHS
$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Definition
$SnoozeFile  = Join-Path $env:ProgramData "OfficeUpgradeSnooze.txt"
$SetupExe    = Join-Path $ScriptDir "setup.exe"
$Prog86      = ${env:ProgramFiles(x86)}
$Prog64      = ${env:ProgramFiles}

# --- BYPASS SNOOZE IF TESTING MANUALLY ---
if (Test-Path $SnoozeFile) {
    if ([Environment]::UserInteractive -eq $false -or $env:USERNAME -eq "SYSTEM") {
        $SnoozeTime = Get-Date (Get-Content $SnoozeFile)
        if ((Get-Date) -lt $SnoozeTime) {
            Write-Host "Snooze window active until $SnoozeTime. Exiting gracefully."
            Exit 0
        }
    }
}

# 2. PERSISTENT SYSTEM LOOP
while ($true) {

    # Render Custom Graphical User Interface
    $Form = New-Object System.Windows.Forms.Form
    $Form.Text = "Mandatory Action Required"
    $Form.Size = New-Object System.Drawing.Size(450, 210)
    $Form.StartPosition = "CenterScreen"
    $Form.FormBorderStyle = "FixedDialog"
    $Form.MaximizeBox = $false
    $Form.MinimizeBox = $false
    $Form.TopMost = $true

    # Message Layout
    $Label = New-Object System.Windows.Forms.Label
    $Label.Text = "A new version of Microsoft Office is now ready to be installed on your device.As part of this installation, your current version will need to be uninstalled.`n`nWhen you are ready to have this happen, please save your work and then click on the OK button below"
    $Label.Location = New-Object System.Drawing.Point(25, 20)
    $Label.Size = New-Object System.Drawing.Size(385, 80)
    $Label.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    # OK Button
    $BtnOK = New-Object System.Windows.Forms.Button
    $BtnOK.Text = "OK"
    $BtnOK.Location = New-Object System.Drawing.Point(85, 115)
    $BtnOK.Size = New-Object System.Drawing.Size(120, 32)
    $BtnOK.Font = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold)
    $BtnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK

    # Snooze Button
    $BtnSnooze = New-Object System.Windows.Forms.Button
    $BtnSnooze.Text = "Snooze (1 Hour)"
    $BtnSnooze.Location = New-Object System.Drawing.Point(220, 115)
    $BtnSnooze.Size = New-Object System.Drawing.Size(135, 32)
    $BtnSnooze.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
    $BtnSnooze.DialogResult = [System.Windows.Forms.DialogResult]::No

    $Form.Controls.Add($Label)
    $Form.Controls.Add($BtnOK)
    $Form.Controls.Add($BtnSnooze)

    # Show window and capture selection
    $Selection = $Form.ShowDialog()

    # --- ACTION EVALUATION ---
    if ($Selection -eq [System.Windows.Forms.DialogResult]::OK) {
        if (Test-Path $SnoozeFile) { Remove-Item $SnoozeFile -Force }
        Write-Host "User clicked OK. Proceeding to uninstallation."
        break
    }
    
    if ($Selection -eq [System.Windows.Forms.DialogResult]::No) {
        $ResumeTime = (Get-Date).AddHours(1).ToString("o")
        Set-Content -Path $SnoozeFile -Value $ResumeTime
        Write-Host "Snooze button clicked. Action deferred until $ResumeTime. Stopping script."
        Exit 0
    }

    # Hitting 'X' triggers Cancel, skipping the conditions above so the loop instantly redraws the window
    Write-Host "User closed window with X. Relaunching popup..."
}

# 3. CORE UNINSTALLATION COMMAND BLOCKS
Write-Host "Commencing file uninstallation steps..."

function Invoke-OfficeConfig {
    param ([string]$XmlName)
    $XmlPath = Join-Path $ScriptDir $XmlName
    if (Test-Path $SetupExe) {
        Start-Process -FilePath $SetupExe -ArgumentList "/configure `"$XmlPath`"" -Wait -NoNewWindow
    }
}

if (Test-Path "$Prog86\Microsoft Office\root\Office16\Visio.exe") { Invoke-OfficeConfig "RemoveVisioStd.xml" }
if (Test-Path "$Prog64\Microsoft Office\root\Office16\Visio.exe") { Invoke-OfficeConfig "RemoveVisioStd.xml" }

if (Test-Path "$Prog86\Microsoft Office\root\Office16\Winproj.exe") { Invoke-OfficeConfig "Uninstall-ProjStdXVolume.xml" }
if (Test-Path "$Prog64\Microsoft Office\root\Office16\Winproj.exe") { Invoke-OfficeConfig "Uninstall-ProjStdXVolume.xml" }

$MsiSetup86 = "C:\Program Files (x86)\Common Files\Microsoft Shared\OFFICE16\Office Setup Controller\setup.exe"
$MsiSetup64 = "C:\Program Files\Common Files\Microsoft Shared\OFFICE16\Office Setup Controller\setup.exe"
$MsiConfig  = Join-Path $ScriptDir "O2016\remove2016.xml"

if (Test-Path $MsiSetup86) { Start-Process -FilePath $MsiSetup86 -ArgumentList "/uninstall PROPLUS /config `"$MsiConfig`"" -Wait -NoNewWindow }
if (Test-Path $MsiSetup64) { Start-Process -FilePath $MsiSetup64 -ArgumentList "/uninstall PROPLUS /config `"$MsiConfig`"" -Wait -NoNewWindow }

if (Test-Path "$Prog86\Microsoft Office\root\Office16\winproj.exe") { Invoke-OfficeConfig "removeprj.xml" }
if (Test-Path "$Prog86\Microsoft Office\root\Office16\Visio.exe")  { Invoke-OfficeConfig "RemoveVisioStd2021.xml" }
if (Test-Path "$Prog86\Microsoft Office\root\Office16\outlook.exe")    { Invoke-OfficeConfig "remove.xml" }

# 4. INSTALL THE NEW MICROSOFT OFFICE PACKAGE
#Invoke-OfficeConfig "configuration.xml"
Exit 0
