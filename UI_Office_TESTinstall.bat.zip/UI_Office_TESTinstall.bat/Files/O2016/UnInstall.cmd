@echo off
cd /d "%~dp0"
setup.exe /configure remove.xml
