@echo off
If NOT Exist "%WINDIR%\DEBUG\" (mkdir "%WINDIR%\DEBUG\")
setup.exe /adminfile ITSSOff16Install2.MSP