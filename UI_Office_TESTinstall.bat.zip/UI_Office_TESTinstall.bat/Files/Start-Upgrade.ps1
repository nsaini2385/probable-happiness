Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.MessageBox]::Show("Your computer is about to upgrade Microsoft Office. Office 2016 will be removed, and Microsoft 365 Apps will be installed. Please save your work.
The installation will start once you click OK.", "Microsoft Office Upgrade", "OK", "Information")
