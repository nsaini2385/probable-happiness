Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# 1. SETUP ENVIRONMENT CONFIGURATION PATHS
$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Definition
$SnoozeFile  = Join-Path $env:ProgramData "OfficeUpgradeSnooze.txt"
$CountFile   = Join-Path $env:ProgramData "OfficeUpgradeCount.txt"   # Track snooze attempts
$SetupExe    = Join-Path $ScriptDir "setup.exe"
$Prog86      = ${env:ProgramFiles(x86)}
$Prog64      = ${env:ProgramFiles}

# --- TRACK AND VALIDATE SNOOZE LIMIT ---
$SnoozeCount = 0
if (Test-Path $CountFile) {
    $SnoozeCount = [int](Get-Content $CountFile)
}

# --- BYPASS SNOOZE IF TESTING MANUALLY / CHECK WINDOW ---
if (Test-Path $SnoozeFile) {
    $SnoozeTime = Get-Date (Get-Content $SnoozeFile)
    if ((Get-Date) -lt $SnoozeTime) {
        Write-Host "Snooze window active until $SnoozeTime. Exiting cleanly."
        Exit 1618 # Exit 1618 tells Intune "Fast Retry / Deferred", avoiding a Failure state
    }
}

# 2. PERSISTENT SYSTEM LOOP (Forces window to reappear if closed via 'X')
while ($true) {

    # Render Custom Graphical User Interface
    $Form = New-Object System.Windows.Forms.Form
    $Form.Text = "Mandatory Action Required"
    $Form.Size = New-Object System.Drawing.Size(450, 260) 
    $Form.StartPosition = "CenterScreen"
    $Form.FormBorderStyle = "FixedDialog"
    $Form.MaximizeBox = $false
    $Form.MinimizeBox = $false
    $Form.TopMost = $true

    # Message Layout (Displays current snooze counts to the user)
    $Label = New-Object System.Windows.Forms.Label
    if ($SnoozeCount -ge 3) {
        $Label.Text = "A mandatory upgrade to Microsoft Office is required immediately. Snooze limit reached.`n`nPlease save your work now and click OK to begin the installation."
    } else {
        $Label.Text = "A new version of Microsoft Office is ready to install. Your current version will be uninstalled.`n`nSnooze used: $SnoozeCount of 3 times.`n`nPlease save your work and click OK when ready."
    }
    $Label.Location = New-Object System.Drawing.Point(25, 20)
    $Label.Size = New-Object System.Drawing.Size(385, 120) 
    $Label.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)

    # OK Button
    $BtnOK = New-Object System.Windows.Forms.Button
    $BtnOK.Text = "OK"
    $BtnOK.Location = New-Object System.Drawing.Point(85, 165) 
    $BtnOK.Size = New-Object System.Drawing.Size(120, 32)
    $BtnOK.Font = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold)
    $BtnOK.DialogResult = [System.Windows.Forms.DialogResult]::OK

    # Snooze Button
    $BtnSnooze = New-Object System.Windows.Forms.Button
    $BtnSnooze.Text = "Snooze (1 Hour)"
    $BtnSnooze.Location = New-Object System.Drawing.Point(220, 165) 
    $BtnSnooze.Size = New-Object System.Drawing.Size(135, 32)
    $BtnSnooze.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
    $BtnSnooze.DialogResult = [System.Windows.Forms.DialogResult]::No

    # Disable the Snooze button entirely if they reached the limit
    if ($SnoozeCount -ge 3) {
        $BtnSnooze.Enabled = $false
        # Remove Close 'X' control option entirely to force compliance when maxed out
        $Form.ControlBox = $false 
    }

    $Form.Controls.Add($Label)
    $Form.Controls.Add($BtnOK)
    $Form.Controls.Add($BtnSnooze)

    # Show window and capture selection
    $Selection = $Form.ShowDialog()

    # --- ACTION EVALUATION ---
    if ($Selection -eq [System.Windows.Forms.DialogResult]::OK) {
        if (Test-Path $SnoozeFile) { Remove-Item $SnoozeFile -Force }
        if (Test-Path $CountFile) { Remove-Item $CountFile -Force }
        Write-Host "User clicked OK or forced install. Proceeding."
        break # Breaks the loop and moves down to the installation blocks
    }
    
    if ($Selection -eq [System.Windows.Forms.DialogResult]::No -and $SnoozeCount -lt 3) {
        # Increment our Snooze limit file
        $SnoozeCount++
        Set-Content -Path $CountFile -Value $SnoozeCount
        
        # Set the 1 hour timer block
        $ResumeTime = (Get-Date).AddHours(1).ToString("o")
        Set-Content -Path $SnoozeFile -Value $ResumeTime
        
        Write-Host "Snooze clicked ($SnoozeCount/3). Action deferred."
        Exit 1618 # Exits cleanly back to Intune agent
    }

    # If execution reaches here, the user hit the 'X' button or closed the window.
    # The loop will naturally repeat and redraw the form.
    Write-Host "User closed window with X. Relaunching popup..."
    Start-Sleep -Seconds 1 # 1-second breather to protect CPU performance from infinite looping crashes
}

# 3. CORE UNINSTALLATION COMMAND BLOCKS
Write-Host "Commencing file uninstallation steps..."

function Invoke-OfficeConfig {
    param ([string]$XmlName)
    $XmlPath = Join-Path $ScriptDir $XmlName
    if (Test-Path $SetupExe) {
        Start-Process -FilePath $SetupExe -ArgumentList "/configure `"$XmlPath`"" -Wait -NoNewWindow
    }
}

if (Test-Path "$Prog86\Microsoft Office\root\Office16\Visio.exe") { Invoke-OfficeConfig "RemoveVisioStd.xml" }
if (Test-Path "$Prog64\Microsoft Office\root\Office16\Visio.exe") { Invoke-OfficeConfig "RemoveVisioStd.xml" }

if (Test-Path "$Prog86\Microsoft Office\root\Office16\Winproj.exe") { Invoke-OfficeConfig "Uninstall-ProjStdXVolume.xml" }
if (Test-Path "$Prog64\Microsoft Office\root\Office16\Winproj.exe") { Invoke-OfficeConfig "Uninstall-ProjStdXVolume.xml" }

$MsiSetup86 = "C:\Program Files (x86)\Common Files\Microsoft Shared\OFFICE16\Office Setup Controller\setup.exe"
$MsiSetup64 = "C:\Program Files\Common Files\Microsoft Shared\OFFICE16\Office Setup Controller\setup.exe"
$MsiConfig  = Join-Path $ScriptDir "O2016\remove2016.xml"

if (Test-Path $MsiSetup86) { Start-Process -FilePath $MsiSetup86 -ArgumentList "/uninstall PROPLUS /config `"$MsiConfig`"" -Wait -NoNewWindow }
if (Test-Path $MsiSetup64) { Start-Process -FilePath $MsiSetup64 -ArgumentList "/uninstall PROPLUS /config `"$MsiConfig`"" -Wait -NoNewWindow }

if (Test-Path "$Prog86\Microsoft Office\root\Office16\winproj.exe") { Invoke-OfficeConfig "removeprj.xml" }
if (Test-Path "$Prog86\Microsoft Office\root\Office16\Visio.exe")  { Invoke-OfficeConfig "RemoveVisioStd2021.xml" }
if (Test-Path "$Prog86\Microsoft Office\root\Office16\outlook.exe")    { Invoke-OfficeConfig "remove.xml" }

# 4. INSTALL THE NEW MICROSOFT OFFICE PACKAGE
Invoke-OfficeConfig "configuration.xml"
Exit 0
