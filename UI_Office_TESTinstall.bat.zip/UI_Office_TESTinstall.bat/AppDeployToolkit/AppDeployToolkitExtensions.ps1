﻿<#
.SYNOPSIS
	This script is a template that allows you to extend the toolkit with your own custom functions.
    # LICENSE #
    PowerShell App Deployment Toolkit - Provides a set of functions to perform common application deployment tasks on Windows.
    Copyright (C) 2017 - Sean Lillis, Dan Cunningham, Muhammad Mashwani, Aman Motazedian.
    This program is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version. This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
    You should have received a copy of the GNU Lesser General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.
.DESCRIPTION
	The script is automatically dot-sourced by the AppDeployToolkitMain.ps1 script.
.NOTES
    Toolkit Exit Code Ranges:
    60000 - 68999: Reserved for built-in exit codes in Deploy-Application.ps1, Deploy-Application.exe, and AppDeployToolkitMain.ps1
    69000 - 69999: Recommended for user customized exit codes in Deploy-Application.ps1
    70000 - 79999: Recommended for user customized exit codes in AppDeployToolkitExtensions.ps1
.LINK
	http://psappdeploytoolkit.com
#>
[CmdletBinding()]
Param (
)

##*===============================================
##* VARIABLE DECLARATION
##*===============================================

# Variables: Script
[string]$appDeployToolkitExtName = 'PSAppDeployToolkitExt'
[string]$appDeployExtScriptFriendlyName = 'App Deploy Toolkit Extensions'
[version]$appDeployExtScriptVersion = [version]'3.8.0'
[string]$appDeployExtScriptDate = '23/09/2019'
[hashtable]$appDeployExtScriptParameters = $PSBoundParameters
[string]$SCCMApplicationIconPath = Join-Path -Path $scriptRoot -ChildPath 'AppDeployToolkitSCCMApplication.ico'

[bool]$isSCCM = $false
Try {
	$SCCMApplication = Get-WmiObject -Namespace "root\ccm\clientSDK" -Class CCM_Application | ? { ($_.EvaluationState -eq 12) -and ($_.Name -like "*$appNameDesc*") }
	if ($SCCMApplication) { 
		$isSCCM = $true
		if (-not (Test-Path $SCCMApplicationIconPath)){
			$bytes = [Convert]::FromBase64String($SCCMApplication.Icon)
			[IO.File]::WriteAllBytes($SCCMApplicationIconPath, $bytes)
		}
	}
}
Catch {
	Write-Log -Message "<error message>. `n$(Resolve-Error)" -Severity 3 -Source ${CmdletName}
}


Add-Type -AssemblyName WindowsFormsIntegration
##*===============================================
##* FUNCTION LISTINGS
##*===============================================

#region Function Show-InstallationWelcome
Function Show-InstallationWelcomeWPF {
<#
.SYNOPSIS
	Show a welcome dialog prompting the user with information about the installation and actions to be performed before the installation can begin.
.DESCRIPTION
	The following prompts can be included in the welcome dialog:
		a) Close the specified running applications, or optionally close the applications without showing a prompt (using the -Silent switch).
		b) Defer the installation a certain number of times, for a certain number of days or until a deadline is reached.
		c) Countdown until applications are automatically closed.
		d) Prevent users from launching the specified applications while the installation is in progress.
	Notes:
		The process descriptions are retrieved from WMI, with a fall back on the process name if no description is available. Alternatively, you can specify the description yourself with a '=' symbol - see examples.
		The dialog box will timeout after the timeout specified in the XML configuration file (default 1 hour and 55 minutes) to prevent SCCM installations from timing out and returning a failure code to SCCM. When the dialog times out, the script will exit and return a 1618 code (SCCM fast retry code).
.PARAMETER CloseApps
	Name of the process to stop (do not include the .exe). Specify multiple processes separated by a comma. Specify custom descriptions like this: "winword=Microsoft Office Word,excel=Microsoft Office Excel"
.PARAMETER Silent
	Stop processes without prompting the user.
.PARAMETER CloseAppsCountdown
	Option to provide a countdown in seconds until the specified applications are automatically closed. This only takes effect if deferral is not allowed or has expired.
.PARAMETER ForceCloseAppsCountdown
	Option to provide a countdown in seconds until the specified applications are automatically closed regardless of whether deferral is allowed.
.PARAMETER PromptToSave
	Specify whether to prompt to save working documents when the user chooses to close applications by selecting the "Close Programs" button. Option does not work in SYSTEM context unless toolkit launched with "psexec.exe -s -i" to run it as an interactive process under the SYSTEM account.
.PARAMETER PersistPrompt
	Specify whether to make the prompt persist in the center of the screen every couple of seconds, specified in the AppDeployToolkitConfig.xml. The user will have no option but to respond to the prompt. This only takes effect if deferral is not allowed or has expired.
.PARAMETER BlockExecution
	Option to prevent the user from launching the process/application during the installation.
.PARAMETER AllowDefer
	Enables an optional defer button to allow the user to defer the installation.
.PARAMETER AllowDeferCloseApps
	Enables an optional defer button to allow the user to defer the installation only if there are running applications that need to be closed.
.PARAMETER DeferTimes
	Specify the number of times the installation can be deferred.
.PARAMETER DeferDays
	Specify the number of days since first run that the installation can be deferred. This is converted to a deadline.
.PARAMETER DeferDeadline
	Specify the deadline date until which the installation can be deferred.
	Specify the date in the local culture if the script is intended for that same culture.
	If the script is intended to run on EN-US machines, specify the date in the format: "08/25/2013" or "08-25-2013" or "08-25-2013 18:00:00"
	If the script is intended for multiple cultures, specify the date in the universal sortable date/time format: "2013-08-22 11:51:52Z"
	The deadline date will be displayed to the user in the format of their culture.
.PARAMETER CheckDiskSpace
	Specify whether to check if there is enough disk space for the installation to proceed.
	If this parameter is specified without the RequiredDiskSpace parameter, the required disk space is calculated automatically based on the size of the script source and associated files.
.PARAMETER RequiredDiskSpace
	Specify required disk space in MB, used in combination with CheckDiskSpace.
.PARAMETER MinimizeWindows
	Specifies whether to minimize other windows when displaying prompt. Default: $true.
.PARAMETER TopMost
	Specifies whether the windows is the topmost window. Default: $true.
.PARAMETER ForceCountdown
	Specify a countdown to display before automatically proceeding with the installation when a deferral is enabled.
.PARAMETER CustomText
	Specify whether to display a custom message specified in the XML file. Custom message must be populated for each language section in the XML.
.EXAMPLE
	Show-InstallationWelcome -CloseApps 'iexplore,winword,excel'
	Prompt the user to close Internet Explorer, Word and Excel.
.EXAMPLE
	Show-InstallationWelcome -CloseApps 'winword,excel' -Silent
	Close Word and Excel without prompting the user.
.EXAMPLE
	Show-InstallationWelcome -CloseApps 'winword,excel' -BlockExecution
	Close Word and Excel and prevent the user from launching the applications while the installation is in progress.
.EXAMPLE
	Show-InstallationWelcome -CloseApps 'winword=Microsoft Office Word,excel=Microsoft Office Excel' -CloseAppsCountdown 600
	Prompt the user to close Word and Excel, with customized descriptions for the applications and automatically close the applications after 10 minutes.
.EXAMPLE
	Show-InstallationWelcome -CloseApps 'winword,msaccess,excel' -PersistPrompt
	Prompt the user to close Word, MSAccess and Excel.
	By using the PersistPrompt switch, the dialog will return to the center of the screen every couple of seconds, specified in the AppDeployToolkitConfig.xml, so the user cannot ignore it by dragging it aside.
.EXAMPLE
	Show-InstallationWelcome -AllowDefer -DeferDeadline '25/08/2013'
	Allow the user to defer the installation until the deadline is reached.
.EXAMPLE
	Show-InstallationWelcome -CloseApps 'winword,excel' -BlockExecution -AllowDefer -DeferTimes 10 -DeferDeadline '25/08/2013' -CloseAppsCountdown 600
	Close Word and Excel and prevent the user from launching the applications while the installation is in progress.
	Allow the user to defer the installation a maximum of 10 times or until the deadline is reached, whichever happens first.
	When deferral expires, prompt the user to close the applications and automatically close them after 10 minutes.
.NOTES
.LINK
	http://psappdeploytoolkit.com
#>
	[CmdletBinding(DefaultParametersetName='None')]

	Param (
		## Specify process names separated by commas. Optionally specify a process description with an equals symbol, e.g. "winword=Microsoft Office Word"
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[string]$CloseApps,
		## Specify whether to prompt user or force close the applications
		[Parameter(Mandatory=$false)]
		[switch]$Silent = $false,
		## Specify a countdown to display before automatically closing applications where deferral is not allowed or has expired
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$CloseAppsCountdown = 0,
		## Specify a countdown to display before automatically closing applications whether or not deferral is allowed
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$ForceCloseAppsCountdown = 0,
		## Specify whether to prompt to save working documents when the user chooses to close applications by selecting the "Close Programs" button
		[Parameter(Mandatory=$false)]
		[switch]$PromptToSave = $false,
		## Specify whether to make the prompt persist in the center of the screen every couple of seconds, specified in the AppDeployToolkitConfig.xml.
		[Parameter(Mandatory=$false)]
		[switch]$PersistPrompt = $false,
		## Specify whether to block execution of the processes during installation
		[Parameter(Mandatory=$false)]
		[switch]$BlockExecution = $false,
		## Specify whether to enable the optional defer button on the dialog box
		[Parameter(Mandatory=$false)]
		[switch]$AllowDefer = $false,
		## Specify whether to enable the optional defer button on the dialog box only if an app needs to be closed
		[Parameter(Mandatory=$false)]
		[switch]$AllowDeferCloseApps = $false,
		## Specify the number of times the deferral is allowed
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$DeferTimes = 0,
		## Specify the number of days since first run that the deferral is allowed
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$DeferDays = 0,
		## Specify the deadline (in format dd/mm/yyyy) for which deferral will expire as an option
		[Parameter(Mandatory=$false)]
		[string]$DeferDeadline = '',
		## Specify whether to check if there is enough disk space for the installation to proceed. If this parameter is specified without the RequiredDiskSpace parameter, the required disk space is calculated automatically based on the size of the script source and associated files.
		[Parameter(ParameterSetName = "CheckDiskSpaceParameterSet",Mandatory=$true)]
		[ValidateScript({$_.IsPresent -eq ($true -or $false)})]
		[switch]$CheckDiskSpace,
		## Specify required disk space in MB, used in combination with $CheckDiskSpace.
		[Parameter(ParameterSetName = "CheckDiskSpaceParameterSet",Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$RequiredDiskSpace = 0,
		## Specify whether to minimize other windows when displaying prompt
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[boolean]$MinimizeWindows = $true,
		## Specifies whether the window is the topmost window
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[boolean]$TopMost = $true,
		## Specify a countdown to display before automatically proceeding with the installation when a deferral is enabled
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$ForceCountdown = 0,
		## Specify whether to display a custom message specified in the XML file. Custom message must be populated for each language section in the XML.
		[Parameter(Mandatory=$false)]
		[switch]$CustomText = $false
	)

	Begin {
		## Get the name of this function and write header
		[string]${CmdletName} = $PSCmdlet.MyInvocation.MyCommand.Name
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -CmdletBoundParameters $PSBoundParameters -Header
	}
	Process {
		## If running in NonInteractive mode, force the processes to close silently
		If ($deployModeNonInteractive) { $Silent = $true }

		## If using Zero-Config MSI Deployment, append any executables found in the MSI to the CloseApps list
		If ($useDefaultMsi) { $CloseApps = "$CloseApps,$defaultMsiExecutablesList" }

		## Check disk space requirements if specified
		If ($CheckDiskSpace) {
			Write-Log -Message 'Evaluate disk space requirements.' -Source ${CmdletName}
			[double]$freeDiskSpace = Get-FreeDiskSpace
			If ($RequiredDiskSpace -eq 0) {
				Try {
					#  Determine the size of the Files folder
					$fso = New-Object -ComObject 'Scripting.FileSystemObject' -ErrorAction 'Stop'
					$RequiredDiskSpace = [math]::Round((($fso.GetFolder($scriptParentPath).Size) / 1MB))
				}
				Catch {
					Write-Log -Message "Failed to calculate disk space requirement from source files. `n$(Resolve-Error)" -Severity 3 -Source ${CmdletName}
				}
			}
			If ($freeDiskSpace -lt $RequiredDiskSpace) {
				Write-Log -Message "Failed to meet minimum disk space requirement. Space Required [$RequiredDiskSpace MB], Space Available [$freeDiskSpace MB]." -Severity 3 -Source ${CmdletName}
				If (-not $Silent) {
					Show-InstallationPrompt -Message ($configDiskSpaceMessage -f $installTitle, $RequiredDiskSpace, ($freeDiskSpace)) -ButtonRightText 'OK' -Icon 'Error'
				}
				Exit-Script -ExitCode $configInstallationUIExitCode
			}
			Else {
				Write-Log -Message 'Successfully passed minimum disk space requirement check.' -Source ${CmdletName}
			}
		}

		If ($CloseApps) {
			## Create a Process object with custom descriptions where they are provided (split on an '=' sign)
			[psobject[]]$processObjects = @()
			#  Split multiple processes on a comma, then split on equal sign, then create custom object with process name and description
			ForEach ($process in ($CloseApps -split ',' | Where-Object { $_ })) {
				If ($process.Contains('=')) {
					[string[]]$ProcessSplit = $process -split '='
					$processObjects += New-Object -TypeName 'PSObject' -Property @{
						ProcessName = $ProcessSplit[0]
						ProcessDescription = $ProcessSplit[1]
					}
				}
				Else {
					[string]$ProcessInfo = $process
					$processObjects += New-Object -TypeName 'PSObject' -Property @{
						ProcessName = $process
						ProcessDescription = ''
					}
				}
			}
		}

		## Check Deferral history and calculate remaining deferrals
		If (($allowDefer) -or ($AllowDeferCloseApps)) {
			#  Set $allowDefer to true if $AllowDeferCloseApps is true
			$allowDefer = $true

			#  Get the deferral history from the registry
			$deferHistory = Get-DeferHistory
			$deferHistoryTimes = $deferHistory | Select-Object -ExpandProperty 'DeferTimesRemaining' -ErrorAction 'SilentlyContinue'
			$deferHistoryDeadline = $deferHistory | Select-Object -ExpandProperty 'DeferDeadline' -ErrorAction 'SilentlyContinue'

			#  Reset Switches
			$checkDeferDays = $false
			$checkDeferDeadline = $false
			If ($DeferDays -ne 0) { $checkDeferDays = $true }
			If ($DeferDeadline) { $checkDeferDeadline = $true }
			If ($DeferTimes -ne 0) {
				If ($deferHistoryTimes -ge 0) {
					Write-Log -Message "Defer history shows [$($deferHistory.DeferTimesRemaining)] deferrals remaining." -Source ${CmdletName}
					$DeferTimes = $deferHistory.DeferTimesRemaining - 1
				}
				Else {
					$DeferTimes = $DeferTimes - 1
				}
				Write-Log -Message "User has [$deferTimes] deferrals remaining." -Source ${CmdletName}
				If ($DeferTimes -lt 0) {
					Write-Log -Message 'Deferral has expired.' -Source ${CmdletName}
					$AllowDefer = $false
				}
			}
			Else {
				If (Test-Path -LiteralPath 'variable:deferTimes') { Remove-Variable -Name 'deferTimes' }
				$DeferTimes = $null
			}
			If ($checkDeferDays -and $allowDefer) {
				If ($deferHistoryDeadline) {
					Write-Log -Message "Defer history shows a deadline date of [$deferHistoryDeadline]." -Source ${CmdletName}
					[string]$deferDeadlineUniversal = Get-UniversalDate -DateTime $deferHistoryDeadline
				}
				Else {
					[string]$deferDeadlineUniversal = Get-UniversalDate -DateTime (Get-Date -Date ((Get-Date).AddDays($deferDays)) -Format ($culture).DateTimeFormat.UniversalDateTimePattern).ToString()
				}
				Write-Log -Message "User has until [$deferDeadlineUniversal] before deferral expires." -Source ${CmdletName}
				If ((Get-UniversalDate) -gt $deferDeadlineUniversal) {
					Write-Log -Message 'Deferral has expired.' -Source ${CmdletName}
					$AllowDefer = $false
				}
			}
			If ($checkDeferDeadline -and $allowDefer) {
				#  Validate Date
				Try {
					[string]$deferDeadlineUniversal = Get-UniversalDate -DateTime $deferDeadline -ErrorAction 'Stop'
				}
				Catch {
					Write-Log -Message "Date is not in the correct format for the current culture. Type the date in the current locale format, such as 20/08/2014 (Europe) or 08/20/2014 (United States). If the script is intended for multiple cultures, specify the date in the universal sortable date/time format, e.g. '2013-08-22 11:51:52Z'. `n$(Resolve-Error)" -Severity 3 -Source ${CmdletName}
					Throw "Date is not in the correct format for the current culture. Type the date in the current locale format, such as 20/08/2014 (Europe) or 08/20/2014 (United States). If the script is intended for multiple cultures, specify the date in the universal sortable date/time format, e.g. '2013-08-22 11:51:52Z': $($_.Exception.Message)"
				}
				Write-Log -Message "User has until [$deferDeadlineUniversal] remaining." -Source ${CmdletName}
				If ((Get-UniversalDate) -gt $deferDeadlineUniversal) {
					Write-Log -Message 'Deferral has expired.' -Source ${CmdletName}
					$AllowDefer = $false
				}
			}
		}
		If (($deferTimes -lt 0) -and (-not ($deferDeadlineUniversal))) { $AllowDefer = $false }

		## Prompt the user to close running applications and optionally defer if enabled
		If (-not ($deployModeSilent) -and (-not ($silent))) {
			If ($forceCloseAppsCountdown -gt 0) {
				#  Keep the same variable for countdown to simplify the code:
				$closeAppsCountdown = $forceCloseAppsCountdown
				#  Change this variable to a boolean now to switch the countdown on even with deferral
				[boolean]$forceCloseAppsCountdown = $true
			}
			ElseIf ($forceCountdown -gt 0){
				#  Keep the same variable for countdown to simplify the code:
				$closeAppsCountdown = $forceCountdown
				#  Change this variable to a boolean now to switch the countdown on
				[boolean]$forceCountdown = $true
			}
			Set-Variable -Name 'closeAppsCountdownGlobal' -Value $closeAppsCountdown -Scope 'Script'

			While ((Get-RunningProcesses -ProcessObjects $processObjects -OutVariable 'runningProcesses') -or (($promptResult -ne 'Defer') -and ($promptResult -ne 'Close'))) {
				[string]$runningProcessDescriptions = ($runningProcesses | Where-Object { $_.ProcessDescription } | Select-Object -ExpandProperty 'ProcessDescription' | Select-Object -Unique | Sort-Object) -join ','
				#  Check if we need to prompt the user to defer, to defer and close apps, or not to prompt them at all
				If ($allowDefer) {
					#  If there is deferral and closing apps is allowed but there are no apps to be closed, break the while loop
					If ($AllowDeferCloseApps -and (-not $runningProcessDescriptions)) {
						Break
					}
					#  Otherwise, as long as the user has not selected to close the apps or the processes are still running and the user has not selected to continue, prompt user to close running processes with deferral
					ElseIf (($promptResult -ne 'Close') -or (($runningProcessDescriptions) -and ($promptResult -ne 'Continue'))) {
						[string]$promptResult = Show-WelcomePromptWPF -ProcessDescriptions $runningProcessDescriptions -CloseAppsCountdown $closeAppsCountdownGlobal -ForceCloseAppsCountdown $forceCloseAppsCountdown -ForceCountdown $forceCountdown -PersistPrompt $PersistPrompt -AllowDefer -DeferTimes $deferTimes -DeferDeadline $deferDeadlineUniversal -MinimizeWindows $MinimizeWindows -CustomText:$CustomText -TopMost $TopMost
					}
				}
				#  If there is no deferral and processes are running, prompt the user to close running processes with no deferral option
				ElseIf (($runningProcessDescriptions) -or ($forceCountdown)) {
					[string]$promptResult = Show-WelcomePromptWPF -ProcessDescriptions $runningProcessDescriptions -CloseAppsCountdown $closeAppsCountdownGlobal -ForceCloseAppsCountdown $forceCloseAppsCountdown -ForceCountdown $forceCountdown -PersistPrompt $PersistPrompt -MinimizeWindows $minimizeWindows -CustomText:$CustomText -TopMost $TopMost
				}
				#  If there is no deferral and no processes running, break the while loop
				Else {
					Break
				}

				#  If the user has clicked OK, wait a few seconds for the process to terminate before evaluating the running processes again
				If ($promptResult -eq 'Continue') {
					Write-Log -Message 'User selected to continue...' -Source ${CmdletName}
					Start-Sleep -Seconds 2

					#  Break the while loop if there are no processes to close and the user has clicked OK to continue
					If (-not $runningProcesses) { Break }
				}
				#  Force the applications to close
				ElseIf ($promptResult -eq 'Close') {
					Write-Log -Message 'User selected to force the application(s) to close...' -Source ${CmdletName}
					If (($PromptToSave) -and ($SessionZero -and (-not $IsProcessUserInteractive))) {
						Write-Log -Message 'Specified [-PromptToSave] option will not be available because current process is running in session zero and is not interactive.' -Severity 2 -Source ${CmdletName}
					}

					ForEach ($runningProcess in $runningProcesses) {
						[psobject[]]$AllOpenWindowsForRunningProcess = Get-WindowTitle -GetAllWindowTitles -DisableFunctionLogging | Where-Object { $_.ParentProcess -eq $runningProcess.Name }
						#  If the PromptToSave parameter was specified and the process has a window open, then prompt the user to save work if there is work to be saved when closing window
						If (($PromptToSave) -and (-not ($SessionZero -and (-not $IsProcessUserInteractive))) -and ($AllOpenWindowsForRunningProcess) -and ($runningProcess.MainWindowHandle -ne [IntPtr]::Zero)) {
							[timespan]$PromptToSaveTimeout = New-TimeSpan -Seconds $configInstallationPromptToSave
							[Diagnostics.StopWatch]$PromptToSaveStopWatch = [Diagnostics.StopWatch]::StartNew()
							$PromptToSaveStopWatch.Reset()
							ForEach ($OpenWindow in $AllOpenWindowsForRunningProcess) {
								Try {
									Write-Log -Message "Stop process [$($runningProcess.Name)] with window title [$($OpenWindow.WindowTitle)] and prompt to save if there is work to be saved (timeout in [$configInstallationPromptToSave] seconds)..." -Source ${CmdletName}
									[boolean]$IsBringWindowToFrontSuccess = [PSADT.UiAutomation]::BringWindowToFront($OpenWindow.WindowHandle)
									[boolean]$IsCloseWindowCallSuccess = $runningProcess.CloseMainWindow()
									If (-not $IsCloseWindowCallSuccess) {
										Write-Log -Message "Failed to call the CloseMainWindow() method on process [$($runningProcess.Name)] with window title [$($OpenWindow.WindowTitle)] because the main window may be disabled due to a modal dialog being shown." -Severity 3 -Source ${CmdletName}
									}
									Else {
										$PromptToSaveStopWatch.Start()
										Do {
											[boolean]$IsWindowOpen = [boolean](Get-WindowTitle -GetAllWindowTitles -DisableFunctionLogging | Where-Object { $_.WindowHandle -eq $OpenWindow.WindowHandle })
											If (-not $IsWindowOpen) { Break }
											Start-Sleep -Seconds 3
										} While (($IsWindowOpen) -and ($PromptToSaveStopWatch.Elapsed -lt $PromptToSaveTimeout))
										$PromptToSaveStopWatch.Reset()
										If ($IsWindowOpen) {
											Write-Log -Message "Exceeded the [$configInstallationPromptToSave] seconds timeout value for the user to save work associated with process [$($runningProcess.Name)] with window title [$($OpenWindow.WindowTitle)]." -Severity 2 -Source ${CmdletName}
										}
										Else {
											Write-Log -Message "Window [$($OpenWindow.WindowTitle)] for process [$($runningProcess.Name)] was successfully closed." -Source ${CmdletName}
										}
									}
								}
								Catch {
									Write-Log -Message "Failed to close window [$($OpenWindow.WindowTitle)] for process [$($runningProcess.Name)]. `n$(Resolve-Error)" -Severity 3 -Source ${CmdletName}
									Continue
								}
								Finally {
									$runningProcess.Refresh()
								}
							}
						}
						Else {
							Write-Log -Message "Stop process $($runningProcess.Name)..." -Source ${CmdletName}
							Stop-Process -Id $runningProcess.Id -Force -ErrorAction 'SilentlyContinue'
						}
					}
					Start-Sleep -Seconds 2
				}
				#  Stop the script (if not actioned before the timeout value)
				ElseIf ($promptResult -eq 'Timeout') {
					Write-Log -Message 'Installation not actioned before the timeout value.' -Source ${CmdletName}
					$BlockExecution = $false

					If (($deferTimes -ge 0) -or ($deferDeadlineUniversal)) {
						Set-DeferHistory -DeferTimesRemaining $DeferTimes -DeferDeadline $deferDeadlineUniversal
					}
					## Dispose the welcome prompt timer here because if we dispose it within the Show-WelcomePrompt function we risk resetting the timer and missing the specified timeout period
					If ($script:welcomeTimer) {
						Try {
							$script:welcomeTimer.Dispose()
							$script:welcomeTimer = $null
						}
						Catch { }
					}

					#  Restore minimized windows
					$null = $shellApp.UndoMinimizeAll()

					Exit-Script -ExitCode $configInstallationUIExitCode
				}
				#  Stop the script (user chose to defer)
				ElseIf ($promptResult -eq 'Defer') {
					Write-Log -Message 'Installation deferred by the user.' -Source ${CmdletName}

					#### Write-Log -Message "$($comboboxRemindMe.SelectedIndex)" -Source ${CmdletName}
					$BlockExecution = $false

					Set-DeferHistory -DeferTimesRemaining $DeferTimes -DeferDeadline $deferDeadlineUniversal

					#  Restore minimized windows
					$null = $shellApp.UndoMinimizeAll()

					Exit-Script -ExitCode $configInstallationDeferExitCode
				}
			}
		}

		## Force the processes to close silently, without prompting the user
		If (($Silent -or $deployModeSilent) -and $CloseApps) {
			[array]$runningProcesses = $null
			[array]$runningProcesses = Get-RunningProcesses $processObjects
			If ($runningProcesses) {
				[string]$runningProcessDescriptions = ($runningProcesses | Where-Object { $_.ProcessDescription } | Select-Object -ExpandProperty 'ProcessDescription' | Select-Object -Unique | Sort-Object) -join ','
				Write-Log -Message "Force close application(s) [$($runningProcessDescriptions)] without prompting user." -Source ${CmdletName}
				$runningProcesses | Stop-Process -Force -ErrorAction 'SilentlyContinue'
				Start-Sleep -Seconds 2
			}
		}

		## Force nsd.exe to stop if Notes is one of the required applications to close
		If (($processObjects | Select-Object -ExpandProperty 'ProcessName') -contains 'notes') {
			## Get the path where Notes is installed
			[string]$notesPath = Get-Item -LiteralPath $regKeyLotusNotes -ErrorAction 'SilentlyContinue' | Get-ItemProperty | Select-Object -ExpandProperty 'Path'

			## Ensure we aren't running as a Local System Account and Notes install directory was found
			If ((-not $IsLocalSystemAccount) -and ($notesPath)) {
				#  Get a list of all the executables in the Notes folder
				[string[]]$notesPathExes = Get-ChildItem -LiteralPath $notesPath -Filter '*.exe' -Recurse | Select-Object -ExpandProperty 'BaseName' | Sort-Object
				## Check for running Notes executables and run NSD if any are found
				$notesPathExes | ForEach-Object {
					If ((Get-Process | Select-Object -ExpandProperty 'Name') -contains $_) {
						[string]$notesNSDExecutable = Join-Path -Path $notesPath -ChildPath 'NSD.exe'
						Try {
							If (Test-Path -LiteralPath $notesNSDExecutable -PathType 'Leaf' -ErrorAction 'Stop') {
								Write-Log -Message "Execute [$notesNSDExecutable] with the -kill argument..." -Source ${CmdletName}
								[Diagnostics.Process]$notesNSDProcess = Start-Process -FilePath $notesNSDExecutable -ArgumentList '-kill' -WindowStyle 'Hidden' -PassThru -ErrorAction 'SilentlyContinue'

								If (-not ($notesNSDProcess.WaitForExit(10000))) {
									Write-Log -Message "[$notesNSDExecutable] did not end in a timely manner. Force terminate process." -Source ${CmdletName}
									Stop-Process -Name 'NSD' -Force -ErrorAction 'SilentlyContinue'
								}
							}
						}
						Catch {
							Write-Log -Message "Failed to launch [$notesNSDExecutable]. `n$(Resolve-Error)" -Source ${CmdletName}
						}

						Write-Log -Message "[$notesNSDExecutable] returned exit code [$($notesNSDProcess.ExitCode)]." -Source ${CmdletName}

						#  Force NSD process to stop in case the previous command was not successful
						Stop-Process -Name 'NSD' -Force -ErrorAction 'SilentlyContinue'
					}
				}
			}

			#  Strip all Notes processes from the process list except notes.exe, because the other notes processes (e.g. notes2.exe) may be invoked by the Notes installation, so we don't want to block their execution.
			If ($notesPathExes) {
				[array]$processesIgnoringNotesExceptions = Compare-Object -ReferenceObject ($processObjects | Select-Object -ExpandProperty 'ProcessName' | Sort-Object) -DifferenceObject $notesPathExes -IncludeEqual | Where-Object { ($_.SideIndicator -eq '<=') -or ($_.InputObject -eq 'notes') } | Select-Object -ExpandProperty 'InputObject'
				[array]$processObjects = $processObjects | Where-Object { $processesIgnoringNotesExceptions -contains $_.ProcessName }
			}
		}

		## If block execution switch is true, call the function to block execution of these processes
		If ($BlockExecution) {
			#  Make this variable globally available so we can check whether we need to call Unblock-AppExecution
			Set-Variable -Name 'BlockExecution' -Value $BlockExecution -Scope 'Script'
			Write-Log -Message '[-BlockExecution] parameter specified.' -Source ${CmdletName}
			Block-AppExecution -ProcessName ($processObjects | Select-Object -ExpandProperty 'ProcessName')
		}
	}
	End {
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -Footer
	}
}
#endregion
	

#region Function Show-WelcomePrompt
Function Show-WelcomePromptWPF {
<#
.SYNOPSIS
	Called by Show-InstallationWelcome to prompt the user to optionally do the following:
		1) Close the specified running applications.
		2) Provide an option to defer the installation.
		3) Show a countdown before applications are automatically closed.
.DESCRIPTION
	The user is presented with a Windows Forms dialog box to close the applications themselves and continue or to have the script close the applications for them.
	If the -AllowDefer option is set to true, an optional "Defer" button will be shown to the user. If they select this option, the script will exit and return a 1618 code (SCCM fast retry code).
	The dialog box will timeout after the timeout specified in the XML configuration file (default 1 hour and 55 minutes) to prevent SCCM installations from timing out and returning a failure code to SCCM. When the dialog times out, the script will exit and return a 1618 code (SCCM fast retry code).
.PARAMETER ProcessDescriptions
	The descriptive names of the applications that are running and need to be closed.
.PARAMETER CloseAppsCountdown
	Specify the countdown time in seconds before running applications are automatically closed when deferral is not allowed or expired.
.PARAMETER ForceCloseAppsCountdown
	Specify whether to show the countdown regardless of whether deferral is allowed.
.PARAMETER PersistPrompt
	Specify whether to make the prompt persist in the center of the screen every couple of seconds, specified in the AppDeployToolkitConfig.xml.
.PARAMETER AllowDefer
	Specify whether to provide an option to defer the installation.
.PARAMETER DeferTimes
	Specify the number of times the user is allowed to defer.
.PARAMETER DeferDeadline
	Specify the deadline date before the user is allowed to defer.
.PARAMETER MinimizeWindows
	Specifies whether to minimize other windows when displaying prompt. Default: $true.
.PARAMETER TopMost
	Specifies whether the windows is the topmost window. Default: $true.
.PARAMETER ForceCountdown
	Specify a countdown to display before automatically proceeding with the installation when a deferral is enabled.
.PARAMETER CustomText
	Specify whether to display a custom message specified in the XML file. Custom message must be populated for each language section in the XML.
.EXAMPLE
	Show-WelcomePrompt -ProcessDescriptions 'Lotus Notes, Microsoft Word' -CloseAppsCountdown 600 -AllowDefer -DeferTimes 10
.NOTES
	This is an internal script function and should typically not be called directly. It is used by the Show-InstallationWelcome prompt to display a custom prompt.
.LINK
	http://psappdeploytoolkit.com
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory=$false)]
		[string]$ProcessDescriptions,
		[Parameter(Mandatory=$false)]
		[int32]$CloseAppsCountdown,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[boolean]$ForceCloseAppsCountdown,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[boolean]$PersistPrompt = $false,
		[Parameter(Mandatory=$false)]
		[switch]$AllowDefer = $false,
		[Parameter(Mandatory=$false)]
		[string]$DeferTimes,
		[Parameter(Mandatory=$false)]
		[string]$DeferDeadline,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[boolean]$MinimizeWindows = $true,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[boolean]$TopMost = $true,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$ForceCountdown = 0,
		[Parameter(Mandatory=$false)]
		[switch]$CustomText = $false
	)

	Begin {
		## Get the name of this function and write header
		[string]${CmdletName} = $PSCmdlet.MyInvocation.MyCommand.Name
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -CmdletBoundParameters $PSBoundParameters -Header
	}
	Process {
		## Reset switches
		[boolean]$showCloseApps = $false
		[boolean]$showDefer = $false
		[boolean]$persistWindow = $false

		## Reset times
		[datetime]$startTime = Get-Date
		[datetime]$countdownTime = $startTime

		## Check if the countdown was specified
		If ($CloseAppsCountdown) {
			If ($CloseAppsCountdown -gt $configInstallationUITimeout) {
				Throw 'The close applications countdown time cannot be longer than the timeout specified in the XML configuration for installation UI dialogs to timeout.'
			}
		}

		## Initial form layout: Close Applications / Allow Deferral
		If ($processDescriptions) {
			Write-Log -Message "Prompt user to close application(s) [$processDescriptions]..." -Source ${CmdletName}
			$showCloseApps = $true
		}
		If (($allowDefer) -and (($deferTimes -ge 0) -or ($deferDeadline))) {
			Write-Log -Message 'User has the option to defer.' -Source ${CmdletName}
			$showDefer = $true
			If ($deferDeadline) {
				#  Remove the Z from universal sortable date time format, otherwise it could be converted to a different time zone
				$deferDeadline = $deferDeadline -replace 'Z',''
				#  Convert the deadline date to a string
				[string]$deferDeadline = (Get-Date -Date $deferDeadline).ToString()
			}
		}

		## If deferral is being shown and 'close apps countdown' or 'persist prompt' was specified, enable those features.
		If (-not $showDefer) {
			If ($closeAppsCountdown -gt 0) {
				Write-Log -Message "Close applications countdown has [$closeAppsCountdown] seconds remaining." -Source ${CmdletName}
				$showCountdown = $true
			}
		}
		If ($showDefer) {
			If ($persistPrompt) { $persistWindow = $true }
		}
		## If 'force close apps countdown' was specified, enable that feature.
		If ($forceCloseAppsCountdown -eq $true) {
			Write-Log -Message "Close applications countdown has [$closeAppsCountdown] seconds remaining." -Source ${CmdletName}
			$showCountdown = $true
		}
		## If 'force countdown' was specified, enable that feature.
		If ($forceCountdown -eq $true) {
			Write-Log -Message "Countdown has [$closeAppsCountdown] seconds remaining." -Source ${CmdletName}
			$showCountdown = $true
		}

		[string[]]$processDescriptions = $processDescriptions -split ','

		[string]$script:welcomeChoice = 'false'

		## Add the timer if it doesn't already exist - this avoids the timer being reset if the continue button is clicked
		If (-not ($script:welcomeTimer)) {
			$script:welcomeTimer = New-Object -TypeName 'System.Windows.Threading.DispatcherTimer'
		}

		# Load XAML form
		[string]$formWelcomeSTR = Get-Content -Path (Join-Path -Path $scriptRoot -ChildPath 'AppDeployToolkitFormWelcome.xaml')
		[xml]$formWelcomeXML = $formWelcomeSTR -replace "x:N",'N' -replace 'mc:Ignorable="d"',''

		[Xml.XmlNode]$node = $formWelcomeXML.SelectSingleNode("//*[@Name='labelAppIcon']")
		$node.Attributes["Source"].Value = $SCCMApplicationIconPath

		$formWelcomeXML.Window.DockPanel.StackPanel.StackPanel.Image.Source = $appDeployLogoBannerWPF

		$formWelcomeXML.Window.Icon = $AppDeployLogoIcon

		# Create XAML form
		Try { 
			$xmlReader = New-Object System.Xml.XmlNodeReader $formWelcomeXML
			$formWelcomeXAML = [Windows.Markup.XamlReader]::Load($xmlReader)
			Write-Log -Message "XAML Form loaded: [$formWelcomeXAML] " -Source ${CmdletName}
		}
		Catch { 
			Write-Log -Message "Unable to parse XAML, with error: $($Error[0])" -Source ${CmdletName}
		}

		# Load XAML Objects
		$formWelcomeXML.SelectNodes("//*[@Name]") | % {
			Try { 
				Set-Variable -Name $($_.Name) -Value $formWelcomeXAML.FindName($_.Name) -ErrorAction Stop 
			}
			Catch { 
				Write-Log -Message "Unable to create variable. Error: $($Error[0])" -Source ${CmdletName}
			}
		}

		## Remove all event handlers from the controls
		[scriptblock]$WelcomeForm_Cleanup_FormClosed = {
			Try {
				$script:welcomeTimer.remove_Tick($timer_Tick)
				$timerPersist.remove_Tick($timerPersist_Tick)
				$timerRunningProcesses.remove_Tick($timerRunningProcesses_Tick)
			}
			Catch { }
		}

		# Declare event scriptblocks
		[scriptblock]$formWelcomeXAML_Loaded = {
			#  Get the start position of the form so we can return the form to this position if PersistPrompt is enabled
			## Set-Variable -Name 'formWelcomeStartPosition' -Value $formWelcomeXAML.Top, $formWelcomeXAML.Left -Scope 'Script'
			[double[]]$script:formWelcomeXAML = $formWelcomeXAML.Top, $formWelcomeXAML.Left
			## Initialize the countdown timer
			[datetime]$currentTime = Get-Date
			[datetime]$countdownTime = $startTime.AddSeconds($CloseAppsCountdown)
			$script:welcomeTimer.Start()

			## Set up the form
			[timespan]$remainingTime = $countdownTime.Subtract($currentTime)
			[string]$labelCountdownSeconds = [string]::Format('{0}:{1:d2}:{2:d2}', $remainingTime.Days * 24 + $remainingTime.Hours, $remainingTime.Minutes, $remainingTime.Seconds)
			If ($forceCountdown -eq $true) {
				If ($deploymentType -ieq 'Install') { $labelCountdown.Text = ($configWelcomePromptCountdownMessage -f $($configDeploymentTypeInstall.ToLower())) + "`n$labelCountdownSeconds" }
				ElseIf ($deploymentType -ieq 'Repair') { $labelCountdown.Text = ($configWelcomePromptCountdownMessage -f $($configDeploymentTypeRepair.ToLower())) + "`n$labelCountdownSeconds" }
				Else { $labelCountdown.Text = ($configWelcomePromptCountdownMessage -f $($configDeploymentTypeUninstall.ToLower())) + "`n$labelCountdownSeconds" }
			}
			Else { $labelCountdown.Text = "$configClosePromptCountdownMessage`n$labelCountdownSeconds" }
		}
		$formWelcomeXAML.add_ContentRendered($formWelcomeXAML_Loaded)
		$formWelcomeXAML.add_Closed($WelcomeForm_Cleanup_FormClosed)

		## Setup form for SCCM
		if ($isSCCM) { 
			$labelAppName.Text = $SCCMApplication.FullName
			$labelAppVendor.Text = "Published by $($SCCMApplication.Publisher)"
			$labelAppVersion.Text = $SCCMApplication.SoftwareVersion
			$formWelcomeXAML.Title = 'Software Center'
			$gridSCCM.Visibility = [Windows.Visibility]::Visible
		}
		else { 
			$formWelcomeXAML.Title = $installTitle
			$gridSCCM.Visibility = [Windows.Visibility]::Collapsed
		}

		Function button_OnClick {
			Param ($choice)
			$script:welcomeChoice = $choice
			$formWelcomeXAML.Close()
		}
		$buttonDefer.add_Click({button_OnClick 'Defer'})
		$buttonCloseApps.add_Click({button_OnClick 'Close'})
		$buttonContinue.add_Click({button_OnClick 'Continue'})

		If ($showCountdown) {
			[scriptblock]$timer_Tick = {
				## Get the time information
				[datetime]$currentTime = Get-Date
				[datetime]$countdownTime = $startTime.AddSeconds($CloseAppsCountdown)
				[timespan]$remainingTime = $countdownTime.Subtract($currentTime)
				Set-Variable -Name 'closeAppsCountdownGlobal' -Value $remainingTime.TotalSeconds -Scope 'Script'

				## If the countdown is complete, close the application(s) or continue
				If ($countdownTime -lt $currentTime) {
					If ($forceCountdown -eq $true) {
						Write-Log -Message 'Countdown timer has elapsed. Force continue.' -Source ${CmdletName}
						$script:welcomeChoice = 'Continue'; $formWelcomeXAML.Close()
					}
					Else {
						Write-Log -Message 'Close application(s) countdown timer has elapsed. Force closing application(s).' -Source ${CmdletName}
						If ($buttonCloseApps.Focusable) { $script:welcomeChoice = 'Close'; $formWelcomeXAML.Close() }
						Else { $script:welcomeChoice = 'Continue'; $formWelcomeXAML.Close() }
					}
				}
				Else {
					#  Update the form
					[string]$labelCountdownSeconds = [string]::Format('{0}:{1:d2}:{2:d2}', $remainingTime.Days * 24 + $remainingTime.Hours, $remainingTime.Minutes, $remainingTime.Seconds)
					If ($forceCountdown -eq $true) {
						If ($deploymentType -ieq 'Install') { $labelCountdown.Text = ($configWelcomePromptCountdownMessage -f $configDeploymentTypeInstall) + "`n$labelCountdownSeconds" }
						ElseIf ($deploymentType -ieq 'Repair') { $labelCountdown.Text = ($configWelcomePromptCountdownMessage -f $configDeploymentTypeRepair) + "`n$labelCountdownSeconds" }
						Else { $labelCountdown.Text = ($configWelcomePromptCountdownMessage -f $configDeploymentTypeUninstall) + "`n$labelCountdownSeconds" }
					}
					Else { $labelCountdown.Text = "$configClosePromptCountdownMessage`n$labelCountdownSeconds" }
				}
			}
		}
		Else {
			$script:welcomeTimer.Interval = ($configInstallationUITimeout * 10000000L)
			[scriptblock]$timer_Tick = { $script:welcomeChoice = 'Timeout'; $formWelcomeXAML.Close() }
		}

		$script:welcomeTimer.add_Tick($timer_Tick)

		## Persistence Timer
		If ($persistWindow) {
			$timerPersist = New-Object -TypeName 'System.Windows.Threading.DispatcherTimer'
			$timerPersist.Interval = ($configInstallationPersistInterval * 10000000L)
			[scriptblock]$timerPersist_Tick = { Update-InstallationWelcome }
			$timerPersist.add_Tick($timerPersist_Tick)
			$timerPersist.Start()
		}

		## Process Re-Enumeration Timer
		If ($configInstallationWelcomePromptDynamicRunningProcessEvaluation) {
			$timerRunningProcesses = New-Object -TypeName 'System.Windows.Threading.DispatcherTimer'
			$timerRunningProcesses.Interval = ($configInstallationWelcomePromptDynamicRunningProcessEvaluationInterval * 10000000L)
			[scriptblock]$timerRunningProcesses_Tick = { try { Get-RunningProcessesDynamically } catch {} }
			$timerRunningProcesses.add_Tick($timerRunningProcesses_Tick)
			$timerRunningProcesses.Start()
		}

		$pictureBanner.Height = $appDeployLogoBannerHeight

		## Initial form layout: Close Applications / Allow Deferral
		If ($showCloseApps) {
			switch ($deploymentType) {
				Install { $labelAppNameText = ($configClosePromptMessage -f $($configDeploymentTypeInstall.ToLower())); break }
				Repair { $labelAppNameText = ($configClosePromptMessage -f $($configDeploymentTypeRepair.ToLower())); break }
				Uninstall { $labelAppNameText = ($configClosePromptMessage -f $($configDeploymentTypeUninstall.ToLower())); break }
				Default {}
			}
			$pictureWelcome.Source = New-Object System.Windows.Media.Imaging.BitmapImage(Join-Path -Path $scriptRoot -ChildPath 'Error.png')
		}
		ElseIf (($showDefer) -or ($forceCountdown)) {
			$labelAppNameText = "$configDeferPromptWelcomeMessage"
			$pictureWelcome.Source = New-Object System.Windows.Media.Imaging.BitmapImage(Join-Path -Path $scriptRoot -ChildPath 'Information.png')
		}
		If ($CustomText) {
			$labelDeferMessage.Text = "$configWelcomePromptCustomMessage `n`n$configDeferPromptExpiryMessage"
		}
		Else{
			$labelDeferMessage.Text = "$configDeferPromptExpiryMessage"
		}
		$labelAppDesc.Text = $labelAppNameText
		## $labelAppName.Text = "$appName `($appRevision`)"

		

		If ($deferTimes -ge 0) {
			$deferralText = "$configDeferPromptRemainingDeferrals $([int32]$deferTimes + 1)"
		}
		If ($deferDeadline) {
			$deferralText = "$configDeferPromptDeadline $deferDeadline"
		}
		If (($deferTimes -lt 0) -and (-not $DeferDeadline)) {
			$deferralText = "$configDeferPromptNoDeadline"
		}
		$labelDeferWarning.Text = "$configDeferPromptWarningMessage"
		$labelDeferRemaining.Text = $deferralText

		$labelCountdown.Text = '00:00:00'

		# $windowMover.add_MouseLeftButtonDown({$formWelcomeXAML.DragMove()})



		$ProcessDescriptions | ForEach-Object { $null = $listboxCloseApps.Items.Add($_) }
		
		If ($showCloseApps) { 
			$gridCloseApps.Visibility = [Windows.Visibility]::Visible
			$buttonCloseApps.Visibility = [Windows.Visibility]::Visible
			$buttonContinue.Visibility = [Windows.Visibility]::Collapsed
			$listBoxCloseApps.IsEnabled = $true
		}
		Else { 
			$gridCloseApps.Visibility = [Windows.Visibility]::Collapsed
			$buttonCloseApps.Visibility = [Windows.Visibility]::Collapsed
			$buttonContinue.Visibility = [Windows.Visibility]::Visible
		}
		If ($showDefer) { 
			$gridDefer.Visibility = [Windows.Visibility]::Visible
			$buttonDefer.Visibility = [Windows.Visibility]::Visible
		}
		Else { 
			$gridDefer.Visibility = [Windows.Visibility]::Collapsed
			$buttonDefer.Visibility = [Windows.Visibility]::Collapsed
		}
		If ($showCountdown) { 
			$gridCountdown.Visibility = [Windows.Visibility]::Visible 
		}
		Else {
			$gridCountdown.Visibility = [Windows.Visibility]::Collapsed
		}


		Function Update-InstallationWelcome {
			$formWelcomeXAML.Top = $script:formWelcomeXAML[0]
			$formWelcomeXAML.Left = $script:formWelcomeXAML[1]
			$formWelcomeXAML.Activate()
		}

		# Function invoked by a timer to periodically check running processes dynamically whilst showing the welcome prompt
		Function Get-RunningProcessesDynamically {
			$dynamicRunningProcesses = $null
			Get-RunningProcesses -ProcessObjects $processObjects -DisableLogging -OutVariable 'dynamicRunningProcesses'
			[string]$dynamicRunningProcessDescriptions = ($dynamicRunningProcesses | Where-Object { $_.ProcessDescription } | Select-Object -ExpandProperty 'ProcessDescription' | Select-Object -Unique | Sort-Object) -join ','
				If ($dynamicRunningProcessDescriptions -ne $script:runningProcessDescriptions) {
				# Update the runningProcessDescriptions variable for the next time this function runs
				Set-Variable -Name 'runningProcessDescriptions' -Value $dynamicRunningProcessDescriptions -Force -Scope 'Script'
				If ($dynamicrunningProcesses) {
					Write-Log -Message "The running processes have changed. Updating the apps to close: [$script:runningProcessDescriptions]..." -Source ${CmdletName}
				}
				# Update the list box with the processes to close
				$listboxCloseApps.Items.Clear()
				$script:runningProcessDescriptions -split "," | ForEach-Object { $null = $listboxCloseApps.Items.Add($_) }
			}
			# If CloseApps processes were running when the prompt was shown, and they are subsequently detected to be closed while the form is showing, then close the form. The deferral and CloseApps conditions will be re-evaluated.
			If ($ProcessDescriptions) {
				If (-not ($dynamicRunningProcesses)) {
					Write-Log -Message 'Previously detected running processes are no longer running.' -Source ${CmdletName}
						$formWelcomeXAML.Close()
				}
			}
			# If CloseApps processes were not running when the prompt was shown, and they are subsequently detected to be running while the form is showing, then close the form for relaunch. The deferral and CloseApps conditions will be re-evaluated.
			ElseIf (-not $ProcessDescriptions) {
				If ($dynamicRunningProcesses) {
					Write-Log -Message 'New running processes detected. Updating the form to prompt to close the running applications.' -Source ${CmdletName}
					$formWelcomeXAML.Close()
				}
			}
		}

		$formWelcomeXAML.ShowDialog() | Out-Null
		Write-Output -InputObject $script:welcomeChoice
		
	}
	End {
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -Footer
	}
}
#endregion

#region Function Show-InstallationProgress
Function Show-InstallationProgressWPF {
<#
.SYNOPSIS
	Displays a progress dialog in a separate thread with an updateable custom message.
.DESCRIPTION
	Create a WPF window in a separate thread to display a marquee style progress ellipse with a custom message that can be updated.
	The status message supports line breaks.
	The first time this function is called in a script, it will display a balloon tip notification to indicate that the installation has started (provided balloon tips are enabled in the configuration).
.PARAMETER StatusMessage
	The status message to be displayed. The default status message is taken from the XML configuration file.
.EXAMPLE
	Show-InstallationProgress
	Uses the default status message from the XML configuration file.
.EXAMPLE
	Show-InstallationProgress -StatusMessage 'Installation in Progress...'
.EXAMPLE
	Show-InstallationProgress -StatusMessage "Installation in Progress...`nThe installation may take 20 minutes to complete."
.EXAMPLE
	Show-InstallationProgress -StatusMessage 'Installation in Progress...' -WindowLocation 'BottomRight' -TopMost $false
.NOTES
.LINK
	http://psappdeploytoolkit.com
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[string]$StatusMessage = $configProgressMessageInstall,
		[Parameter(Mandatory=$false)]
		[ValidateSet('Default','BottomRight')]
		[string]$WindowLocation = 'Default',
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[boolean]$TopMost = $true
	)

	Begin {
		## Get the name of this function and write header
		[string]${CmdletName} = $PSCmdlet.MyInvocation.MyCommand.Name
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -CmdletBoundParameters $PSBoundParameters -Header
	}
	Process {
		If ($deployModeSilent) { Return }

		## If the default progress message hasn't been overridden and the deployment type is uninstall, use the default uninstallation message
		If ($StatusMessage -eq $configProgressMessageInstall) {
			switch ($deploymentType) {
				Install { $StatusMessage = ($configProgressMessageInstall -f $installTitle) }
				Uninstall { $StatusMessage = ($configProgressMessageUninstall -f $installTitle) }
				Repair { $StatusMessage = ($configProgressMessageRepair -f $installTitle) }
				Default {}
			}
		}

		If ($envHost.Name -match 'PowerGUI') {
			Write-Log -Message "$($envHost.Name) is not a supported host for WPF multi-threading. Progress dialog with message [$StatusMessage] will not be displayed." -Severity 2 -Source ${CmdletName}
			Return
		}

		## Check if the progress thread is running before invoking methods on it
		If ($script:ProgressSyncHash.Window.Dispatcher.Thread.ThreadState -ne 'Running') {
			#  Notify user that the software installation has started
			$balloonText = "$deploymentTypeName $configBalloonTextStart"
			Show-BalloonTip -BalloonTipIcon 'Info' -BalloonTipText $balloonText
			#  Create a synchronized hashtable to share objects between runspaces
			$script:ProgressSyncHash = [hashtable]::Synchronized(@{ })
			#  Create a new runspace for the progress bar
			$script:ProgressRunspace = [runspacefactory]::CreateRunspace()
			$script:ProgressRunspace.ApartmentState = 'STA'
			$script:ProgressRunspace.ThreadOptions = 'ReuseThread'
			$script:ProgressRunspace.Open()
			#  Add the sync hash to the runspace
			$script:ProgressRunspace.SessionStateProxy.SetVariable('progressSyncHash', $script:ProgressSyncHash)
			#  Add other variables from the parent thread required in the progress runspace
			$script:ProgressRunspace.SessionStateProxy.SetVariable('installTitle', $installTitle)
			$script:ProgressRunspace.SessionStateProxy.SetVariable('windowLocation', $windowLocation)
			$script:ProgressRunspace.SessionStateProxy.SetVariable('appDeployLogoBannerWPF', $appDeployLogoBannerWPF)
			$script:ProgressRunspace.SessionStateProxy.SetVariable('appDeployLogoBannerHeight', $appDeployLogoBannerHeight)
			$script:ProgressRunspace.SessionStateProxy.SetVariable('appDeployLogoBannerHeightDifference', $appDeployLogoBannerHeightDifference)
			$script:ProgressRunspace.SessionStateProxy.SetVariable('ProgressStatusMessage', $StatusMessage)
			$script:ProgressRunspace.SessionStateProxy.SetVariable('AppDeployLogoIcon', $AppDeployLogoIcon)
			$script:ProgressRunspace.SessionStateProxy.SetVariable('dpiScale', $dpiScale)

			$script:ProgressRunspace.SessionStateProxy.SetVariable('appDeployToolkitInstallIcon', (Join-Path -Path $scriptRoot -ChildPath 'Information.png'))
			

			[string]$formProgressSTR = Get-Content -Path (Join-Path -Path $scriptRoot -ChildPath 'AppDeployToolkitFormProgress.xaml')
			$script:ProgressRunspace.SessionStateProxy.SetVariable('formProgressSTR', $formProgressSTR)

			$script:ProgressRunspace.SessionStateProxy.SetVariable('isSCCM', $isSCCM)
			if ($isSCCM){ 
				$script:ProgressRunspace.SessionStateProxy.SetVariable('SCCMApplication', $SCCMApplication)
				$script:ProgressRunspace.SessionStateProxy.SetVariable('SCCMApplicationIconPath', $SCCMApplicationIconPath)
			}

			#  Add the script block to be executed in the progress runspace
			$progressCmd = [PowerShell]::Create().AddScript({
				# Load XAML form
				$formProgressSTR = $formProgressSTR -replace "x:N",'N' -replace 'mc:Ignorable="d"',''


				## Replace dummy text with values and turn the string into an xml document variable
				## $xamlProgressString = $xamlProgressString.replace('%BannerHeight%', $appDeployLogoBannerHeight).replace('%Height%', 180 + $appDeployLogoBannerHeightDifference).replace('%MinHeight%', 180 + $appDeployLogoBannerHeightDifference).replace('%MaxHeight%', 200 + $appDeployLogoBannerHeightDifference)
				[Xml.XmlDocument]$xamlProgress = New-Object 'System.Xml.XmlDocument'
				$xamlProgress.LoadXml($formProgressSTR)
				## Set the configurable values using variables added to the runspace from the parent thread
				#  Calculate the position on the screen where the progress dialog should be placed
				$screen = [Windows.Forms.Screen]::PrimaryScreen
				$screenWorkingArea = $screen.WorkingArea
				[int32]$screenWidth = $screenWorkingArea | Select-Object -ExpandProperty 'Width'
				[int32]$screenHeight = $screenWorkingArea | Select-Object -ExpandProperty 'Height'
				#  Set the start position of the Window based on the screen size
				If ($windowLocation -eq 'BottomRight') {
					$xamlProgress.Window.Left = [string](($screenWidth / ($dpiscale / 100)) - ($xamlProgress.Window.Width))
					$xamlProgress.Window.Top = [string](($screenHeight / ($dpiscale / 100)) - ($xamlProgress.Window.Height))
				}
				#  Show the default location (Top center)
				Else {
					#  Center the progress window by calculating the center of the workable screen based on the width of the screen relative to the DPI scale minus half the width of the progress bar
					$xamlProgress.Window.Left = [string](($screenWidth / (2 * ($dpiscale / 100) )) - (($xamlProgress.Window.Width / 2)))
					$xamlProgress.Window.Top = [string]($screenHeight / 9.5)
				}
				$xamlProgress.Window.Icon = $AppDeployLogoIcon
				$xamlProgress.Window.DockPanel.StackPanel.StackPanel.Image.Source = $appDeployLogoBannerWPF
				
				[Xml.XmlNode]$node = $xamlProgress.SelectSingleNode("//*[@Name='gridWelcome']").StackPanel.TextBlock
				$node.Attributes["Text"].Value = $ProgressStatusMessage

				[Xml.XmlNode]$node = $xamlProgress.SelectSingleNode("//*[@Name='pictureProgress']")
				$node.Attributes["Source"].Value = $appDeployToolkitInstallIcon

				if ($isSCCM){
					[Xml.XmlNode]$node = $xamlProgress.SelectSingleNode("//*[@Name='gridSCCM']")
					$node.Attributes["Visibility"].Value = "Visible"
					[Xml.XmlNode]$node = $xamlProgress.SelectSingleNode("//*[@Name='labelAppIcon']")
					$node.Attributes["Source"].Value = $SCCMApplicationIconPath
					[Xml.XmlNode]$node = $xamlProgress.SelectSingleNode("//*[@Name='labelAppName']")
					$node.Attributes["Text"].Value = $SCCMApplication.FullName
					[Xml.XmlNode]$node = $xamlProgress.SelectSingleNode("//*[@Name='labelAppVendor']")
					$node.Attributes["Text"].Value = "Published by $($SCCMApplication.Publisher)"
					[Xml.XmlNode]$node = $xamlProgress.SelectSingleNode("//*[@Name='labelAppVersion']")
					$node.Attributes["Text"].Value = $SCCMApplication.SoftwareVersion
					$xamlProgress.Window.Title = 'Software Center'
				}
				else {
					[Xml.XmlNode]$node = $xamlProgress.SelectSingleNode("//*[@Name='gridSCCM']")
					$node.Attributes["Visibility"].Value = "Collapsed"
					$xamlProgress.Window.Title = $installTitle
				}

				#  Parse the XAML
				$progressReader = New-Object -TypeName 'System.Xml.XmlNodeReader' -ArgumentList $xamlProgress
				$script:ProgressSyncHash.Window = [Windows.Markup.XamlReader]::Load($progressReader)
				$script:ProgressSyncHash.ProgressText = $script:ProgressSyncHash.Window.FindName('ProgressText')
				#  Add an action to the Window.Closing event handler to disable the close button
				$script:ProgressSyncHash.Window.Add_Closing({ $_.Cancel = $true })
				#  Allow the window to be dragged by clicking on it anywhere
				$script:ProgressSyncHash.Window.Add_MouseLeftButtonDown({ $script:ProgressSyncHash.Window.DragMove() })
				#  Add a tooltip
				$script:ProgressSyncHash.Window.ToolTip = $installTitle
				$null = $script:ProgressSyncHash.Window.ShowDialog()
				$script:ProgressSyncHash.Error = $Error
			})

			$progressCmd.Runspace = $script:ProgressRunspace
			Write-Log -Message "Spin up progress dialog in a separate thread with message: [$StatusMessage]." -Source ${CmdletName}
			#  Invoke the progress runspace
			$progressData = $progressCmd.BeginInvoke()
			#  Allow the thread to be spun up safely before invoking actions against it.
			Start-Sleep -Seconds 1
			If ($script:ProgressSyncHash.Error) {
				Write-Log -Message "Failure while displaying progress dialog. `n$(Resolve-Error -ErrorRecord $script:ProgressSyncHash.Error)" -Severity 3 -Source ${CmdletName}
			}
		}
		## Check if the progress thread is running before invoking methods on it
		ElseIf ($script:ProgressSyncHash.Window.Dispatcher.Thread.ThreadState -eq 'Running') {
			#  Update the progress text
			Try {
				$script:ProgressSyncHash.Window.Dispatcher.Invoke([Windows.Threading.DispatcherPriority]'Send', [Windows.Input.InputEventHandler]{ $script:ProgressSyncHash.ProgressText.Text = $StatusMessage }, $null, $null)
				Write-Log -Message "Updated progress message: [$StatusMessage]." -Source ${CmdletName}
			}
			Catch {
				Write-Log -Message "Unable to update the progress message. `n$(Resolve-Error)" -Severity 2 -Source ${CmdletName}
			}
		}
	}
	End {
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -Footer
	}
}
#endregion

#region Function Show-InstallationRestartPrompt
Function Show-InstallationRestartPromptWPF {
<#
.SYNOPSIS
	Displays a restart prompt with a countdown to a forced restart.
.DESCRIPTION
	Displays a restart prompt with a countdown to a forced restart.
.PARAMETER CountdownMinutes
	Specifies the number of seconds to countdown before the system restart.
.PARAMETER CountdownNoHideMinutes
	Specifies the number of seconds to display the restart prompt without allowing the window to be hidden.
.PARAMETER NoCountdown
	Specifies not to show a countdown, just the Restart Now and Restart Later buttons.
	The UI will restore/reposition itself persistently based on the interval value specified in the config file.
.EXAMPLE
	Show-InstallationRestartPrompt -CountdownMinutes 600 -CountdownNoHideMinutes 60
.EXAMPLE
	Show-InstallationRestartPrompt -NoCountdown
.NOTES
.LINK
	http://psappdeploytoolkit.com
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$CountdownMinutes = 240,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$CountdownNoHideMinutes = 10,
		[Parameter(Mandatory=$false)]
		[switch]$NoCountdown = $false
	)

	Begin {
		## Get the name of this function and write header
		[string]${CmdletName} = $PSCmdlet.MyInvocation.MyCommand.Name
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -CmdletBoundParameters $PSBoundParameters -Header
	}
	Process {
		## Bypass if in non-interactive mode
		If ($deployModeSilent) {
			Write-Log -Message "Bypass Installation Restart Prompt [Mode: $deployMode]." -Source ${CmdletName}
			Return
		}
		## Get the parameters passed to the function for invoking the function asynchronously
		[hashtable]$installRestartPromptParameters = $psBoundParameters

		## Check if we are already displaying a restart prompt
		If (Get-Process | Where-Object { $_.MainWindowTitle -match $configRestartPromptTitle }) {
			Write-Log -Message "${CmdletName} was invoked, but an existing restart prompt was detected. Cancelling restart prompt." -Severity 2 -Source ${CmdletName}
			Return
		}

		[datetime]$startTime = Get-Date
		[datetime]$countdownTime = $startTime
		$countdownTimeSpan = [timespan]::FromMinutes($CountdownMinutes)

		$timerCountdown = New-Object -TypeName 'System.Windows.Threading.DispatcherTimer'
		$timerCountdown.Interval = 10000000L

		[scriptblock]$RestartComputer = {
			$MessageTitle = "System Restart Required"
			$MessageText += "`nSystem will restart immediately, are you sure?"
			$MessageIcon = [System.Windows.MessageBoxImage]::Question
			$ButtonType = [System.Windows.MessageBoxButton]::OkCancel
			Switch ([System.Windows.MessageBox]::Show($MessageText,$MessageTitle,$ButtonType,$MessageIcon)){
				"Ok" { 
					Write-Log -Message 'Force restart the computer...' -Source ${CmdletName}
					Restart-Computer -Force
				} 
				"Cancel" { } 
			}
		}

		# Load XAML form
		[string]$formRestartSTR = Get-Content -Path (Join-Path -Path $scriptRoot -ChildPath 'AppDeployToolkitFormRestart.xaml')
		[xml]$formRestartXML = $formRestartSTR -replace "x:N",'N' -replace 'mc:Ignorable="d"',''

		[Xml.XmlNode]$node = $formRestartXML.SelectSingleNode("//*[@Name='labelAppIcon']")
		$node.Attributes["Source"].Value = $SCCMApplicationIconPath

		[Xml.XmlNode]$node = $formRestartXML.SelectSingleNode("//*[@Name='pictureRestart']")
		$node.Attributes["Source"].Value = Join-Path -Path $scriptRoot -ChildPath 'Information.png'		

		$formRestartXML.Window.DockPanel.StackPanel.StackPanel.Image.Source = $appDeployLogoBannerWPF

		$formRestartXML.Window.Icon = $AppDeployLogoIcon

		# Create XAML form
		Try { 
			$xmlReader = New-Object System.Xml.XmlNodeReader $formRestartXML
			$formRestartXAML = [Windows.Markup.XamlReader]::Load($xmlReader)
			Write-Log -Message "XAML Form loaded: [$formRestartXAML] " -Source ${CmdletName}
		}
		Catch { 
			Write-Log -Message "Unable to parse XAML, with error: $($Error[0])" -Source ${CmdletName}
		}

		# Load XAML Objects
		$formRestartXML.SelectNodes("//*[@Name]") | % {
			Try { 
				Set-Variable -Name $($_.Name) -Value $formRestartXAML.FindName($_.Name) -ErrorAction Stop 
			}
			Catch { 
				Write-Log -Message "Unable to create variable. Error: $($Error[0])" -Source ${CmdletName}
			}
		}

		[scriptblock]$FormEvent_Load = {
			## Initialize the countdown timer
			[datetime]$currentTime = Get-Date
			[datetime]$countdownTime = $startTime.AddMinutes($CountdownMinutes)
			$timerCountdown.Start()
			## Set up the form
			[timespan]$remainingTime = $countdownTime.Subtract($currentTime)
			$labelCountdown.Text = [string]::Format('{0}:{1:d2}:{2:d2}', $remainingTime.Days * 24 + $remainingTime.Hours, $remainingTime.Minutes, $remainingTime.Seconds)
			If ($remainingTime.TotalMinutes -le $CountdownNoHideMinutes) { $buttonRestartLater.Enabled = $false }
			$formRestartXAML.Activate()
		}


		## Persistence Timer
		$timerPersist = New-Object -TypeName 'System.Windows.Threading.DispatcherTimer'
		$timerPersist.Interval = ($configInstallationRestartPersistInterval * 10000000L)
		[scriptblock]$timerPersist_Tick = {
			#  Show the Restart Popup
			$notifyRestartIcon.ShowBalloonTip(5000)
			Start-Sleep -s 5
			$formRestartXAML.WindowState = 'Normal'
			$formRestartXAML.TopMost = $true
			$formRestartXAML.Activate()
			
		}
		$timerPersist.add_Tick($timerPersist_Tick)
		$timerPersist.Start()		

		[scriptblock]$buttonRestartLater_Click = {
			## Minimize the form
			$formRestartXAML.WindowState = 'Minimized'
			$formRestartXAML.TopMost = $false
			If ($NoCountdown) {
				## Reset the persistence timer
				$timerPersist.Stop()
				$timerPersist.Start()
			}
		}

		## Restart the computer
		[scriptblock]$buttonRestartNow_Click = { & $RestartComputer }

		## Hide the form if minimized
		[scriptblock]$formRestart_Resize = { If ($formRestartXAML.WindowState -eq 'Minimized') { $formRestartXAML.WindowState = 'Minimized' } }

		[scriptblock]$timerCountdown_Tick = {
			## Get the time information
			[datetime]$currentTime = Get-Date
			[datetime]$countdownTime = $startTime.AddMinutes($CountdownMinutes)
			[timespan]$remainingTime = $countdownTime.Subtract($currentTime)
			## If the countdown is complete, restart the machine
			If ($countdownTime -lt $currentTime) {				
				$progressRestart.Visibility = [Windows.Visibility]::Collapsed
				$labelCountdown.Text = ""
				$labelTimeRemaining.Text = "Restart is now required."

			}
			Else {
				## Update the form
				[double]$progpercent = 100 - (($remainingTime.Ticks / $countdownTimeSpan.Ticks) * 100)
				$progressRestart.Value = $progpercent
				$labelCountdown.Text = [string]::Format('{0}:{1:d2}:{2:d2}', $remainingTime.Days * 24 + $remainingTime.Hours, $remainingTime.Minutes, $remainingTime.Seconds)
				If ($remainingTime.TotalMinutes -le $CountdownNoHideMinutes) {
					$buttonRestartLater.IsEnabled = $false
					$labelTimeRemaining.Foreground = 'Red'
					$labelCountdown.Foreground = 'Red'
					$progressRestart.Foreground = 'Red'
					$timerPersist.Stop()
					#  If the form is hidden when we hit the "No Hide", bring it back up
					If ($formRestartXAML.WindowState -eq 'Minimized') {
						#  Show Popup
						$notifyRestartIcon.ShowBalloonTip(5000)
						$formRestartXAML.WindowState = 'Normal'
						$formRestartXAML.Activate()
						$formRestartXAML.TopMost = $true
						
					}
				}
			}
		}

		## Remove all event handlers from the controls
		[scriptblock]$Form_Cleanup_FormClosed = {
			Try {
				$buttonRestartLater.remove_Click($buttonRestartLater_Click)
				$buttonRestartNow.remove_Click($buttonRestartNow_Click)
				$formRestartXAML.remove_Load($FormEvent_Load)
				$formRestartXAML.remove_Resize($formRestart_Resize)
				$timerCountdown.remove_Tick($timerCountdown_Tick)
				$timerPersist.remove_Tick($timerPersist_Tick)
				$formRestartXAML.remove_Load($Form_StateCorrection_Load)
				$formRestartXAML.remove_Closed($Form_Cleanup_FormClosed)
			}
			Catch { }
		}

		## Form
		If (-not $NoCountdown) {
			## $formRestart.Controls.Add($labelCountdown)
			## $formRestart.Controls.Add($labelTimeRemaining)
			$timerCountdown.add_Tick($timerCountdown_Tick)
			$gridCountdown.Visibility = [Windows.Visibility]::Visible
		}
		Else {
			$gridCountdown.Visibility = [Windows.Visibility]::Collapsed
		}

		$labelAppDesc.Text = "$configRestartPromptMessage $configRestartPromptMessageTime `n$configRestartPromptMessageRestart"
		If ($NoCountdown) { $labelAppDesc.Text = $configRestartPromptMessage }

		## Label Time Remaining
		$labelTimeRemaining.Text = $configRestartPromptTimeRemaining

		## Setup form for SCCM
		if ($isSCCM) { 
			$labelAppName.Text = $SCCMApplication.FullName
			$labelAppVendor.Text = "Published by $($SCCMApplication.Publisher)"
			$labelAppVersion.Text = $SCCMApplication.SoftwareVersion
			$gridSCCM.Visibility = [Windows.Visibility]::Visible
		}
		else { 
			$gridSCCM.Visibility = [Windows.Visibility]::Collapsed
		}

		## Label Restart Later
		$buttonRestartLater.add_Click($buttonRestartLater_Click)

		## Label Restart Now
		$buttonRestartNow.add_Click($buttonRestartNow_Click)

		$formRestartXAML.TaskbarItemInfo.Overlay = New-Object System.Windows.Media.Imaging.BitmapImage((Join-Path -Path $scriptRoot -ChildPath 'Information.png')) 
		$formRestartXAML.TaskbarItemInfo.Description = $configRestartPromptTitle

		##----------------------------------------------
		$formRestartXAML.Title = $configRestartPromptTitle
		# Init the OnLoad event to correct the initial state of the form
		$formRestartXAML.add_ContentRendered($FormEvent_Load)
		# Clean up the control events
		$formRestartXAML.add_Closed($Form_Cleanup_FormClosed)
		$formRestartXAML.add_Closing({ $_.Cancel = $true })

		## If the script has been dot-source invoked by the deploy app script, display the restart prompt asynchronously
		If ($deployAppScriptFriendlyName) {
			If ($NoCountdown) {
				Write-Log -Message "Invoking ${CmdletName} asynchronously with no countdown..." -Source ${CmdletName}
			}
			Else {
				Write-Log -Message "Invoking ${CmdletName} asynchronously with a [$CountdownMinutes] minute countdown..." -Source ${CmdletName}
			}
			[string]$installRestartPromptParameters = ($installRestartPromptParameters.GetEnumerator() | ForEach-Object {
				If ($_.Value.GetType().Name -eq 'SwitchParameter') {
					"-$($_.Key)"
				}
				ElseIf ($_.Value.GetType().Name -eq 'Boolean') {
					"-$($_.Key) `$" + "$($_.Value)".ToLower()
				}
				ElseIf ($_.Value.GetType().Name -eq 'Int32') {
					"-$($_.Key) $($_.Value)"
				}
				Else {
					"-$($_.Key) `"$($_.Value)`""
				}
			}) -join ' '
			Start-Process -FilePath "$PSHOME\powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -NoProfile -NoLogo -WindowStyle Hidden -File `"$scriptPath`" -ReferredInstallTitle `"$installTitle`" -ReferredAppNameDesc `"$appNameDesc`" -ReferredInstallName `"$installName`" -ReferredLogName `"$logName`" -ShowInstallationRestartPromptWPF $installRestartPromptParameters -AsyncToolkitLaunch" -WindowStyle 'Hidden' -ErrorAction 'SilentlyContinue'
			Start-Sleep -Seconds 10
		}
		Else {
			If ($NoCountdown) {
				Write-Log -Message 'Display restart prompt with no countdown.' -Source ${CmdletName}
			}
			Else {
				Write-Log -Message "Display restart prompt with a [$CountdownMinutes] minute countdown." -Source ${CmdletName}
			}

			## Dispose of previous balloon
			If ($script:notifyRestartIcon) { Try { $script:notifyRestartIcon.Dispose() } Catch {} }
			[Windows.Forms.ToolTipIcon]$BalloonTipIcon = 'Info'
			$script:notifyRestartIcon = New-Object -TypeName 'System.Windows.Forms.NotifyIcon' -Property @{
				BalloonTipIcon = $BalloonTipIcon
				BalloonTipText = "A system restart is required to complete a recent software installation"
				BalloonTipTitle = $configRestartPromptTitle
				Icon = New-Object -TypeName 'System.Drawing.Icon' -ArgumentList $AppDeployLogoIcon
				Text = $configRestartPromptTitle
				Visible = $true
			}
			$notifyRestartIcon.add_MouseClick({
				$formRestartXAML.WindowState = 'Normal'
				$formRestartXAML.TopMost = $true
				$formRestartXAML.Activate()
			})
	
			$notifyRestartIcon.add_BalloonTipClicked({
				$formRestartXAML.WindowState = 'Normal'
				$formRestartXAML.TopMost = $true
				$formRestartXAML.Activate()
			})

			$script:notifyRestartIcon.ShowBalloonTip(5000)
			Start-Sleep -Seconds 2
			Write-Output -InputObject $formRestartXAML.ShowDialog()


			$formRestartXAML.Close()
			$notifyRestartIcon.Dispose()

			#  Activate the Window
			[Diagnostics.Process]$powershellProcess = Get-Process | Where-Object { $_.MainWindowTitle -match $installTitle }
			[Microsoft.VisualBasic.Interaction]::AppActivate($powershellProcess.ID)
		}
	}
	End {
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -Footer
	}
}
#endregion

#region Function Show-InstallationPrompt
Function Show-InstallationPromptWPF {
<#
.SYNOPSIS
	Displays a custom installation prompt with the toolkit branding and optional buttons.
.DESCRIPTION
	Any combination of Left, Middle or Right buttons can be displayed. The return value of the button clicked by the user is the button text specified.
.PARAMETER Title
	Title of the prompt. Default: the application installation name.
.PARAMETER Message
	Message text to be included in the prompt
.PARAMETER MessageAlignment
	Alignment of the message text. Options: Left, Center, Right. Default: Center.
.PARAMETER ButtonLeftText
	Show a button on the left of the prompt with the specified text
.PARAMETER ButtonRightText
	Show a button on the right of the prompt with the specified text
.PARAMETER ButtonMiddleText
	Show a button in the middle of the prompt with the specified text
.PARAMETER Icon
	Show a system icon in the prompt. Options: Application, Asterisk, Error, Exclamation, Hand, Information, None, Question, Shield, Warning, WinLogo. Default: None.
.PARAMETER NoWait
	Specifies whether to show the prompt asynchronously (i.e. allow the script to continue without waiting for a response). Default: $false.
.PARAMETER PersistPrompt
	Specify whether to make the prompt persist in the center of the screen every couple of seconds, specified in the AppDeployToolkitConfig.xml. The user will have no option but to respond to the prompt - resistance is futile!
.PARAMETER MinimizeWindows
	Specifies whether to minimize other windows when displaying prompt. Default: $false.
.PARAMETER Timeout
	Specifies the time period in seconds after which the prompt should timeout. Default: UI timeout value set in the config XML file.
.PARAMETER ExitOnTimeout
	Specifies whether to exit the script if the UI times out. Default: $true.
.EXAMPLE
	Show-InstallationPrompt -Message 'Do you want to proceed with the installation?' -ButtonRightText 'Yes' -ButtonLeftText 'No'
.EXAMPLE
	Show-InstallationPrompt -Title 'Funny Prompt' -Message 'How are you feeling today?' -ButtonRightText 'Good' -ButtonLeftText 'Bad' -ButtonMiddleText 'Indifferent'
.EXAMPLE
	Show-InstallationPrompt -Message 'You can customize text to appear at the end of an install, or remove it completely for unattended installations.' -Icon Information -NoWait
.NOTES
.LINK
	http://psappdeploytoolkit.com
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[string]$Title = $installTitle,
		[Parameter(Mandatory=$false)]
		[string]$Message = '',
		[Parameter(Mandatory=$false)]
		[ValidateSet('Left','Center','Right')]
		[string]$MessageAlignment = 'Center',
		[Parameter(Mandatory=$false)]
		[string]$ButtonRightText = '',
		[Parameter(Mandatory=$false)]
		[string]$ButtonLeftText = '',
		[Parameter(Mandatory=$false)]
		[string]$ButtonMiddleText = '',
		[Parameter(Mandatory=$false)]
		[ValidateSet('Application','Asterisk','Error','Exclamation','Hand','Information','None','Question','Shield','Warning','WinLogo')]
		[string]$Icon = 'None',
		[Parameter(Mandatory=$false)]
		[switch]$NoWait = $false,
		[Parameter(Mandatory=$false)]
		[switch]$PersistPrompt = $false,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[boolean]$MinimizeWindows = $false,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[int32]$Timeout = $configInstallationUITimeout,
		[Parameter(Mandatory=$false)]
		[ValidateNotNullorEmpty()]
		[boolean]$ExitOnTimeout = $true
	)

	Begin {
		## Get the name of this function and write header
		[string]${CmdletName} = $PSCmdlet.MyInvocation.MyCommand.Name
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -CmdletBoundParameters $PSBoundParameters -Header
	}
	Process {
		## Bypass if in non-interactive mode
		If ($deployModeSilent) {
			Write-Log -Message "Bypassing Installation Prompt [Mode: $deployMode]... $Message" -Source ${CmdletName}
			Return
		}

		## Get parameters for calling function asynchronously
		[hashtable]$installPromptParameters = $psBoundParameters

		## Check if the countdown was specified
		If ($timeout -gt $configInstallationUITimeout) {
			[string]$CountdownTimeoutErr = "The installation UI dialog timeout cannot be longer than the timeout specified in the XML configuration file."
			Write-Log -Message $CountdownTimeoutErr -Severity 3 -Source ${CmdletName}
			Throw $CountdownTimeoutErr
		}

		[string]$script:promptChoice = ''

		# Load XAML form
		[string]$formPromptSTR = Get-Content -Path (Join-Path -Path $scriptRoot -ChildPath 'AppDeployToolkitFormPrompt.xaml')
		[xml]$formPromptXML = $formPromptSTR -replace "x:N",'N' -replace 'mc:Ignorable="d"',''

		[Xml.XmlNode]$node = $formPromptXML.SelectSingleNode("//*[@Name='labelAppIcon']")
		$node.Attributes["Source"].Value = $SCCMApplicationIconPath	

		$formPromptXML.Window.DockPanel.StackPanel.StackPanel.Image.Source = $appDeployLogoBannerWPF

		$formPromptXML.Window.Icon = $AppDeployLogoIcon

		# Create XAML form
		Try { 
			$xmlReader = New-Object System.Xml.XmlNodeReader $formPromptXML
			$formPromptXAML = [Windows.Markup.XamlReader]::Load($xmlReader)
			Write-Log -Message "XAML Form loaded: [$formPromptXAML] " -Source ${CmdletName}
		}
		Catch { 
			Write-Log -Message "Unable to parse XAML, with error: $($Error[0])" -Source ${CmdletName}
		}

		# Load XAML Objects
		$formPromptXML.SelectNodes("//*[@Name]") | % {
			Try { 
				Set-Variable -Name $($_.Name) -Value $formPromptXAML.FindName($_.Name) -ErrorAction Stop 
			}
			Catch { 
				Write-Log -Message "Unable to create variable. Error: $($Error[0])" -Source ${CmdletName}
			}
		}

		[scriptblock]$Form_Cleanup_FormClosed = {
			## Remove all event handlers from the controls
			Try {
				$buttonLeft.remove_Click($buttonLeft_OnClick)
				$buttonRight.remove_Click($buttonRight_OnClick)
				$buttonMiddle.remove_Click($buttonMiddle_OnClick)
				$timer.remove_Tick($timer_Tick)
				$timer.Dispose()
				$timer = $null
				$timerPersist.remove_Tick($timerPersist_Tick)
				$timerPersist.Dispose()
				$timerPersist = $null
				$formPromptXAML.remove_Load($Form_StateCorrection_Load)
				$formPromptXAML.remove_FormClosed($Form_Cleanup_FormClosed)
			}
			Catch { }
		}

		Function buttonPrompt_OnClick {
			Param ($choice)
			$script:promptChoice = $choice
			$formPromptXAML.Close()
		}

		[scriptblock]$Form_StateCorrection_Load = {
			## Correct the initial state of the form to prevent the .NET maximized form issue
			$formPromptXAML.WindowState = 'Normal'
			$formPromptXAML.Activate()
		}

		## Picture Icon
		
		
		If ($Icon -ne 'None') { 
			If (-not (Test-Path "$scriptRoot\$Icon.png")) {
				[Drawing.SystemIcons]::$Icon.ToBitmap().Save("$scriptRoot\$Icon.png", [Drawing.Imaging.ImageFormat]::Png)
			}
			$picturePrompt.Source = New-Object System.Windows.Media.Imaging.BitmapImage(Join-Path -Path $scriptRoot -ChildPath "$Icon.png") 
		}

		## Button Left
		$buttonLeft.Content = $buttonLeftText
		$buttonLeft.add_Click({buttonPrompt_OnClick $buttonLeft.Content})

		## Button Middle
		$buttonMiddle.Content = $buttonMiddleText
		$buttonMiddle.add_Click({buttonPrompt_OnClick $buttonMiddle.Content})

		## Button Right
		$buttonRight.Content = $buttonRightText
		$buttonRight.add_Click({buttonPrompt_OnClick $buttonRight.Content})

		$labelPromptTitle.Text = $Title
		$labelPromptText.Text = $Message

		## Form Installation Prompt

		## Setup form for SCCM
		if ($isSCCM) { 
			$labelAppName.Text = $SCCMApplication.FullName
			$labelAppVendor.Text = "Published by $($SCCMApplication.Publisher)"
			$labelAppVersion.Text = $SCCMApplication.SoftwareVersion
			$formPromptXAML.Title = 'Software Center'
			$gridSCCM.Visibility = [Windows.Visibility]::Visible
		}
		else { 
			$formPromptXAML.Title = $installTitle
			$gridSCCM.Visibility = [Windows.Visibility]::Collapsed
		}

		If (-not $buttonLeftText) { $buttonLeft.Visibility = [Windows.Visibility]::Collapsed }
		If (-not $buttonMiddleText) { $buttonMiddle.Visibility = [Windows.Visibility]::Collapsed }
		If (-not $buttonRightText) { $buttonRight.Visibility = [Windows.Visibility]::Collapsed }

		## Timer
		$timer = New-Object -TypeName 'System.Windows.Threading.DispatcherTimer'
		$timer.Interval = ($timeout * 10000000L)
		$timer.Add_Tick({
			Write-Log -Message 'Installation action not taken within a reasonable amount of time.' -Source ${CmdletName}
			If ($ExitOnTimeout) {
				Exit-Script -ExitCode $configInstallationUIExitCode
			}
			Else {
				Write-Log -Message 'UI timed out but `$ExitOnTimeout set to `$false. Continue...' -Source ${CmdletName}
			}
		})

		## Init the OnLoad event to correct the initial state of the form
		$formPromptXAML.add_ContentRendered($Form_StateCorrection_Load)
		## Clean up the control events
		$formPromptXAML.add_Closed($Form_Cleanup_FormClosed)

		## Start the timer
		$timer.Start()

		## Persistence Timer
		[scriptblock]$RefreshInstallationPrompt = {
			$formPromptXAML.Activate()
		}
		If ($persistPrompt) {
			$timerPersist = New-Object -TypeName 'System.Windows.Threading.DispatcherTimer'
			$timerPersist.Interval = ($configInstallationPersistInterval * 10000000L)
			[scriptblock]$timerPersist_Tick = { & $RefreshInstallationPrompt }
			$timerPersist.add_Tick($timerPersist_Tick)
			$timerPersist.Start()
		}

		## Close the Installation Progress Dialog if running
		Close-InstallationProgress

		[string]$installPromptLoggedParameters = ($installPromptParameters.GetEnumerator() | ForEach-Object { If ($_.Value.GetType().Name -eq 'SwitchParameter') { "-$($_.Key):`$" + "$($_.Value)".ToLower() } ElseIf ($_.Value.GetType().Name -eq 'Boolean') { "-$($_.Key) `$" + "$($_.Value)".ToLower() } ElseIf ($_.Value.GetType().Name -eq 'Int32') { "-$($_.Key) $($_.Value)" } Else { "-$($_.Key) `"$($_.Value)`"" } }) -join ' '
		Write-Log -Message "Displaying custom installation prompt with the non-default parameters: [$installPromptLoggedParameters]." -Source ${CmdletName}

		## If the NoWait parameter is specified, launch a new PowerShell session to show the prompt asynchronously
		If ($NoWait) {
			# Remove the NoWait parameter so that the script is run synchronously in the new PowerShell session
			$installPromptParameters.Remove('NoWait')
			# Format the parameters as a string
			[string]$installPromptParameters = ($installPromptParameters.GetEnumerator() | ForEach-Object { If ($_.Value.GetType().Name -eq 'SwitchParameter') { "-$($_.Key):`$" + "$($_.Value)".ToLower() } ElseIf ($_.Value.GetType().Name -eq 'Boolean') { "-$($_.Key) `$" + "$($_.Value)".ToLower() } ElseIf ($_.Value.GetType().Name -eq 'Int32') { "-$($_.Key) $($_.Value)" } Else { "-$($_.Key) `"$($_.Value)`"" } }) -join ' '
			Start-Process -FilePath "$PSHOME\powershell.exe" -ArgumentList "-ExecutionPolicy Bypass -NoProfile -NoLogo -WindowStyle Hidden -File `"$scriptPath`" -ReferredInstallTitle `"$Title`" -ReferredInstallName `"$installName`" -ReferredLogName `"$logName`" -ShowInstallationPromptWPF $installPromptParameters -AsyncToolkitLaunch" -WindowStyle 'Hidden' -ErrorAction 'SilentlyContinue'
		}
		## Otherwise, show the prompt synchronously. If user cancels, then keep showing it until user responds using one of the buttons.
		Else {
			$showDialog = $true
			While ($showDialog) {
				# Minimize all other windows
				If ($minimizeWindows) { $null = $shellApp.MinimizeAll() }
				# Show the Form
				$ret = $formPromptXAML.ShowDialog()
				If (($script:promptChoice -eq $buttonLeft.Content) -or ($script:promptChoice -eq $buttonMiddle.Content) -or ($script:promptChoice -eq $buttonRight.Content)) {
					$showDialog = $false
				}
			}
			$formPromptXAML.Close()

			Write-Output $script:promptChoice
		}
	}
	End {
		Write-FunctionHeaderOrFooter -CmdletName ${CmdletName} -Footer
	}
}
#endregion
	
##*===============================================
##* END FUNCTION LISTINGS
##*===============================================

##*===============================================
##* SCRIPT BODY
##*===============================================

If ($scriptParentPath) {
	Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] dot-source invoked by [$(((Get-Variable -Name MyInvocation).Value).ScriptName)]" -Source $appDeployToolkitExtName
} Else {
	Write-Log -Message "Script [$($MyInvocation.MyCommand.Definition)] invoked directly" -Source $appDeployToolkitExtName
}

##*===============================================
##* END SCRIPT BODY
##*===============================================
