param([string]$Prefix = 'WL11-', [string]$Domain = 'melb.ad')
$ErrorActionPreference = 'Stop'
$WorkDir = 'C:\ProgramData\Rename'
$ResultFile = Join-Path $WorkDir 'result.json'
function PLog($m){ try { "$(Get-Date -Format s) [popup] $m" | Add-Content (Join-Path $WorkDir 'Rename.log') } catch {} }
trap { PLog "ERROR: $($_.Exception.Message) | line $($_.InvocationInfo.ScriptLineNumber)"; exit 1 }
PLog "Popup started. User=$env:USERNAME Session=$([System.Diagnostics.Process]::GetCurrentProcess().SessionId)"

Add-Type -AssemblyName System.Windows.Forms, System.Drawing, System.Security, System.DirectoryServices.AccountManagement
[System.Windows.Forms.Application]::EnableVisualStyles()

# ShiftF10.exe (AutoHotkey) opens the OOBE command prompt so our window can take the foreground (as in OOBEPrompt).
# Never wait on it for more than 15s.
try {
    $sf = Start-Process (Join-Path $WorkDir 'ShiftF10.exe') -PassThru
    if (-not $sf.WaitForExit(15000)) { $sf.Kill() }
} catch { PLog "ShiftF10 failed: $($_.Exception.Message)" }

$MaxLen = 15 - $Prefix.Length   # NetBIOS limit

# ---- Serial number (BIOS, then enclosure). Empty if missing or placeholder ----
$detected = ''
try { $detected = ((Get-CimInstance Win32_BIOS).SerialNumber | Out-String).Trim() } catch {}
if (-not $detected) { try { $detected = ((Get-CimInstance Win32_SystemEnclosure).SerialNumber | Out-String).Trim() } catch {} }
$junk = 'To Be Filled By O.E.M.','Default string','System Serial Number','None','N/A','Not Specified','Not Applicable','Unknown','0'
if ($junk -contains $detected) { $detected = '' }
$script:serial = ($detected -replace '[^A-Za-z0-9\-]','').ToUpper().Trim('-')
if ($script:serial -match '^0+$') { $script:serial = '' }
if ($script:serial.Length -gt $MaxLen) { $script:serial = $script:serial.Substring($script:serial.Length - $MaxLen) }
PLog "Detected serial '$detected' -> prefill '$($script:serial)'"

$blue = [System.Drawing.Color]::FromArgb(15,76,129)
$grey = [System.Drawing.Color]::FromArgb(85,85,85)
function New-Ctl($type, $x, $y, $w, $h, $text) {
    $c = New-Object $type; $c.Location = New-Object System.Drawing.Point($x,$y); $c.Size = New-Object System.Drawing.Size($w,$h)
    if ($null -ne $text) { $c.Text = $text }; $c
}

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Device Information'; $form.ClientSize = New-Object System.Drawing.Size(520,560)
$form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'; $form.ControlBox = $false
$form.MinimizeBox = $false; $form.MaximizeBox = $false; $form.TopMost = $true; $form.ShowInTaskbar = $false
$form.Font = New-Object System.Drawing.Font('Segoe UI',10); $form.BackColor = [System.Drawing.Color]::White

$hdr = New-Ctl System.Windows.Forms.Label 0 0 520 50 '  Device Information'
$hdr.BackColor = $blue; $hdr.ForeColor = [System.Drawing.Color]::White; $hdr.TextAlign = 'MiddleLeft'
$hdr.Font = New-Object System.Drawing.Font('Segoe UI',16,[System.Drawing.FontStyle]::Bold)

$h1 = New-Ctl System.Windows.Forms.Label 24 66 470 24 'Computer Name'
$h1.ForeColor = $blue; $h1.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold)
$lblPrefix = New-Ctl System.Windows.Forms.Label 24 98 70 28 $Prefix; $lblPrefix.TextAlign = 'MiddleLeft'; $lblPrefix.Font = New-Object System.Drawing.Font('Segoe UI',12)
$txtTag = New-Ctl System.Windows.Forms.TextBox 96 98 250 28 ''; $txtTag.MaxLength = $MaxLen; $txtTag.CharacterCasing = 'Upper'; $txtTag.Font = New-Object System.Drawing.Font('Segoe UI',12)
$note = New-Ctl System.Windows.Forms.Label 24 134 470 22 'Pre-filled with the serial number. Tick the box to change it.'; $note.ForeColor = $grey
$chk = New-Ctl System.Windows.Forms.CheckBox 24 160 470 24 'Override detected serial number'
$lblPreview = New-Ctl System.Windows.Forms.Label 24 190 470 22 ''; $lblPreview.ForeColor = $blue

$h2 = New-Ctl System.Windows.Forms.Label 24 226 470 24 'Domain Credentials'
$h2.ForeColor = $blue; $h2.Font = New-Object System.Drawing.Font('Segoe UI',11,[System.Drawing.FontStyle]::Bold)
$lblDom = New-Ctl System.Windows.Forms.Label 24 252 470 22 "Domain: $Domain"; $lblDom.ForeColor = $grey
$l3 = New-Ctl System.Windows.Forms.Label 24 282 470 20 'Username'
$txtUser = New-Ctl System.Windows.Forms.TextBox 24 304 470 28 ''
$l4 = New-Ctl System.Windows.Forms.Label 24 340 470 20 'Password'
$txtPass = New-Ctl System.Windows.Forms.TextBox 24 362 470 28 ''; $txtPass.UseSystemPasswordChar = $true

$lblErr = New-Ctl System.Windows.Forms.Label 24 400 470 56 ''; $lblErr.ForeColor = [System.Drawing.Color]::FromArgb(176,0,32)
$btn = New-Ctl System.Windows.Forms.Button 384 480 110 36 'Finish'; $btn.Enabled = $false

$form.Controls.AddRange(@($hdr,$h1,$lblPrefix,$txtTag,$note,$chk,$lblPreview,$h2,$lblDom,$l3,$txtUser,$l4,$txtPass,$lblErr,$btn))
$form.AcceptButton = $btn
$script:allowClose = $false

function Update-State {
    $t = $txtTag.Text
    $nameOk = ($t -match "^[A-Za-z0-9\-]{1,$MaxLen}$") -and -not $t.EndsWith('-')
    $credOk = ($txtUser.Text.Trim().Length -gt 0) -and ($txtPass.Text.Length -gt 0)
    $btn.Enabled = ($nameOk -and $credOk)
    $lblPreview.Text = if ($nameOk) { "Computer name will be: $Prefix$t" } else { '' }
    if ($t -and -not $nameOk) { $lblErr.Text = "Letters, numbers and hyphens only, maximum $MaxLen characters." }
    elseif ($lblErr.Text -like 'Letters*') { $lblErr.Text = '' }
}

if ($script:serial) { $txtTag.Text = $script:serial; $txtTag.ReadOnly = $true; $chk.Checked = $false }
else { $chk.Checked = $true; $chk.Enabled = $false; $txtTag.ReadOnly = $false }   # nothing detected: empty, must type
$chk.Add_CheckedChanged({
    if ($chk.Checked) { $txtTag.ReadOnly = $false; $txtTag.Focus() | Out-Null }
    elseif ($script:serial) { $txtTag.Text = $script:serial; $txtTag.ReadOnly = $true }
})
$txtTag.Add_TextChanged({ Update-State })
$txtUser.Add_TextChanged({ Update-State })
$txtPass.Add_TextChanged({ Update-State })

$btn.Add_Click({
    $lblErr.Text = ''; $btn.Enabled = $false; $btn.Text = 'Checking...'; $form.Refresh()
    $user = $txtUser.Text.Trim(); $valid = $false; $msg = ''
    try {
        $sam = if ($user -match '\\') { $user.Split('\')[-1] } else { $user }
        $ctx = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('Domain', $Domain)
        $valid = $ctx.ValidateCredentials($sam, $txtPass.Text)
        if (-not $valid) { $msg = 'Invalid domain username or password.' }
    } catch {
        $msg = "Cannot contact domain $Domain. Check the network and try again."
        PLog "Credential check error: $($_.Exception.Message)"
    }
    if (-not $valid) { $lblErr.Text = $msg; $btn.Text = 'Finish'; Update-State; return }

    # Machine-scope DPAPI: Launch.ps1 (SYSTEM, same machine) decrypts it. Never stored in clear text.
    $enc = [Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($txtPass.Text), $null, 'LocalMachine')
    $obj = [pscustomobject]@{ Name = "$Prefix$($txtTag.Text)"; AssetTag = $detected; Override = $chk.Checked; User = $user; Pw = [Convert]::ToBase64String($enc) }
    $obj | ConvertTo-Json | Set-Content -Path $ResultFile -Encoding UTF8
    $script:allowClose = $true; $form.Close()
})
$form.Add_FormClosing({ if (-not $script:allowClose) { $_.Cancel = $true } })
$form.Add_Shown({ $form.Activate(); $form.BringToFront(); Update-State })
[void]$form.ShowDialog()
PLog 'Popup closed normally'
