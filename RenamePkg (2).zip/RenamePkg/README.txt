RENAME POPUP - Intune Win32 app

1. Copy ServiceUI.exe (x64) from MDT (C:\Program Files\Microsoft Deployment Toolkit\Templates\Distribution\Tools\x64) into this folder.
2. Package:  IntuneWinAppUtil.exe -c . -s Launch.ps1 -o ..\out
   (Download: https://github.com/microsoft/Microsoft-Win32-Content-Prep-Tool)
3. Intune app settings
   Install:    %SystemRoot%\sysnative\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File Launch.ps1
   Uninstall:  Uninstall.cmd
   Install behaviour: System
   Return codes: 0 success, 3010 soft reboot, 1 failed
   Detection:  custom script, Detection.ps1 (run as 64-bit: Yes, signature check: No)
4. Assign as REQUIRED to the device group/Autopilot group, and add it to the ESP profile "Block device use until these required apps are installed".
5. The popup asks for domain credentials (validated against melb.ad) and the rename uses them (Rename-Computer -DomainCredential), so the AD computer object is renamed with that account. The account needs rights to rename computer objects in the target OU. The password is stored only machine-DPAPI encrypted in result.json, which Launch.ps1 deletes right after reading.
Logs: C:\ProgramData\Rename\Rename.log (also IME logs in C:\ProgramData\Microsoft\IntuneManagementExtension\Logs).
Local test (as admin): psexec -s -i 1 powershell -STA -File Show-DeviceInfo.ps1
