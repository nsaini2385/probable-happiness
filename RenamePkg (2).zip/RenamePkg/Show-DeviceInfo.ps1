param([string]$Prefix = 'WL11-', [string]$Domain = 'melb.ad')
$ErrorActionPreference = 'Stop'
function PLog($m){ try { "$(Get-Date -Format s) [popup] $m" | Add-Content 'C:\ProgramData\Rename\Rename.log' } catch {} }
trap { PLog "ERROR: $($_.Exception.Message) | line $($_.InvocationInfo.ScriptLineNumber)"; exit 1 }
PLog "Popup started. User=$env:USERNAME Session=$([System.Diagnostics.Process]::GetCurrentProcess().SessionId) LanguageMode=$($ExecutionContext.SessionState.LanguageMode)"
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
Add-Type -AssemblyName System.Security
Add-Type -AssemblyName System.DirectoryServices.AccountManagement
$ResultFile = 'C:\ProgramData\Rename\result.json'
$MaxLen = 15 - $Prefix.Length          # NetBIOS computer name limit is 15

# ---- Detect serial number (BIOS first, enclosure as fallback). Empty if not found / placeholder ----
$detected = ''
try { $detected = ((Get-CimInstance Win32_BIOS).SerialNumber | Out-String).Trim() } catch {}
if (-not $detected) { try { $detected = ((Get-CimInstance Win32_SystemEnclosure).SerialNumber | Out-String).Trim() } catch {} }
$junk = 'To Be Filled By O.E.M.','Default string','System Serial Number','None','N/A','Not Specified','Not Applicable','Unknown','0'
if ($junk -contains $detected) { $detected = '' }
$serial = ($detected -replace '[^A-Za-z0-9\-]','').ToUpper().Trim('-')
if ($serial -match '^0+$') { $serial = '' }
if ($serial.Length -gt $MaxLen) { $serial = $serial.Substring($serial.Length - $MaxLen) }
PLog "Detected serial: '$detected' -> prefill '$serial'"

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Width="560" SizeToContent="Height" WindowStartupLocation="CenterScreen"
        WindowStyle="None" ResizeMode="NoResize" AllowsTransparency="True" Background="Transparent"
        Topmost="True" ShowInTaskbar="False" FontFamily="Segoe UI">
  <Border Background="White" CornerRadius="8" BorderBrush="#FF0F4C81" BorderThickness="1" Margin="12">
    <Border.Effect><DropShadowEffect BlurRadius="18" ShadowDepth="2" Opacity="0.35"/></Border.Effect>
    <StackPanel>
      <Border Background="#FF0F4C81" CornerRadius="7,7,0,0" Padding="20,14">
        <TextBlock Text="Device Information" Foreground="White" FontSize="20" FontWeight="SemiBold"/>
      </Border>
      <StackPanel Margin="24,18,24,20">
        <TextBlock Text="Where will this device be used?" FontSize="16" FontWeight="SemiBold" Foreground="#FF0F4C81"/>
        <RadioButton x:Name="rbWs" IsChecked="True" Content="This is a WORKSAFE device" FontSize="14" Margin="0,10,0,0"/>

        <TextBlock Text="Computer Name" FontSize="16" FontWeight="SemiBold" Foreground="#FF0F4C81" Margin="0,18,0,0"/>
        <StackPanel Orientation="Horizontal" Margin="0,8,0,0">
          <TextBlock x:Name="lblPrefix" FontSize="16" VerticalAlignment="Center" Margin="0,0,6,0"/>
          <TextBox x:Name="txtTag" Width="190" FontSize="16" Padding="6,4" CharacterCasing="Upper"/>
        </StackPanel>
        <TextBlock Text="Pre-filled with the device serial number. Tick the box below to change it." TextWrapping="Wrap" Foreground="#FF555555" Margin="0,8,0,0"/>
        <CheckBox x:Name="chkOverride" Content="Override detected serial number" Margin="0,10,0,0"/>
        <TextBlock x:Name="lblPreview" FontSize="13" Foreground="#FF0F4C81" Margin="0,10,0,0"/>

        <TextBlock Text="Domain Credentials" FontSize="16" FontWeight="SemiBold" Foreground="#FF0F4C81" Margin="0,18,0,0"/>
        <TextBlock x:Name="lblDomain" FontSize="13" Foreground="#FF555555" Margin="0,4,0,0"/>
        <TextBlock Text="Username" Margin="0,10,0,0"/>
        <TextBox x:Name="txtUser" FontSize="14" Padding="6,4" Margin="0,2,0,0"/>
        <TextBlock Text="Password" Margin="0,10,0,0"/>
        <PasswordBox x:Name="txtPass" FontSize="14" Padding="6,4" Margin="0,2,0,0"/>

        <TextBlock x:Name="lblErr" Foreground="#FFB00020" Margin="0,10,0,0" TextWrapping="Wrap"/>
        <Button x:Name="btnFinish" Content="Finish" Width="110" Height="34" HorizontalAlignment="Right" Margin="0,14,0,0" IsEnabled="False"/>
      </StackPanel>
    </StackPanel>
  </Border>
</Window>
"@
$win = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$ui = @{}; 'rbWs','lblPrefix','txtTag','chkOverride','lblPreview','lblDomain','txtUser','txtPass','lblErr','btnFinish' | ForEach-Object { $ui[$_] = $win.FindName($_) }
$ui.lblPrefix.Text = $Prefix
$ui.lblDomain.Text = "Domain: $Domain  (account allowed to rename computer objects)"
$ui.txtTag.MaxLength = $MaxLen
$script:allowClose = $false

function Update-State {
    $t = $ui.txtTag.Text
    $nameOk = ($t -match "^[A-Za-z0-9\-]{1,$MaxLen}$") -and -not $t.EndsWith('-')
    $credOk = [bool]($ui.txtUser.Text.Trim()) -and [bool]($ui.txtPass.Password)
    $ui.btnFinish.IsEnabled = ($nameOk -and $credOk)
    $ui.lblPreview.Text = if ($nameOk) { "Computer name will be: $Prefix$t" } else { '' }
    if ($t -and -not $nameOk) { $ui.lblErr.Text = "Letters, numbers and hyphens only, maximum $MaxLen characters." }
    elseif ($ui.lblErr.Text -like 'Letters*') { $ui.lblErr.Text = '' }
}

if ($serial) {
    $ui.txtTag.Text = $serial; $ui.txtTag.IsReadOnly = $true; $ui.chkOverride.IsChecked = $false
} else {
    $ui.chkOverride.IsChecked = $true; $ui.chkOverride.IsEnabled = $false   # nothing detected: empty, must type
}
$ui.chkOverride.Add_Checked({ $ui.txtTag.IsReadOnly = $false; $ui.txtTag.Focus() | Out-Null })
$ui.chkOverride.Add_Unchecked({ $ui.txtTag.Text = $serial; $ui.txtTag.IsReadOnly = $true })
$ui.txtTag.Add_TextChanged({ Update-State })
$ui.txtUser.Add_TextChanged({ Update-State })
$ui.txtPass.Add_PasswordChanged({ Update-State })

$ui.btnFinish.Add_Click({
    $ui.lblErr.Text = ''
    $ui.btnFinish.IsEnabled = $false; $ui.btnFinish.Content = 'Checking...'
    $win.Dispatcher.Invoke([Action]{}, [System.Windows.Threading.DispatcherPriority]::Render)

    $user = $ui.txtUser.Text.Trim()
    $valid = $false; $msg = ''
    try {
        $sam = if ($user -match '\\') { $user.Split('\')[-1] } else { $user }
        $ctx = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('Domain', $Domain)
        $valid = $ctx.ValidateCredentials($sam, $ui.txtPass.Password)
        if (-not $valid) { $msg = 'Invalid domain username or password.' }
    } catch {
        $msg = "Cannot contact domain $Domain. Check the network and try again."
        PLog "Credential check error: $($_.Exception.Message)"
    }
    if (-not $valid) {
        $ui.lblErr.Text = $msg; $ui.btnFinish.Content = 'Finish'; Update-State; return
    }

    # Password is protected with machine-scope DPAPI (Launch.ps1 runs as SYSTEM on the same machine) - never stored in clear text
    $enc = [Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($ui.txtPass.Password), $null, 'LocalMachine')
    $obj = [pscustomobject]@{
        Name = "$Prefix$($ui.txtTag.Text)"; AssetTag = $detected; Override = [bool]$ui.chkOverride.IsChecked
        User = $user; Pw = [Convert]::ToBase64String($enc)
    }
    New-Item -ItemType Directory -Path (Split-Path $ResultFile) -Force | Out-Null
    $obj | ConvertTo-Json | Set-Content -Path $ResultFile -Encoding UTF8
    $script:allowClose = $true; $win.Close()
})
$win.Add_Closing({ if (-not $script:allowClose) { $_.Cancel = $true } })
$win.Add_ContentRendered({ $win.Activate() | Out-Null; Update-State })
$win.ShowDialog() | Out-Null
PLog 'Popup closed normally'
