Run the following: 

Phase 0:
Ensure device has been fully reset / reimaged and is at the region select screen. If resetting - ensure previous Intune object has been deleted. Ensure Autopilot Registration shows the correct group tag (eg AU_Laptop_Pharmacy). 


Phase 1:
1_TimeZone_Set
Script will prompt for which AU / NZ Timezone to apply to device pre Autopilot. Put in place to help with timestamps for troubleshooting logs but should also help with building machines interstate and shipping to user. Select the zone appropriate for the intended end user. 

2_EBOS-TimeGuard_Install_v2
This will set things up for pre-provision. Once all completed (look for errors). Will try and detect if you are imaging 'on network' or externally and adjust accordingly for how it handles time sync processes. 


Phase 2:
Run Pre-provision process. 


Phase 3:
Completed successful image. If this is going to a user - ensure Reseal is completed and device powered back on and able to get to the Login screen ok before handing over.


TROUBLESHOOTING: 

Verification checklist: (For Technician to verify manually)


Logs:
C:\ProgramData\EBOS-TimeGuard\Logs\TimeGuard_v2.txt
For reference - C:\ProgramData\EBOS-TimeGuard\state.json

Other Log File Locations of note: 
C:\ProgramData\Microsoft\IntuneManagementExtension\Logs
- IntuneManagementExtension.log
- AgentExecutor.log
C:\Windows\Debug\Netsetup.log
Output dsregcmd /status (eg > D:\dsregcmd.txt) for review
Event Viewer - Applications and Services Logs - Microsoft - Windows - AAD - Operational. Save Selected Events out to CSV for review for the autopilot time region (should display duration on the error screen but can see timestamps from the Intune Autopilot Deployments Monitoring page). 
