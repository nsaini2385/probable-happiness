powershell.exe "set-executionpolicy bypass"
powershell.exe .\ebos.ps1
pause