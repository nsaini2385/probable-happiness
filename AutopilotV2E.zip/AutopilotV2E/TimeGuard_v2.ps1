﻿<#
  EBOS TimeGuard - Option C build (v2.1C)
  - Keep filename TimeGuard_v2.ps1 for installer compatibility
  - Standard folder: C:\ProgramData\EBOS-TimeGuard
  - Option C behaviour:
      * Off-network/weak signal: set AllSync + peers, resync once, exit (control-like)
      * On-network: strict NTP until ODJ, then AllSync handoff, exit
#>

[CmdletBinding()]
param(
  [ValidateSet('OneShot','Runtime')]
  [string]$Mode = 'Runtime',

  [string]$LogPath = 'C:\ProgramData\EBOS-TimeGuard\Logs\TimeGuard_v2.log',

  [string]$StatePath = 'C:\ProgramData\EBOS-TimeGuard\state.json'
)

$ErrorActionPreference = 'SilentlyContinue'

# -------------------- Constants --------------------
$TGVersion = '2.1C'
$Root      = 'C:\ProgramData\EBOS-TimeGuard'
$LogDir    = Join-Path $Root 'Logs'
$DefaultPeers = @(
  'au.pool.ntp.org,0x8',
  '0.au.pool.ntp.org,0x8',
  '1.au.pool.ntp.org,0x8'
)

# -------------------- Helpers --------------------
function Ensure-Dirs {
  if (-not (Test-Path $Root))   { New-Item -ItemType Directory -Path $Root  -Force | Out-Null }
  if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir -Force | Out-Null }
}

function Write-TGLog([string]$Msg) {
  $ts = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ss')
  Add-Content -LiteralPath $LogPath -Value "[$ts] $Msg" -Encoding ASCII
}

function Load-State {
  $s = $null
  if (Test-Path $StatePath) {
    try { $s = Get-Content -LiteralPath $StatePath -Raw | ConvertFrom-Json } catch { $s = $null }
  }
  if (-not $s) {
    $s = [pscustomobject]@{}
  }

  # Normalize schema (supports legacy StateInit_v2.json and newer)
  foreach ($p in @('Version','Phase','FirstSeenUtc','ODJDetected','ODJDetectedUtc','HandoffCompleted','HandoffMode','Notes')) {
    if (-not ($s.PSObject.Properties.Name -contains $p)) {
      $s | Add-Member -MemberType NoteProperty -Name $p -Value $null
    }
  }

  if (-not $s.FirstSeenUtc) { $s.FirstSeenUtc = (Get-Date).ToUniversalTime().ToString('s') + 'Z' }
  if (-not $s.Version)      { $s.Version = $TGVersion }

  # Legacy mapping: if StateInit wrote Phase=PreODJ, respect it
  if (-not $s.Phase) { $s.Phase = 'INIT' }

  return $s
}

function Save-State($s) {
  # Ensure Version exists and is set (fixes the "property cannot be found" issue)
  if (-not ($s.PSObject.Properties.Name -contains 'Version')) {
    $s | Add-Member -MemberType NoteProperty -Name Version -Value $TGVersion
  } else {
    $s.Version = $TGVersion
  }

  $s | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $StatePath -Encoding UTF8
}

function Test-ODJ {
  # Minimal stable signal (works during Autopilot phases)
  return (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters')
}

function Get-DomainName {
  if ($env:USERDNSDOMAIN) { return $env:USERDNSDOMAIN }
  try {
    $cs = Get-CimInstance Win32_ComputerSystem
    if ($cs.Domain -and $cs.PartOfDomain) { return $cs.Domain }
  } catch {}
  return $null
}

function Test-DomainReachableQuick {
  $d = Get-DomainName
  if (-not $d) { return $false }

  # Use nltest with a short timeout pattern
  $cmd = "nltest /dsgetdc:$d"
  try {
    $p = Start-Process -FilePath "cmd.exe" -ArgumentList "/c $cmd" -NoNewWindow -PassThru -WindowStyle Hidden
    if ($p.WaitForExit(6000)) {
      return ($p.ExitCode -eq 0)
    } else {
      try { $p.Kill() | Out-Null } catch {}
      return $false
    }
  } catch {
    return $false
  }
}

function Test-CorporateNetwork {
    # ---- CONFIG: set these for EBOS ----
    $CorpDomain = "pharmacyservices.local"   # <-- set to your real AD DNS name
    $CorpDnsServers = @(
        "10.13.10.10","10.12.10.10"       # <-- add corp DNS resolver IPs if you have them
    )
    $CorpProfileNames = @(
        # "EBOS","EBOS Corporate","Docklands","EBOS LAN"  # <-- optional allowlist
    )

    $evidence = New-Object System.Collections.Generic.List[string]

    # 1) DC SRV record resolution (best early signal)
    try {
        $srv = "_ldap._tcp.dc._msdcs.$CorpDomain"
        $null = Resolve-DnsName -Name $srv -Type SRV -ErrorAction Stop
        $evidence.Add("DNS_SRV_OK:$srv")
    } catch {}

    # 2) Check DNS server IPs (very reliable if you populate $CorpDnsServers)
    try {
        $dns = (Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction Stop |
                Where-Object {$_.ServerAddresses} |
                Select-Object -ExpandProperty ServerAddresses -Unique)

        if ($CorpDnsServers.Count -gt 0) {
            foreach ($d in $dns) {
                if ($CorpDnsServers -contains $d) {
                    $evidence.Add("DNS_SERVER_MATCH:$d")
                    break
                }
            }
        } else {
            # If you haven't provided corp DNS IPs, still log what we saw
            foreach ($d in $dns) { $evidence.Add("DNS_SERVER_SEEN:$d") }
        }
    } catch {}

    # 3) Network profile name allowlist (supporting evidence)
    try {
        $profiles = Get-NetConnectionProfile -ErrorAction Stop
        foreach ($p in $profiles) {
            if ($p.Name) { $evidence.Add("PROFILE_NAME:$($p.Name)") }
            if ($CorpProfileNames.Count -gt 0 -and $p.Name -and ($CorpProfileNames | Where-Object { $p.Name -like "*$_*" })) {
                $evidence.Add("PROFILE_ALLOWLIST_MATCH:$($p.Name)")
            }
            if ($p.NetworkCategory) { $evidence.Add("CATEGORY:$($p.NetworkCategory)") }
        }
    } catch {}

    # 4) nltest success is a strong confirmation (but failure is not decisive)
    try {
        $d = $CorpDomain
        $p = Start-Process -FilePath "cmd.exe" -ArgumentList "/c nltest /dsgetdc:$d" -NoNewWindow -PassThru -WindowStyle Hidden
        if ($p.WaitForExit(6000) -and $p.ExitCode -eq 0) {
            $evidence.Add("NLTEST_OK")
        } else {
            $evidence.Add("NLTEST_FAIL")
        }
    } catch {}

    # ---- DECISION ----
    # ON-NET if we have any strong corporate evidence
    $onNet = $false
    if ($evidence | Where-Object { $_ -like "DNS_SRV_OK:*" }) { $onNet = $true }
    elseif ($evidence | Where-Object { $_ -like "DNS_SERVER_MATCH:*" }) { $onNet = $true }
    elseif ($evidence | Where-Object { $_ -like "PROFILE_ALLOWLIST_MATCH:*" }) { $onNet = $true }
    elseif ($evidence | Where-Object { $_ -eq "NLTEST_OK" }) { $onNet = $true }

    # Return both result + evidence for logging
    return @{ OnNetwork = $onNet; Evidence = $evidence }
}

function Apply-W32TimeConfig([string]$Type, [string[]]$Peers) {
  $peerString = ($Peers -join ' ')
  Write-TGLog "[W32TIME] Setting Type=$Type; NtpServer=$peerString"

  & w32tm /config /manualpeerlist:"$peerString" /syncfromflags:manual /update | Out-Null
  & w32tm /config /type:$Type /update | Out-Null

  try { Restart-Service w32time -Force -ErrorAction Stop } catch { Write-TGLog "[WARN] Restart-Service w32time failed: $_" }
  try { & w32tm /resync /force | Out-Null } catch { Write-TGLog "[WARN] w32tm /resync failed: $_" }
}

function Snapshot-W32Time {
  try {
    Write-TGLog "[SNAPSHOT] w32tm /query /status"
    (& w32tm /query /status) | ForEach-Object { Write-TGLog "  $_" }
  } catch {}
  try {
    Write-TGLog "[SNAPSHOT] w32tm /query /configuration"
    (& w32tm /query /configuration) | ForEach-Object { Write-TGLog "  $_" }
  } catch {}
}

# -------------------- Main --------------------
Ensure-Dirs
Write-TGLog "==== TimeGuard $TGVersion Start (Mode=$Mode) ===="

$state = Load-State

# If already done, exit cleanly
if ($state.HandoffCompleted -eq $true -or $state.Phase -eq 'HANDOFF_COMPLETED') {
  Write-TGLog "[STATE] Already completed. Exiting."
  Write-TGLog "==== TimeGuard $TGVersion End ===="
  return
}

$net = Test-CorporateNetwork
Write-TGLog ("[NET] OnNetwork={0} Evidence={1}" -f $net.OnNetwork, ($net.Evidence -join ";"))
$onNetwork = [bool]$net.OnNetwork

# OPTION C: Off-network/weak-signal => behave like control
if (-not $onNetwork) {
  $state.HandoffMode      = 'OptionC_Relaxed'
  $state.Phase            = 'RELAXED_CONTROLMODE'
  $state.Notes            = 'Off-network detected; set AllSync and exit (control-like).'
  Write-TGLog "[STATE] RELAXED_CONTROLMODE - applying AllSync and exiting."
  Apply-W32TimeConfig -Type 'AllSync' -Peers $DefaultPeers
  Snapshot-W32Time

  $state.HandoffCompleted = $true
  Save-State $state
  Write-TGLog "==== TimeGuard $TGVersion End ===="
  return
}

# On-network path: strict NTP only until ODJ
if (-not (Test-ODJ)) {
  $state.HandoffMode = 'OptionC_StrictPreODJ'
  $state.Phase       = 'PRE_ODJ'
  Write-TGLog "[STATE] PRE_ODJ - enforcing strict NTP (on-network) until ODJ detected."
  Apply-W32TimeConfig -Type 'NTP' -Peers $DefaultPeers
  Snapshot-W32Time
  Save-State $state

  Write-TGLog "==== TimeGuard $TGVersion End ===="
  return
}

# ODJ detected => handoff immediately (no cloud gate in Option C)
if (Test-ODJ) {
  if (-not $state.ODJDetected) {
    $state.ODJDetected    = $true
    $state.ODJDetectedUtc = (Get-Date).ToUniversalTime().ToString('s') + 'Z'
  }

  $state.HandoffMode = 'OptionC_HandoffOnODJ'
  $state.Phase       = 'HANDOFF_READY'
  Write-TGLog "[STATE] ODJ detected - performing AllSync handoff now."
  Apply-W32TimeConfig -Type 'AllSync' -Peers $DefaultPeers
  Snapshot-W32Time

  $state.HandoffCompleted = $true
  $state.Phase            = 'HANDOFF_COMPLETED'
  Save-State $state

  Write-TGLog "[STATE] HANDOFF_COMPLETED"
}

Write-TGLog "==== TimeGuard $TGVersion End ===="