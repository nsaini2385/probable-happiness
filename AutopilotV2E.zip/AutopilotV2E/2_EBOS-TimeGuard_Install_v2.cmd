@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM =====================================================
REM  EBOS TimeGuard - All-in-One Installer (Option C)
REM  - Install + StateInit + OneShot + Task + Preflight
REM =====================================================

set TGROOT=C:\ProgramData\EBOS-TimeGuard
set TGLOG=%TGROOT%\Logs

set INSTALLLOG=%TGLOG%\install_log.txt
set RUNTIMELOG=%TGLOG%\TimeGuard_v2.log
set PREFLIGHTLOG=%TGLOG%\preflight_log.txt

REM ---------- Prep ----------
if not exist "%TGROOT%" mkdir "%TGROOT%" >nul 2>&1
if not exist "%TGLOG%" mkdir "%TGLOG%" >nul 2>&1

call :Log "==== TimeGuard Option C - All-in-One Install START ===="

REM ---------- STEP 1 ----------
call :Step "1" "Folder structure" "Ensure EBOS-TimeGuard + Logs"
if exist "%TGROOT%" (
  call :Pass "STEP 1 PASS - %TGROOT% exists"
) else (
  call :Fail "STEP 1 FAIL - %TGROOT% missing"
  exit /b 1
)

REM ---------- STEP 2 ----------
call :Step "2" "Copy scripts" "TimeGuard_v2, StateInit, Preflight"
copy /y "%~dp0TimeGuard_v2.ps1" "%TGROOT%\TimeGuard_v2.ps1" >nul 2>&1
copy /y "%~dp0TimeGuard_StateInit_v2.ps1" "%TGROOT%\TimeGuard_StateInit_v2.ps1" >nul 2>&1
copy /y "%~dp0TimeGuard_Preflight_v2.ps1" "%TGROOT%\TimeGuard_Preflight_v2.ps1" >nul 2>&1

if exist "%TGROOT%\TimeGuard_v2.ps1" (
  call :Pass "STEP 2 PASS - Scripts copied"
) else (
  call :Fail "STEP 2 FAIL - Scripts missing"
  exit /b 1
)

REM ---------- STEP 3 ----------
call :Step "3" "Initialise state" "Create state.json"
powershell.exe -NoProfile -ExecutionPolicy Bypass ^
  -File "%TGROOT%\TimeGuard_StateInit_v2.ps1" ^
  -LogPath "%INSTALLLOG%"

if %errorlevel%==0 (
  call :Pass "STEP 3 PASS - State initialised"
) else (
  call :Warn "STEP 3 WARN - StateInit returned %errorlevel%"
)

REM ---------- STEP 4 ----------
call :Step "4" "One-shot execution" "Apply Option C logic immediately"
powershell.exe -NoProfile -ExecutionPolicy Bypass ^
  -File "%TGROOT%\TimeGuard_v2.ps1" ^
  -Mode OneShot ^
  -LogPath "%RUNTIMELOG%"

if %errorlevel%==0 (
  call :Pass "STEP 4 PASS - One-shot completed"
) else (
  call :Warn "STEP 4 WARN - One-shot returned %errorlevel%"
)

REM ---------- STEP 5 ----------
call :Step "5" "Scheduled task" "SYSTEM runtime enforcement"
schtasks /Delete /TN "\EBOS\TimeGuard" /F >nul 2>&1

schtasks /Create /TN "\EBOS\TimeGuard" ^
 /TR "powershell.exe -NoProfile -ExecutionPolicy Bypass -File %TGROOT%\TimeGuard_v2.ps1 -Mode Runtime -LogPath %RUNTIMELOG%" ^
 /SC ONSTART /RU SYSTEM /RL HIGHEST /F >nul 2>&1

schtasks /Query /TN "\EBOS\TimeGuard" >nul 2>&1
if %errorlevel%==0 (
  call :Pass "STEP 5 PASS - Scheduled task created"
) else (
  call :Fail "STEP 5 FAIL - Scheduled task missing"
  exit /b 1
)

REM ---------- STEP 6 ----------
call :Step "6" "Preflight snapshot" "Capture validation output"
powershell.exe -NoProfile -ExecutionPolicy Bypass ^
  -File "%TGROOT%\TimeGuard_Preflight_v2.ps1" ^
  -LogPath "%PREFLIGHTLOG%" -Quiet

if %errorlevel%==0 (
  call :Pass "STEP 6 PASS - Preflight completed"
) else (
  call :Warn "STEP 6 WARN - Preflight returned %errorlevel%"
)

REM ---------- DONE ----------
call :Log "==== TimeGuard Option C - All-in-One Install END ===="
exit /b 0

REM =====================================================
REM  Helpers
REM =====================================================
:Step
call :Log "STEP %~1 - %~2 :: %~3"
exit /b 0

:Pass
call :Log "%~1"
exit /b 0

:Warn
call :Log "%~1"
exit /b 0

:Fail
call :Log "%~1"
exit /b 0

:Log
echo [%date% %time%] %~1>> "%INSTALLLOG%"
echo %~1
exit /b 0