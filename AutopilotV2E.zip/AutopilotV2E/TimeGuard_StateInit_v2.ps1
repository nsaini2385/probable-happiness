﻿param(
  [string]$LogPath = "C:\ProgramData\EBOS-TimeGuard\Logs\install_log.txt"
)

$ErrorActionPreference = "SilentlyContinue"
$root      = "C:\ProgramData\EBOS-TimeGuard"
$logDir    = Join-Path $root "Logs"
$statePath = Join-Path $root "state.json"

if (!(Test-Path $root))   { New-Item -ItemType Directory -Path $root -Force | Out-Null }
if (!(Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }

function Log($m){
  $line = "[{0}] {1}" -f (Get-Date).ToString("s"), $m
  $line | Out-File -FilePath $LogPath -Append -Encoding utf8
}

$boot    = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
$bootUtc = ($boot).ToUniversalTime().ToString("s")+"Z"
$nowUtc  = (Get-Date).ToUniversalTime().ToString("s")+"Z"

# Keep legacy keys + add new ones used by v2.1C
$state = [ordered]@{
  Version            = "2.1C"
  Phase              = "INIT"
  FirstSeenUtc       = $nowUtc
  ODJDetected         = $false
  ODJDetectedUtc      = $null
  HandoffCompleted    = $false
  HandoffMode         = $null
  Notes              = "Initialised by install script"

  # Legacy v2 keys (preserved for compatibility)
  InstallTimeUtc      = $nowUtc
  LastBootUtc         = $bootUtc
  NtpEnforced         = $true
  HandoffEligible     = $false
  ODJDetectedBootUtc  = ""
}

($state | ConvertTo-Json -Depth 6) | Out-File -FilePath $statePath -Encoding utf8
Log "[STATE] Initialised: Version=2.1C Phase=INIT InstallTimeUtc=$nowUtc BootUtc=$bootUtc"
exit 0