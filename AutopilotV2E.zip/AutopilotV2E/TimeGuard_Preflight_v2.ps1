﻿param(
  [string]$LogPath = "C:\ProgramData\EBOS-TimeGuard\Logs\preflight_log.txt",
  [switch]$Quiet
)

$ErrorActionPreference = "SilentlyContinue"

$root = "C:\ProgramData\EBOS-TimeGuard"
$statePath = Join-Path $root "state.json"

function Log($m){
  $line = "[{0}] {1}" -f (Get-Date).ToString("s"), $m
  $line | Out-File -FilePath $LogPath -Append -Encoding utf8
  if (-not $Quiet) { Write-Host $m }
}

Log "==== TimeGuard v2 Preflight ===="

if (!(Test-Path $statePath)) {
  Log "FAIL - state.json not found"
  exit 1
}

$state = Get-Content $statePath -Raw | ConvertFrom-Json
$cs = Get-CimInstance Win32_ComputerSystem
$os = Get-CimInstance Win32_OperatingSystem
$bootUtc = ($os.LastBootUpTime).ToUniversalTime().ToString("s")+"Z"

# Read current W32Time Parameters
$w32 = "HKLM:\SYSTEM\CurrentControlSet\Services\W32Time\Parameters"
$type = (Get-ItemProperty $w32 -Name Type -ErrorAction SilentlyContinue).Type
$ntp  = (Get-ItemProperty $w32 -Name NtpServer -ErrorAction SilentlyContinue).NtpServer

Log ("Phase              : {0}" -f $state.Phase)
Log ("InstallTimeUtc     : {0}" -f $state.InstallTimeUtc)
Log ("LastBootUtc        : {0} (current: {1})" -f $state.LastBootUtc, $bootUtc)
Log ("NtpEnforced        : {0}" -f $state.NtpEnforced)
Log ("HandoffEligible    : {0}" -f $state.HandoffEligible)
Log ("HandoffCompleted   : {0}" -f $state.HandoffCompleted)
Log ("ODJDetected        : {0}" -f $state.ODJDetected)
Log ("ODJDetectedBootUtc : {0}" -f $state.ODJDetectedBootUtc)

Log ("Computer PartOfDomain: {0} Domain: {1}" -f $cs.PartOfDomain, $cs.Domain)
Log ("W32Time Type        : {0}" -f $type)
Log ("W32Time NtpServer   : {0}" -f $ntp)

# Task checks
schtasks /Query /TN "\EBOS\TimeGuard_v2" | Out-String | % { Log $_.TrimEnd() } | Out-Null
schtasks /Query /TN "\EBOS\TimeGuard_v2_Repeat" | Out-String | % { Log $_.TrimEnd() } | Out-Null

Log "==== End Preflight ===="
exit 0