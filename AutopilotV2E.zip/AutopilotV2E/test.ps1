# loop to ensure the right tag is selected
:outer do {
	$type = Read-Host -Prompt 'Enter "1" for AU Laptop "2" for AU Desktop "3" for NZ Laptop "4" for NZ Desktop "5" for Cloud only'
    Switch ($type){
		'1'{
			# write-host "Good 1"
			# $asset = Read-Host -Prompt 'Input the Device Name for Standard image'
			$type1 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Cryomed "4" for Intellipharm "5" for BACK'
			Switch ($type1){
				'1'{
					$grouptag = "AU_Laptop_Pharmacy"
					break outer
				}
				'2'{
					$grouptag = "AU_Laptop_HPS"
					break outer
				}
				'3'{
					$grouptag = "AU_Laptop_Cryomed"
					break outer
				}
				'4'{
					$grouptag = "AU_Laptop_Intellipharm"
					break outer
				}
				'5'{
					# $grouptag = "NZ_Desktop_Intellipharm"
					write-host "should go to 1st menu"
					break
				}
				default{
					write-host "Invalid. Please choose again"
					break
				}
			}
		}
		'2'{
			# write-host "Bad 2"
			# $asset = Read-Host -Prompt 'Input the Device Name for VIP image'
			$type2 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Cryomed "4" for Intellipharm "5" for BACK'
			Switch ($type2){
				'1'{
					$grouptag = "AU_Desktop_Pharmacy"
					break outer
				}
				'2'{
					$grouptag = "AU_Desktop_HPS"
					break outer
				}
				'3'{
					$grouptag = "AU_Desktop_Cryomed"
					break outer
				}
				'4'{
					$grouptag = "AU_Desktop_Intellipharm"
					break outer
				}
				'5'{
					# $grouptag = "NZ_Desktop_Intellipharm"
					break
				}
				default{
					write-host "Invalid. Please choose again"
					break
				}
			}
		}
		'3'{
			# write-host "Good 1"
			# $asset = Read-Host -Prompt 'Input the Device Name for Standard image'
			$type3 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Cryomed "4" for Intellipharm "5" for BACK'
			Switch ($type3){
				'1'{
					$grouptag = "NZ_Laptop_Pharmacy"
					break outer
				}
				'2'{
					$grouptag = "NZ_Laptop_HPS"
					break outer
				}
				'3'{
					$grouptag = "NZ_Laptop_Cryomed"
					break outer
				}
				'4'{
					$grouptag = "NZ_Laptop_Intellipharm"
					break outer
				}
				'5'{
					# $grouptag = "NZ_Desktop_Intellipharm"
					break
				}
				default{
					write-host "Invalid. Please choose again"
					break
				}
			}
		}
		'4'{
			# write-host "Good 1"
			# $asset = Read-Host -Prompt 'Input the Device Name for Standard image'
			$type4 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Cryomed "4" for Intellipharm "5" for BACK'
			Switch ($type4){
				'1'{
					$grouptag = "NZ_Desktop_Pharmacy"
					break outer
				}
				'2'{
					$grouptag = "NZ_Desktop_HPS"
					break outer
				}
				'3'{
					$grouptag = "NZ_Desktop_Cryomed"
					break outer
				}
				'4'{
					$grouptag = "NZ_Desktop_Intellipharm"
					break outer
				}
				'5'{
					# $grouptag = "NZ_Desktop_Intellipharm"
					break
				}
				default{
					write-host "Invalid. Please choose again"
					break
				}
			}
		}
		'5'{
			$grouptag = "AAD"
			break outer
		}
		default{
			write-host "Invalid. Please choose again"
		}
	}
}while ($True)

write-host $grouptag