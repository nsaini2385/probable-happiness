﻿#https://docs.microsoft.com/en-us/windows-hardware/get-started/adk-install
#https://www.tenforums.com/tutorials/96683-create-media-automated-unattended-install-windows-10-a.html#Step2
#https://go.microsoft.com/fwlink/?linkid=2086042

# Get Info to include in upload
$tenant = "e9159d1f-e53a-417a-b788-997860d140b8"
$app = "23fd1967-8042-43fe-aa1d-1988e0eb3e69"
$secret = "aUt8Q~E4ilcGWK5rWDBEmA9xkNQPGT5C6sA5HbEV"

#Install package Provider and Script for uploading HardwareHash
Write-Host "Installing required Scripts"
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Install-Script -Name Get-WindowsAutopilotinfo -Confirm:$False -Force

# loop to ensure the right tag is selected
:outer do {
    $type = Read-Host -Prompt 'Enter "1" for AU Laptop "2" for AU Desktop "3" for NZ Laptop "4" for NZ Desktop "5" for Cloud only'
    Switch ($type){
        '1'{
            $type1 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Ebos MedTech "4" for Intellipharm "5" for Ebos Animal Care "6" to go back to previous menu'
            Switch ($type1){
                '1'{
                    $grouptag = "AU_Laptop_Pharmacy"
                    break outer
                }
                '2'{
                    $grouptag = "AU_Laptop_HPS"
                    break outer
                }
                '3'{
                    $grouptag = "AU_Laptop_EbosMedTech"
                    break outer
                }
                '4'{
                    $grouptag = "AU_Laptop_Intellipharm"
                    break outer
                }
                '5'{
                    $grouptag = "AU_Laptop_EbosAnimalCare"
                    break outer
                }
                '6'{
                    break
                }
                default{
                    write-host "Invalid. Please choose again"
                    break
                }
            }
        }
        '2'{
            $type2 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Ebos MedTech "4" for Intellipharm "5" for Ebos Animal Care "6" to go back to previous menu'
            Switch ($type2){
                '1'{
                    $grouptag = "AU_Desktop_Pharmacy"
                    break outer
                }
                '2'{
                    $grouptag = "AU_Desktop_HPS"
                    break outer
                }
                '3'{
                    $grouptag = "AU_Desktop_EbosMedTech"
                    break outer
                }
                '4'{
                    $grouptag = "AU_Desktop_Intellipharm"
                    break outer
                }
                '5'{
                    $grouptag = "AU_Desktop_EbosAnimalCare"
                    break outer
                }
                '6'{
                    break
                }
                default{
                    write-host "Invalid. Please choose again"
                    break
                }
            }
        }
        '3'{
            $type3 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Ebos MedTech "4" for Intellipharm "5" for Ebos Animal Care "6" to go back to previous menu'
            Switch ($type3){
                '1'{
                    $grouptag = "NZ_Laptop_Pharmacy"
                    break outer
                }
                '2'{
                    $grouptag = "NZ_Laptop_HPS"
                    break outer
                }
                '3'{
                    $grouptag = "NZ_Laptop_EbosMedTech"
                    break outer
                }
                '4'{
                    $grouptag = "NZ_Laptop_Intellipharm"
                    break outer
                }
                '5'{
                    $grouptag = "NZ_Laptop_EbosAnimalCare"
                    break outer
                }
                '6'{
                    break
                }
                default{
                    write-host "Invalid. Please choose again"
                    break
                }
            }
        }
        '4'{
            $type4 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Ebos MedTech "4" for Intellipharm "5" for Ebos Animal Care "6" to go back to previous menu'
            Switch ($type4){
                '1'{
                    $grouptag = "NZ_Desktop_Pharmacy"
                    break outer
                }
                '2'{
                    $grouptag = "NZ_Desktop_HPS"
                    break outer
                }
                '3'{
                    $grouptag = "NZ_Desktop_EbosMedTech"
                    break outer
                }
                '4'{
                    $grouptag = "NZ_Desktop_Intellipharm"
                    break outer
                }
                '5'{
                    $grouptag = "NZ_Desktop_EbosAnimalCare"
                    break outer
                }
                '6'{
                    break
                }
                default{
                    write-host "Invalid. Please choose again"
                    break
                }
            }
        }
        '5'{
            $grouptag = "AAD"
            break outer
        }
        default{
            write-host "Invalid. Please choose again"
        }
    }
}while ($True)

#Upload Hardware Hash 
Write-Host "Uploading Hardware Hash"
.\\Get-WindowsAutopilotinfo.ps1 -Online -GroupTag "$grouptag" -TenantId "$tenant" -AppId "$app" -AppSecret "$secret" -informationaction continue 
#Installing OS Updates and Drivers
Write-Host "Installing OS Updates and Drivers"
.\\UpdateOS.ps1

# shutdown.exe /s /t 10
