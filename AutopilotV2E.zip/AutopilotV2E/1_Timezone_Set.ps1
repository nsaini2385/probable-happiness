﻿# Requires admin to set system timezone
function Require-Admin {
    $currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Write-Host "This script must be run as Administrator." -ForegroundColor Yellow
        Write-Host "Right-click PowerShell and select 'Run as administrator', then re-run this script."
        exit 1
    }
}

# Apply the selected timezone using tzutil
function Set-TimeZoneSafe {
    param(
        [Parameter(Mandatory=$true)]
        [string]$WindowsTzId
    )
    try {
        tzutil.exe /s $WindowsTzId 2>$null
        if ($LASTEXITCODE -ne 0) {
            throw "tzutil exited with code $LASTEXITCODE"
        }
        Write-Host "✅ Timezone set to: $WindowsTzId" -ForegroundColor Green
    }
    catch {
        Write-Host "❌ Failed to set timezone: $($_.Exception.Message)" -ForegroundColor Red
        exit 2
    }
}

# Show current timezone
function Show-CurrentTimeZone {
    try {
        $current = tzutil.exe /g
        Write-Host "Current timezone: $current" -ForegroundColor Cyan
    } catch {
        Write-Host "Current timezone: (unable to query)" -ForegroundColor DarkYellow
    }
}

# Define selectable options (ordered, each on its own line)
# Note: Using Windows Time Zone IDs so DST is applied automatically where applicable.
$TimeZoneOptions = @(
    @{ Number = 1;  Label = "Australia – Sydney/Melbourne (AEST/AEDT)"; Id = "AUS Eastern Standard Time" }     # NSW, VIC
    @{ Number = 2;  Label = "Australia – Brisbane (AEST, no DST)";        Id = "E. Australia Standard Time" }  # QLD
    @{ Number = 3;  Label = "Australia – Adelaide (ACST/ACDT)";           Id = "Cen. Australia Standard Time"} # SA
    @{ Number = 4;  Label = "Australia – Darwin (ACST, no DST)";          Id = "AUS Central Standard Time" }   # NT
    @{ Number = 5;  Label = "Australia – Perth (AWST)";                    Id = "W. Australia Standard Time" }  # WA
    @{ Number = 6;  Label = "Australia – Hobart/Tasmania (AEST/AEDT)";     Id = "Tasmania Standard Time" }      # TAS
    @{ Number = 7; Label = "New Zealand – Auckland/Wellington (NZST/NZDT)"; Id = "New Zealand Standard Time" } # NZ
    #@{ Number = 8;  Label = "Australia – Eucla (ACWST)";                   Id = "Aus Central W. Standard Time"} # WA (Eucla + border towns)
    #@{ Number = 9;  Label = "Australia – Lord Howe (LHST/LHDT)";           Id = "Lord Howe Standard Time" }     # NSW (Lord Howe Island)
    #@{ Number = 10;  Label = "Australia – Norfolk Island (NFT)";            Id = "Norfolk Standard Time" }       # External territory (if needed)
    #@{ Number = 11; Label = "Australia – Christmas Island (CXT)";          Id = "SE Asia Standard Time" }       # Closest Windows mapping typically not used on corp endpoints
    #@{ Number = 12; Label = "Australia – Cocos (Keeling) Islands (CCT)";   Id = "Myanmar Standard Time" }       # Closest mapping; uncommon on corp endpoints
)

Require-Admin
Show-CurrentTimeZone

Write-Host ""
Write-Host "Select your timezone:" -ForegroundColor White
foreach ($opt in $TimeZoneOptions) {
    Write-Host ("{0}. {1}" -f $opt.Number, $opt.Label)
}

# Prompt until valid
$selected = $null
while (-not $selected) {
    $inputVal = Read-Host "Enter the number corresponding to your timezone"
    if ([int]::TryParse($inputVal, [ref]([int]$null))) {
        $match = $TimeZoneOptions | Where-Object { $_.Number -eq [int]$inputVal }
        if ($match) {
            $selected = $match
        } else {
            Write-Host "Invalid selection '$inputVal'. Please enter a number from the list." -ForegroundColor Yellow
        }
    } else {
        Write-Host "Please enter a numeric value." -ForegroundColor Yellow
    }
}

Write-Host ("You selected: {0} → {1}" -f $selected.Label, $selected.Id) -ForegroundColor Cyan
Set-TimeZoneSafe -WindowsTzId $selected.Id