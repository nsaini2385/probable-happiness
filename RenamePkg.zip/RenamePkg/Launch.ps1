# Launch.ps1 - runs as SYSTEM from Intune. Shows popup in the OOBE/ESP session via ServiceUI, then renames.
$ErrorActionPreference = 'Stop'
$Domain   = 'melb.ad'
$Prefix   = 'WL11-'
$WorkDir  = 'C:\ProgramData\Rename'
$Log      = Join-Path $WorkDir 'Rename.log'
$Result   = Join-Path $WorkDir 'result.json'
$RegPath  = 'HKLM:\SOFTWARE\Rename'
New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null
function Write-Log($m){ "$(Get-Date -Format 's') $m" | Add-Content $Log }

# Must be 64-bit (Intune agent is 32-bit)
if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) {
    $ps64 = "$env:windir\sysnative\WindowsPowerShell\v1.0\powershell.exe"
    & $ps64 -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath
    exit $LASTEXITCODE
}

try {
    Write-Log "Start. Current name: $env:COMPUTERNAME"
    $here      = Split-Path -Parent $PSCommandPath
    $serviceUI = Join-Path $here 'ServiceUI.exe'
    $popup     = Join-Path $here 'Show-DeviceInfo.ps1'
    $psExe     = "$env:windir\System32\WindowsPowerShell\v1.0\powershell.exe"
    if (-not (Test-Path $serviceUI)) { throw 'ServiceUI.exe missing from package' }

    Remove-Item $Result -Force -ErrorAction SilentlyContinue

    # Copy to a space-free path: ServiceUI mangles quoted arguments (cause of exit code -1)
    Copy-Item $popup (Join-Path $WorkDir 'Show-DeviceInfo.ps1') -Force
    Copy-Item $serviceUI (Join-Path $WorkDir 'ServiceUI.exe') -Force
    $popup     = Join-Path $WorkDir 'Show-DeviceInfo.ps1'
    $serviceUI = Join-Path $WorkDir 'ServiceUI.exe'

    $candidates = 'explorer','CloudExperienceHostBroker','RuntimeBroker','WWAHost','LogonUI','msoobe'
    $deadline = (Get-Date).AddMinutes(30)
    $fails = 0
    while (-not (Test-Path $Result) -and (Get-Date) -lt $deadline) {
        $target = $null
        foreach ($c in $candidates) {
            $p = Get-Process -Name $c -ErrorAction SilentlyContinue | Where-Object { $_.SessionId -gt 0 } | Select-Object -First 1
            if ($p) { $target = "$c.exe"; Write-Log "Target process $target session $($p.SessionId)"; break }
        }
        if (-not $target) { Write-Log 'No interactive-session process yet, retrying in 10s'; Start-Sleep 10; continue }

        $svcArgs = "-process:$target $psExe -NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File $popup -Prefix $Prefix -Domain $Domain"
        Write-Log "Running: $serviceUI $svcArgs"
        $proc = Start-Process -FilePath $serviceUI -ArgumentList $svcArgs -Wait -PassThru -WindowStyle Hidden
        Write-Log "ServiceUI exit code $($proc.ExitCode)"
        if (-not (Test-Path $Result)) {
            $fails++
            if ($fails -ge 3) { throw "Popup produced no result after $fails attempts (last ServiceUI exit $($proc.ExitCode))" }
            Start-Sleep 5
        }
    }
    if (-not (Test-Path $Result)) { throw 'Popup timed out, no result' }

    $r = Get-Content $Result -Raw | ConvertFrom-Json
    $newName = ($r.Name).Trim().ToUpper()
    if ($newName -notmatch '^[A-Z0-9\-]{1,15}$' -or -not $newName.StartsWith($Prefix)) { throw "Invalid name '$newName'" }
    Write-Log "Requested name $newName (asset tag $($r.AssetTag), override=$($r.Override))"

    if ($env:COMPUTERNAME -ne $newName) {
        Rename-Computer -NewName $newName -Force -ErrorAction Stop
        Write-Log "Renamed to $newName"
    } else { Write-Log 'Name already correct' }

    New-Item -Path $RegPath -Force | Out-Null
    New-ItemProperty -Path $RegPath -Name Done -Value 1 -PropertyType DWord -Force | Out-Null
    New-ItemProperty -Path $RegPath -Name Name -Value $newName -PropertyType String -Force | Out-Null
    exit 3010   # soft reboot, treated as success by Intune
}
catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    exit 1
}
