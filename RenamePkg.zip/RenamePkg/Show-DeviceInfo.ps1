param([string]$Prefix = 'WL11-', [string]$Domain = 'melb.ad')
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
$ResultFile = 'C:\ProgramData\Rename\result.json'

$detected = ''
try { $detected = ((Get-CimInstance Win32_SystemEnclosure).SMBIOSAssetTag | Out-String).Trim() } catch {}
$detectedDigits = ($detected -replace '\D','')
if ($detectedDigits.Length -gt 10) { $detectedDigits = $detectedDigits.Substring($detectedDigits.Length-10) }
if ($detectedDigits -match '^0+$') { $detectedDigits = '' }

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Width="560" SizeToContent="Height" WindowStartupLocation="CenterScreen"
        WindowStyle="None" ResizeMode="NoResize" AllowsTransparency="True" Background="Transparent"
        Topmost="True" ShowInTaskbar="False" FontFamily="Segoe UI">
  <Border Background="White" CornerRadius="8" BorderBrush="#FF0F4C81" BorderThickness="1" Margin="12">
    <Border.Effect><DropShadowEffect BlurRadius="18" ShadowDepth="2" Opacity="0.35"/></Border.Effect>
    <StackPanel>
      <Border Background="#FF0F4C81" CornerRadius="7,7,0,0" Padding="20,14">
        <TextBlock Text="Device Information" Foreground="White" FontSize="20" FontWeight="SemiBold"/>
      </Border>
      <StackPanel Margin="24,18,24,20">
        <TextBlock Text="Where will this device be used?" FontSize="16" FontWeight="SemiBold" Foreground="#FF0F4C81"/>
        <RadioButton x:Name="rbWs" IsChecked="True" Content="This is a WORKSAFE device" FontSize="14" Margin="0,10,0,0"/>

        <TextBlock Text="Computer Name" FontSize="16" FontWeight="SemiBold" Foreground="#FF0F4C81" Margin="0,18,0,0"/>
        <StackPanel Orientation="Horizontal" Margin="0,8,0,0">
          <TextBlock x:Name="lblPrefix" FontSize="16" VerticalAlignment="Center" Margin="0,0,6,0"/>
          <TextBox x:Name="txtTag" Width="190" FontSize="16" Padding="6,4" MaxLength="10"/>
        </StackPanel>
        <TextBlock Text="Enter the asset tag for this device, numbers only. Refer to the sticker on the device." TextWrapping="Wrap" Foreground="#FF555555" Margin="0,8,0,0"/>
        <CheckBox x:Name="chkOverride" Content="Override detected asset tag" Margin="0,10,0,0"/>
        <TextBlock x:Name="lblPreview" FontSize="13" Foreground="#FF0F4C81" Margin="0,12,0,0"/>
        <TextBlock x:Name="lblDomain" FontSize="13" Foreground="#FF555555" Margin="0,2,0,0"/>
        <TextBlock x:Name="lblErr" Foreground="#FFB00020" Margin="0,8,0,0" TextWrapping="Wrap"/>
        <Button x:Name="btnFinish" Content="Finish" Width="110" Height="34" HorizontalAlignment="Right" Margin="0,16,0,0" IsEnabled="False"/>
      </StackPanel>
    </StackPanel>
  </Border>
</Window>
"@
$win = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$ui = @{}; 'rbWs','lblPrefix','txtTag','chkOverride','lblPreview','lblDomain','lblErr','btnFinish' | ForEach-Object { $ui[$_] = $win.FindName($_) }
$ui.lblPrefix.Text = $Prefix
$ui.lblDomain.Text = "Domain: $Domain"
$script:allowClose = $false

function Update-State {
    $t = $ui.txtTag.Text
    $ok = ($t -match '^\d{1,10}$')
    $ui.btnFinish.IsEnabled = $ok
    $ui.lblPreview.Text = if ($ok) { "Computer name will be: $Prefix$t" } else { '' }
    $ui.lblErr.Text = if ($t -and -not $ok) { 'Numbers only, maximum 10 digits.' } else { '' }
}

if ($detectedDigits) {
    $ui.txtTag.Text = $detectedDigits; $ui.txtTag.IsReadOnly = $true; $ui.chkOverride.IsChecked = $false
} else {
    $ui.chkOverride.IsChecked = $true; $ui.chkOverride.IsEnabled = $false   # nothing detected, must type
}
$ui.chkOverride.Add_Checked({ $ui.txtTag.IsReadOnly = $false; $ui.txtTag.Focus() | Out-Null })
$ui.chkOverride.Add_Unchecked({ $ui.txtTag.Text = $detectedDigits; $ui.txtTag.IsReadOnly = $true })
$ui.txtTag.Add_TextChanged({ Update-State })
$ui.btnFinish.Add_Click({
    $obj = [pscustomobject]@{ Name = "$Prefix$($ui.txtTag.Text)"; AssetTag = $detected; Override = [bool]$ui.chkOverride.IsChecked }
    New-Item -ItemType Directory -Path (Split-Path $ResultFile) -Force | Out-Null
    $obj | ConvertTo-Json | Set-Content -Path $ResultFile -Encoding UTF8
    $script:allowClose = $true; $win.Close()
})
$win.Add_Closing({ if (-not $script:allowClose) { $_.Cancel = $true } })
$win.Add_ContentRendered({ $win.Activate() | Out-Null; Update-State })
$win.ShowDialog() | Out-Null
