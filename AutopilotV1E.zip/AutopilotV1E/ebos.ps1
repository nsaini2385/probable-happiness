# Get Info to include in upload
$tenant = "e9159d1f-e53a-417a-b788-997860d140b8"
$app = "23fd1967-8042-43fe-aa1d-1988e0eb3e69"
$secret = "aUt8Q~E4ilcGWK5rWDBEmA9xkNQPGT5C6sA5HbEV"


# Install required modules and script
Write-Host "Installing required scripts..."
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -ErrorAction SilentlyContinue
Install-Script -Name Get-WindowsAutoPilotInfo -Force -Confirm:$false -ErrorAction SilentlyContinue

# GroupTag selection menu
:outer do {
    $type = Read-Host -Prompt 'Enter "1" for AU Laptop "2" for AU Desktop "3" for NZ Laptop "4" for NZ Desktop "5" for Cloud only'
    Switch ($type) {
        '1' {
            $type1 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Ebos MedTech "4" for Intellipharm "5" for Ebos Animal Care "6" to go back'
            Switch ($type1) {
                '1' { $grouptag = "AU_Laptop_Pharmacy"; break outer }
                '2' { $grouptag = "AU_Laptop_HPS"; break outer }
                '3' { $grouptag = "AU_Laptop_EbosMedTech"; break outer }
                '4' { $grouptag = "AU_Laptop_Intellipharm"; break outer }
                '5' { $grouptag = "AU_Laptop_EbosAnimalCare"; break outer }
                '6' { break }
                default { Write-Host "Invalid selection. Try again." }
            }
        }
        '2' {
            $type2 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Ebos MedTech "4" for Intellipharm "5" for Ebos Animal Care "6" to go back'
            Switch ($type2) {
                '1' { $grouptag = "AU_Desktop_Pharmacy"; break outer }
                '2' { $grouptag = "AU_Desktop_HPS"; break outer }
                '3' { $grouptag = "AU_Desktop_EbosMedTech"; break outer }
                '4' { $grouptag = "AU_Desktop_Intellipharm"; break outer }
                '5' { $grouptag = "AU_Desktop_EbosAnimalCare"; break outer }
                '6' { break }
                default { Write-Host "Invalid selection. Try again." }
            }
        }
        '3' {
            $type3 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Ebos MedTech "4" for Intellipharm "5" for Ebos Animal Care "6" to go back'
            Switch ($type3) {
                '1' { $grouptag = "NZ_Laptop_Pharmacy"; break outer }
                '2' { $grouptag = "NZ_Laptop_HPS"; break outer }
                '3' { $grouptag = "NZ_Laptop_EbosMedTech"; break outer }
                '4' { $grouptag = "NZ_Laptop_Intellipharm"; break outer }
                '5' { $grouptag = "NZ_Laptop_EbosAnimalCare"; break outer }
                '6' { break }
                default { Write-Host "Invalid selection. Try again." }
            }
        }
        '4' {
            $type4 = Read-Host -Prompt 'Enter "1" for Pharmacy "2" for HPS "3" for Ebos MedTech "4" for Intellipharm "5" for Ebos Animal Care "6" to go back'
            Switch ($type4) {
                '1' { $grouptag = "NZ_Desktop_Pharmacy"; break outer }
                '2' { $grouptag = "NZ_Desktop_HPS"; break outer }
                '3' { $grouptag = "NZ_Desktop_EbosMedTech"; break outer }
                '4' { $grouptag = "NZ_Desktop_Intellipharm"; break outer }
                '5' { $grouptag = "NZ_Desktop_EbosAnimalCare"; break outer }
                '6' { break }
                default { Write-Host "Invalid selection. Try again." }
            }
        }
        '5' {
            $grouptag = "AAD"
            Write-Host "`nGroup Tag Set: $grouptag"
            break outer
        }
        default {
            Write-Host "`nInvalid selection. Try again."
        }
    }
} while ($true)

# Gather serial number and hardware hash
Write-Host "Collecting serial number and hardware hash..."
$serial = (Get-CimInstance Win32_BIOS).SerialNumber
$hash = (Get-CimInstance -Namespace root\cimv2\mdm\dmmap -Class MDM_DevDetail_Ext01).DeviceHardwareData

# Validate before proceeding
if ([string]::IsNullOrWhiteSpace($serial) -or [string]::IsNullOrWhiteSpace($hash)) {
    Write-Error "❌ Failed to retrieve serial number or hardware hash. Cannot continue."
    exit 1
}

Write-Host "Serial Number: $serial"
Write-Host "Hash Length: $($hash.Length)"

# Upload using the Autopilot script
Write-Host "`nUploading device to Autopilot with Group Tag: $grouptag"
$uploadResult = .\Get-WindowsAutoPilotInfo.ps1 -Online -GroupTag "$grouptag" -TenantId "$tenant" -AppId "$app" -AppSecret "$secret" -InformationAction Continue

# Optional verification message
if ($uploadResult) {
    Write-Host "✅ Upload triggered. Please verify the device appears in Intune Autopilot portal."
} else {
    Write-Warning "⚠️ Upload script finished, but could not confirm success. Please check Intune portal manually."
}

# Run OS update and driver update
Write-Host "`nInstalling OS Updates and Drivers"
.\UpdateOS.ps1

# Optional shutdown
# shutdown.exe /s /t 10