'Micro Focus Content Manager 9.3.2.0430 - PRODUCTION Environment - WSDoM User Settings



On Error Resume Next
Dim fso 'As New Scripting.FileSystemObject
Set fso = CreateObject("Scripting.FileSystemObject")



Dim WshShell
Set WshShell = CreateObject("WScript.Shell")



If fso.FileExists("\\wpwtws0204\Install-CM93-UserSettings\CM93-WSDoM-User-Settings-PROD-43-x86-x64.vbs") = True Then
WshShell.Run "\\wpwtws0204\Install-CM93-UserSettings\CM93-WSDoM-User-Settings-PROD-43-x86-x64.vbs"
Else
'//file does not exist
End If