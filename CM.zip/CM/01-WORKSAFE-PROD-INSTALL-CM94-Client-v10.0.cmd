@ ECHO OFF
TITLE INSTALL PROD Environment Micro Focus Content Manager 9.3.2.0430 Patch 2 Hotfix 4 for Office 64 and 32 bit Version 10.0
REM Version 10.0
REM - Initial Worksafe client deployment package developed for Micro Focus Content Manager 9.3.2.0430 Patch 2 Hotfix 4

REM DYNAMICALLY DETECT THE ROOTPATH FOR INSTALL PACKAGE
    SET ROOTPATH=%~dp0
REM DOES STRING HAVE A TRAINING SLASH? IF SO, REMOVE IT
    IF %ROOTPATH:~-1%==\ SET ROOTPATH=%ROOTPATH:~0,-1%

REM CREATE AND SET LOGPATH DIRECTORY
IF EXIST "\\WPWTWS0204\Install-CM93-Logs\%COMPUTERNAME%\INSTALL" GOTO SETUNINSTALLLOGPATH
	MKDIR "\\WPWTWS0204\Install-CM93-Logs\%COMPUTERNAME%\INSTALL"
	:SETUNINSTALLLOGPATH
	IF EXIST "\\WPWTWS0204\Install-CM93-Logs\%COMPUTERNAME%\UNINSTALL" GOTO SETLOGPATH
	MKDIR "\\WPWTWS0204\Install-CM93-Logs\%COMPUTERNAME%\UNINSTALL"
	:SETLOGPATH	
	SET LOGPATH=\\WPWTWS0204\Install-CM93-Logs\%COMPUTERNAME%

REM UNINSTALL KAPISH ADD-ONS 
    ECHO 01. UNINSTALL Kapish Easy Link
REM UNINSTALL Kapish Easy Link 3.40.3520 x64
	MsiExec.exe /X{2F5DEBF0-3F3E-42C7-BDC8-EC3FDD63DDAB} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\01-UNINSTALL-Kapish-Easy-Link-x64-3.40.3520.log"
REM UNINSTALL Kapish Easy Link 3.41.3556 x64
	MsiExec.exe /X{D5EA7DF7-F34E-42DF-B6C4-74A830D4EF35} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\01-UNINSTALL-Kapish-Easy-Link-x64-3.41.3556.log"
REM UNINSTALL Kapish Easy Link 3.40.3520 x86
	MsiExec.exe /X{4218FF6A-1793-4513-8CD2-DF25288C5B61} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\01-UNINSTALL-Kapish-Easy-Link-x86-3.40.3520.log"
REM UNINSTALL Kapish Easy Link 3.41.3556 x86
	MsiExec.exe /X{C6C78ACE-496D-445F-93D5-E5799AA94948} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\01-UNINSTALL-Kapish-Easy-Link-x86-3.41.3556.log"

	ECHO 02. UNINSTALL Kapish Folder Wizard
REM UNINSTALL Kapish Folder Wizard 3.52.1910 x64
	MsiExec.exe /X{7E28F642-69A1-4582-908B-B84F0A841DB9} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\02-UNINSTALL-Kapish-Folder-Wizard-x64-3.52.1910.log"
REM UNINSTALL Kapish Folder Wizard 3.52.1910 x86
	MsiExec.exe /X{2753C6B7-570E-4211-8F13-9C6249E16620} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\02-UNINSTALL-Kapish-Folder-Wizard-x86-3.52.1910.log"
	
	ECHO 03. UNINSTALL Kapish PDF Wizard
REM UNINSTALL Kapish PDF Wizard 2.01.1110 x64
	MsiExec.exe /X{E42BCA13-9B7D-45D8-9066-ED034A5D5526} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\03-UNINSTALL-Kapish-PDF-Wizard-x64-2.01.1110.log"
REM UNINSTALL Kapish PDF Wizard 2.01.1110 x86
	MsiExec.exe /X{2C2D4712-1818-4EE1-A5D1-F1C23C9EA394} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\03-UNINSTALL-Kapish-PDF-Wizard-x86-2.01.1110.log"

	ECHO 04. UNINSTALL Kapish Record Remover
REM UNINSTALL Kapish Record Remover 1.60.1400 x64
	MsiExec.exe /X{E4240372-B832-4154-AB41-182AD829BAF3} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\04-UNINSTALL-Kapish-Record-Remover-x64-1.60.1400.log"
REM UNINSTALL Kapish Record Remover 1.60.1400 x64
	MsiExec.exe /X{5AF2757F-507D-4C20-A2C8-88A028E9A6DB} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\04-UNINSTALL-Kapish-Record-Remover-x86-1.60.1400.log"

	ECHO 05. UNINSTALL Kapish Workflow Wizard
REM UNINSTALL Kapish Workflow Wizard 1.04.1066 x64
	MsiExec.exe /X{C4E79744-DD36-4E6E-8FC3-18F95F1A748B} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\05-UNINSTALL-Kapish-Workflow-Wizard-x64-1.04.1066.log"
REM UNINSTALL Kapish Workflow Wizard 1.04.1066 x86 
	MsiExec.exe /X{D1997875-DE4C-4B77-B340-D3FAFD0310E2} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\05-UNINSTALL-Kapish-Workflow-Wizard-x86-1.04.1066.log"

	ECHO 06. UNINSTALL Kapish Excel Add-In
REM UNINSTALL Kapish Excel Add-In 4.20.1434 x64 and x86
	MsiExec.exe /X{981398A2-0561-4AB5-99D7-B79785345FAD} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\06-UNINSTALL-Kapish-Excel-AddIn-4.20.1434.log"
	REG DELETE "HKLM\Software\Kapish\Excel Add-In" /V DefaultTabName /F /REG:32

	ECHO 07. UNINSTALL Kapish Word Add-In
REM UNINSTALL Kapish Word Add-In 4.20.1434 x64 and x86
	MsiExec.exe /X{6449CADC-497A-47B2-A82A-64590F06586D} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\07-UNINSTALL-Kapish-Word-AddIn-4.20.1434.log"
	REG DELETE "HKLM\Software\Kapish\Word Add-In" /V DefaultTabName /F /REG:32
	
	ECHO 08. UNINSTALL Kapish Explorer 
REM UNINSTALL Kapish Explorer 5.10.5024 x64
	MsiExec.exe /X{D27FC147-2274-4602-8D1C-806C6D18E106} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\08-UNINSTALL-Kapish-Explorer-x64-5.10.5024.log"
REM UNINSTALL Kapish Explorer 5.11.5026 x64
	MsiExec.exe /X{3D4414A4-BD4D-4B53-AA99-909E786F6E34} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\08-UNINSTALL-Kapish-Explorer-x64-5.11.5026.log"
REM UNINSTALL Kapish Explorer 5.10.5024 x86
	MsiExec.exe /X{AB9BF394-2717-41C2-ADAA-847FB2BE2AD8} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\08-UNINSTALL-Kapish-Explorer-x86-5.10.5024.log"
REM UNINSTALL Kapish Explorer 5.11.5026 x86
	MsiExec.exe /X{68588BB0-F37B-4A88-BEB6-3D395B322F75} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\08-UNINSTALL-Kapish-Explorer-x86-5.11.5026.log"
	REG DELETE "HKLM\Software\Kapish\TRIM Explorer" /V MaxLengthFilepath /F /REG:64
	REG DELETE "HKLM\Software\Kapish\TRIM Explorer" /V MaxLengthFilepath /F /REG:32
	START EXPLORER.EXE
		
REM UNINSTALL HPE RECORDS MANAGER AND MICRO FOCUS CONTENT MANAGER
    ECHO 09. UNINSTALL Micro Focus Content Manager
REM UNINSTALL Micro Focus Content Manager 9.3.2.0430 x64
	MsiExec.exe /X{4E6086CA-B627-4AFA-A41C-8F86363832C7} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\09-UNINSTALL-Micro-Focus-Content-Manager-x64-9.3.2.0430.log"
REM UNINSTALL Micro Focus Content Manager 9.3.2.0430 x86
	MsiExec.exe /X{CEA78427-2FFF-4C38-B6F0-A108724C7421} /quiet /norestart /l*vx "%LOGPATH%\UNINSTALL\09-UNINSTALL-Micro-Focus-Content-Manager-x86-9.3.2.0430.log"

REM DELETE UNWANTED MICRO FOCUS CM FILES, FOLDERS AND REGISTRY KEYS
	DEL "%PUBLIC%\Desktop\Kapish Explorer.lnk" /Q /F
	DEL "%PUBLIC%\Desktop\WSDoM Desktop.lnk" /Q /F
	DEL "%PUBLIC%\Desktop\WSDoM Explorer.lnk" /Q /F
	RD "%PROGRAMFILES%\Kapish" /S /Q
	RD "%PROGRAMFILES(x86)%\Kapish" /S /Q
	RD "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Kapish" /S /Q
	RD "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Content Manager" /S /Q
	RD "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\WSDoM" /S /Q
	RD "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}" /S /Q
	RD /S /Q "%PROGRAMFILES%\Micro Focus\Content Manager"
	RD /S /Q "%PROGRAMFILES(x86)%\Micro Focus\Content Manager"
	RD /S /Q "C:\Micro Focus Content Manager\"
	REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Kapish" /F /REG:32
	REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Kapish" /F /REG:64
	REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Micro Focus\Content Manager" /F /REG:32
    REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Micro Focus\Content Manager" /F /REG:64
	REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "CM93-WSDoM-User-Settings-PROD-43" /F /REG:32
	REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "CM93-WSDoM-User-Settings-PROD-43" /F /REG:64
	REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "CM93-WSDoM-User-Settings-PROD-43-x64Office" /F /REG:32
	REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "CM93-WSDoM-User-Settings-PROD-43-x64Office" /F /REG:64
	REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "CM93-WSDoM-User-Settings-PROD-43-x86Office" /F /REG:32
	REG DELETE "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "CM93-WSDoM-User-Settings-PROD-43-x86Office" /F /REG:64

:INSTALL64BITWSDOM
REM INSTALL MICRO FOCUS CONTENT MANAGER     
    ECHO 10. INSTALL Micro Focus Content Manager 9.3.2.0430 Patch 2 Hotfix 4 x64
REM INSTALL Micro Focus Content Manager Client 9.3.0.0178 Base x64  
	MsiExec.exe /I "%ROOTPATH%\SourceX64\MicroFocus\CM_x64_9300178.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\10-INSTALL-Micro-Focus-Content-Manager-x64-9.30.0178.log" INSTALLDIR="%PROGRAMFILES%\Micro Focus\Content Manager\" ADDLOCAL="HPTRIM,Client" ALLUSERS="1" AUTHMECH="0" AUTOGG="1" DEFAULTDB="43" DEFAULTDBNAME="Corporate Records Production" EXCEL_ON="1" OUTLOOK_ON="1" POWERPOINT_ON="1" PRIMARYURL="WPWTWS0203.melb.ad" PROJECT_ON="1" SECONDARYURL="WPWTWS0204.melb.ad" STARTMENU_NAME="Content Manager" TRIM_DSK="0" TRIMREF="TRIM" TRIMUserSetup_On="0" WORD_ON="1"
REM INSTALL Micro Focus Content Manager Client 9.3.2.0418 Patch 2 x64
	MsiExec.exe /UPDATE "%ROOTPATH%\SourceX64\MicroFocus\CM_x64_9320418.msp" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\10-INSTALL-Micro-Focus-Content-Manager-x64-9.32.0418.log"
REM INSTALL Micro Focus Content Manager Client 9.3.2.0430 Hotfix 4 for Patch 2 x64
	MsiExec.exe /UPDATE "%ROOTPATH%\SourceX64\MicroFocus\CM_x64_9320430.msp" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\10-INSTALL-Micro-Focus-Content-Manager-x64-9.32.0430.log" 
REM MANUALLY REGISTER TRIMSDK.DLL x64
    REGSVR32 /S "%PROGRAMFILES%\Micro Focus\Content Manager\trimsdk.dll"
REM SET TR5's to open in Micro Focus Content Manager	
	REG ADD "HKEY_CLASSES_ROOT\TRIM5.Record.Reference\Shell\open\Command" /V "" /T "REG_SZ" /D "\"%PROGRAMFILES%\Micro Focus\Content Manager\Trim.exe\" \"%%1\"" /F
REM COPY CUSTOMISED USER DICTIONARY FILE
	IF EXIST "%ROOTPATH%\SourceX86\MicroFocus\UIgnore.tlx" COPY "%ROOTPATH%\SourceX86\MicroFocus\UIgnore.tlx" "C:\Micro Focus Content Manager\Lex\UIgnore.tlx" /Y
	
REM INSTALL KAPISH ADD-ONS
    ECHO 11. INSTALL Kapish Kapish Easy Link
REM INSTALL Kapish Easy Link 3.41.3556 x64
	MsiExec.exe /I "%ROOTPATH%\SourceX64\Kapish\Kapish Easy Link-x64-3.41.3556.msi" DISABLEADVTSHORTCUTS=1 /quiet /norestart /l*vx "%LOGPATH%\INSTALL\11-INSTALL-Kapish-Easy-Link-x64.log"

	ECHO 12. INSTALL Kapish Folder Wizard 
REM INSTALL Kapish Folder Wizard 3.52.1910 x64
	MsiExec.exe /I "%ROOTPATH%\SourceX64\Kapish\Kapish Folder Wizard-x64-3.52.1910.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\11-INSTALL-Kapish-Folder-Wizard-x64.log"

	ECHO 13. INSTALL Kapish PDF Wizard 
REM INSTALL Kapish PDF Wizard 2.01.1110 x64
	MsiExec.exe /I "%ROOTPATH%\SourceX64\Kapish\Kapish PDF Wizard-x64-2.01.1110.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\13-INSTALL-Kapish-PDF-Wizard-x64.log"

	ECHO 14. INSTALL Kapish Record Remover
REM INSTALL Kapish Record Remover 1.60.1400 x64
	MsiExec.exe /I "%ROOTPATH%\SourceX64\Kapish\Kapish Record Remover-x64-1.60.1400.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\14-INSTALL-Kapish-Record-Remover-x64.log"

	ECHO 15. INSTALL Kapish Workflow Wizard 
REM INSTALL Kapish Workflow Wizard 1.04.1066 x64
	MsiExec.exe /I "%ROOTPATH%\SourceX64\Kapish\Kapish Workflow Wizard-x64-1.04.1066.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\15-INSTALL-Kapish-Workflow-Wizard-x64.log"

	ECHO 16. INSTALL Kapish Excel Add-In 
REM INSTALL Kapish Excel Add-In 4.20.1434 
	MsiExec.exe /I "%ROOTPATH%\SourceX86\Kapish\Kapish Excel Add-In v4.20.1434.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\16-INSTALL-Kapish-Excel-AddIn.log"
REM RENAME RIBBON TAB IN MS EXCEL
	REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\Kapish\Excel Add-In" /V DefaultTabName /T REG_SZ /D "WSDoM Templates" /F /REG:32
	REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Kapish\Excel Add-In" /V DefaultTabName /T  "REG_SZ" /D "WSDoM Templates" /F 
	
	ECHO 17. INSTALL Kapish Word Add-In
REM INSTALL Kapish Word Add-In 4.20.1434 
	MsiExec.exe /I "%ROOTPATH%\SourceX86\Kapish\Kapish Word Add-In v4.20.1434.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\17-INSTALL-Kapish-Word-AddIn.log"
	REM RENAME RIBBON TAB IN MS WORD
	REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\Kapish\Word Add-In" /V DefaultTabName /T REG_SZ /D "WSDoM Templates" /F /REG:32
	REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Kapish\Word Add-In" /V DefaultTabName /T "REG_SZ" /D "WSDoM Templates" /F 

	ECHO 18. INSTALL Kapish Explorer 
REM INSTALL Kapish Kapish Explorer 5.11.5026
	MsiExec.exe /I "%ROOTPATH%\SourceX64\Kapish\Kapish_Explorer-x64-5.11.5026.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\18-INSTALL-Kapish-Explorer-x64.log"
	REM SET MAX LENGTH FOR DISPLAYING FILE NAMES IN WINDOWS EXPLORER
	REG ADD "HKLM\Software\Kapish\TRIM Explorer" /V "MaxLengthFilepath" /T "REG_DWORD" /D "200" /F /REG:64

REM REBRAND KAPISH EXPLORER TO WSDoM EXPLORER
	COPY "%ROOTPATH%\WSDoM\WSDoM Explorer.ico" "%PROGRAMFILES%\Kapish\Explorer\WSDoM Explorer.ico" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Explorer.ico" "%PROGRAMFILES%\Kapish\Explorer\Icons\explorer-48x48.ico" /Y
	DEL "%SYSTEMROOT%\Installer\{3D4414A4-BD4D-4B53-AA99-909E786F6E34}\MSIIcon" /Q /F
	DEL "%SYSTEMROOT%\Installer\{3D4414A4-BD4D-4B53-AA99-909E786F6E34}\MainShortcutIcon.dll" /Q /F
	COPY "%ROOTPATH%\WSDoM\WSDoM Explorer.ico" "%SYSTEMROOT%\Installer\{3D4414A4-BD4D-4B53-AA99-909E786F6E34}\MSIIcon" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Explorer.ico" "%SYSTEMROOT%\Installer\{3D4414A4-BD4D-4B53-AA99-909E786F6E34}\MainShortcutIcon.dll" /Y
	REG ADD "HKEY_CLASSES_ROOT\CLSID\{6EC97137-BE18-44B9-BB5B-92240A8D3481}" /V "" /D "WSDoM Explorer" /T "REG_SZ" /F /REG:64
	REG ADD "HKEY_CLASSES_ROOT\CLSID\{6EC97137-BE18-44B9-BB5B-92240A8D3481}" /V "InfoTip" /D "Browse WSDoM within Windows Explorer" /T "REG_SZ" /F /REG:64
	REG ADD "HKEY_CLASSES_ROOT\CLSID\{6EC97137-BE18-44B9-BB5B-92240A8D3481}\DefaultIcon" /V "" /D "%PROGRAMFILES%\Kapish\Explorer\WSDoM Explorer.ico" /T "REG_SZ" /F /REG:64

REM CHECK MICROSOFT OFFICE BIT LEVEL (32BIT OR 64BIT)
	IF EXIST "C:\Program Files\Microsoft Office\Office15\WINWORD.EXE" GOTO UserSettings
	IF EXIST "C:\Program Files\Microsoft Office\Office16\WINWORD.EXE" GOTO UserSettings
	IF EXIST "C:\Program Files\Microsoft Office\root\Office15\WINWORD.EXE" GOTO UserSettings
	IF EXIST "C:\Program Files\Microsoft Office\root\Office16\WINWORD.EXE" GOTO UserSettings
	IF EXIST "C:\Program Files (x86)\Microsoft Office\Office15\WINWORD.EXE" GOTO INSTALL32BITWSDOM
	IF EXIST "C:\Program Files (x86)\Microsoft Office\Office16\WINWORD.EXE" GOTO INSTALL32BITWSDOM
	IF EXIST "C:\Program Files (x86)\Microsoft Office\root\Office15\WINWORD.EXE" GOTO INSTALL32BITWSDOM
	IF EXIST "C:\Program Files (x86)\Microsoft Office\root\Office16\WINWORD.EXE" GOTO INSTALL32BITWSDOM
		
:INSTALL32BITWSDOM
REM INSTALL MICRO FOCUS CONTENT MANAGER     
    ECHO 19. INSTALL Micro Focus Content Manager 9.3.2.0430 Patch 2 Hotfix 4 x86
REM INSTALL Micro Focus Content Manager Client 9.3.0.0178 Base x86
	MsiExec.exe /I "%ROOTPATH%\SourceX86\MicroFocus\CM_x86_9300178.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\19-INSTALL-Micro-Focus-Content-Manager-x86-9.30.0178.log" INSTALLDIR="%PROGRAMFILES(x86)%\Micro Focus\Content Manager\" ADDLOCAL="HPTRIM,Client" ALLUSERS="1" AUTHMECH="0" AUTOGG="1" DEFAULTDB="43" DEFAULTDBNAME="Corporate Records Production" EXCEL_ON="1" OUTLOOK_ON="1" POWERPOINT_ON="1" PRIMARYURL="WPWTWS0203.melb.ad" PROJECT_ON="1" SECONDARYURL="WPWTWS0204.melb.ad" STARTMENU_NAME="Content Manager" TRIM_DSK="0" TRIMREF="TRIM" TRIMUserSetup_On="0" WORD_ON="1"
REM INSTALL Micro Focus Content Manager Client 9.3.2.0418 Patch 2 x86
	MsiExec.exe /UPDATE "%ROOTPATH%\SourceX86\MicroFocus\CM_x86_9320418.msp" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\19-INSTALL-Micro-Focus-Content-Manager-x86-9.32.0418.log"
REM INSTALL Micro Focus Content Manager Client 9.3.2.0430 Hotfix 4 for Patch 2 x86
	MsiExec.exe /UPDATE "%ROOTPATH%\SourceX86\MicroFocus\CM_x86_9320430.msp" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\19-INSTALL-Micro-Focus-Content-Manager-x86-9.32.0430.log" 
REM MANUALLY REGISTER TRIMSDK.DLL x86
    REGSVR32 /S "%PROGRAMFILES(x86)%\Micro Focus\Content Manager\trimsdk.dll"
REM SET TR5's to open in Micro Focus Content Manager	
	REG ADD "HKEY_CLASSES_ROOT\TRIM5.Record.Reference\Shell\open\Command" /V "" /T "REG_SZ" /D "\"%PROGRAMFILES(x86)%\Micro Focus\Content Manager\Trim.exe\" \"%%1\"" /F
	
REM INSTALL KAPISH ADD-ONS
    ECHO 20. INSTALL Kapish Kapish Easy Link
REM INSTALL Kapish Easy Link 3.41.3556 x86
	MsiExec.exe /I "%ROOTPATH%\SourceX86\Kapish\Kapish Easy Link-x86-3.41.3556.msi" DISABLEADVTSHORTCUTS=1 /quiet /norestart /l*vx "%LOGPATH%\INSTALL\20-INSTALL-Kapish-Easy-Link-x86.log"

	ECHO 21. INSTALL Kapish Folder Wizard 
REM INSTALL Kapish Folder Wizard 3.52.1910 x86
	MsiExec.exe /I "%ROOTPATH%\SourceX86\Kapish\Kapish Folder Wizard-x86-3.52.1910.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\21-INSTALL-Kapish-Folder-Wizard-x86.log"

	ECHO 22. INSTALL Kapish PDF Wizard 
REM INSTALL Kapish PDF Wizard 2.01.1110 x86
	MsiExec.exe /I "%ROOTPATH%\SourceX86\Kapish\Kapish PDF Wizard-x86-2.01.1110.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\22-INSTALL-Kapish-PDF-Wizard-x86.log"

	ECHO 23. INSTALL Kapish Record Remover
REM INSTALL Kapish Record Remover 1.60.1400 x86
	MsiExec.exe /I "%ROOTPATH%\SourceX86\Kapish\Kapish Record Remover-x86-1.60.1400.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\23-INSTALL-Kapish-Record-Remover-x86.log"

	ECHO 24. INSTALL Kapish Workflow Wizard 
REM INSTALL Kapish Workflow Wizard 1.04.1066 x86
	MsiExec.exe /I "%ROOTPATH%\SourceX86\Kapish\Kapish Workflow Wizard-x86-1.04.1066.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\24-INSTALL-Kapish-Workflow-Wizard-x86.log"

	ECHO 25. INSTALL Kapish Explorer 
REM INSTALL Kapish Explorer 4.20.1434 
	MsiExec.exe /I "%ROOTPATH%\SourceX86\Kapish\Kapish_Explorer-x86-5.11.5026.msi" /quiet /norestart /l*vx "%LOGPATH%\INSTALL\25-INSTALL-Kapish-Explorer-x86.log"
	REM SET MAX LENGTH FOR DISPLAYING FILE NAMES IN WINDOWS EXPLORER
	REG ADD "HKLM\Software\Kapish\TRIM Explorer" /V "MaxLengthFilepath" /T "REG_DWORD" /D "200" /F /REG:64

REM REBRAND KAPISH EXPLORER TO WSDoM EXPLORER
	COPY "%ROOTPATH%\WSDoM\WSDoM Explorer.ico" "%PROGRAMFILES(x86)%\Kapish\Explorer\WSDoM Explorer.ico" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Explorer.ico" "%PROGRAMFILES(x86)%\Kapish\Explorer\Icons\explorer-48x48.ico" /Y
	DEL "%SYSTEMROOT%\Installer\{68588BB0-F37B-4A88-BEB6-3D395B322F75}\MSIIcon" /Q /F
	DEL "%SYSTEMROOT%\Installer\{68588BB0-F37B-4A88-BEB6-3D395B322F75}\MainShortcutIcon.dll" /Q /F
	COPY "%ROOTPATH%\WSDoM\WSDoM Explorer.ico" "%SYSTEMROOT%\Installer\{68588BB0-F37B-4A88-BEB6-3D395B322F75}\MSIIcon" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Explorer.ico" "%SYSTEMROOT%\Installer\{68588BB0-F37B-4A88-BEB6-3D395B322F75}\MainShortcutIcon.dll" /Y
	REG ADD "HKEY_CLASSES_ROOT\CLSID\{6EC97137-BE18-44B9-BB5B-92240A8D3481}" /V "" /D "WSDoM Explorer" /T "REG_SZ" /F /REG:32
	REG ADD "HKEY_CLASSES_ROOT\CLSID\{6EC97137-BE18-44B9-BB5B-92240A8D3481}" /V "InfoTip" /D "Browse WSDoM within Windows Explorer" /T "REG_SZ" /F /REG:32
	REG ADD "HKEY_CLASSES_ROOT\CLSID\{6EC97137-BE18-44B9-BB5B-92240A8D3481}\DefaultIcon" /V "" /D "%PROGRAMFILES%\Kapish\Explorer\WSDoM Explorer.ico" /T "REG_SZ" /F /REG:32
		
GOTO UserSettings

:UserSettings
REM REBRAND Micro Focus Content Manager TO WSDoM Desktop
REM DELETE EXISTING ICON FILES x64
	DEL "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\trim.exe" /Q /F
	DEL "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\TRIMDataPortConfig.exe" /Q /F
	DEL "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\TRIMDesktop.exe" /Q /F
	DEL "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\TRIMEnterpriseStudio.exe" /Q /F
	DEL "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\TRIMQueue.exe" /Q /F
REM DELETE EXISTING ICON FILES x86
	DEL "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\trim.exe" /Q /F
	DEL "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\TRIMDataPortConfig.exe" /Q /F
	DEL "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\TRIMDesktop.exe" /Q /F
	DEL "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\TRIMEnterpriseStudio.exe" /Q /F
	DEL "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\TRIMQueue.exe" /Q /F
REM COPY NEW ICON FILES x64
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\trim.exe" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\TRIMDataPortConfig.exe" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\TRIMDesktop.exe" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\TRIMEnterpriseStudio.exe" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{CEA78427-2FFF-4C38-B6F0-A108724C7421}\TRIMQueue.exe" /Y
REM COPY NEW ICON FILES x86
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\trim.exe" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\TRIMDataPortConfig.exe" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\TRIMDesktop.exe" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\TRIMEnterpriseStudio.exe" /Y
	COPY "%ROOTPATH%\WSDoM\WSDoM Desktop.ico" "%SYSTEMROOT%\Installer\{4E6086CA-B627-4AFA-A41C-8F86363832C7}\TRIMQueue.exe" /Y
REM COPY WSDoM DESKTOP (CONTENT MANAGER) START MENU SHORTCUT TO PUBLIC (ALL USERS) DESKTOP
	COPY "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Content Manager\Content Manager.lnk" "%PUBLIC%\Desktop\WSDoM Desktop.lnk" /Y
REM RENAME KAPISH EXPLORER DESKTOP SHORTCUT TO WSDoM EXPLORER
	REN "%PUBLIC%\Desktop\Kapish Explorer.lnk" "WSDoM Explorer.lnk"
REM CREATE NEW WSDoM START MENU FOLDER AND COPY / RENAME SHORTCUTS FOR CONTENT MANAGER AND KAPISH PRODUCTS
	MKDIR "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\WSDoM"
	COPY "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Content Manager\Content Manager.lnk" "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\WSDoM\WSDoM Desktop.lnk" /Y
	COPY "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Content Manager\Content Manager User Guide.lnk" "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\WSDoM\WSDoM Desktop User Guide.lnk" /Y
	COPY "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Kapish\Easy Link.lnk" "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\WSDoM\WSDoM Easy Link.lnk" /Y
	COPY "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Kapish\Explorer.lnk" "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\WSDoM\WSDoM Explorer.lnk" /Y
REM DELETE DEFAULT CONTENT MANAGER AND KAPISH START MENU FOLDERS
	RD "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Content Manager" /S /Q
	RD "%ALLUSERSPROFILE%\Microsoft\Windows\Start Menu\Programs\Kapish" /S /Q

REM INSTALL WSDoM USER SETTINGS PACKAGE VIA WINDOWS RUN REGISTRY KEY
	REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "CM93-WSDoM-User-Settings-PROD-43-x86-X64" /T "REG_SZ" /D "wscript.exe \"\\wpwtws0204\Install-CM93-UserSettings\CM93-WSDoM-User-Settings-PROD-43-X86-X64.vbs\"" /F

REM INSTALL WSDoM USER SETTINGS PACKAGE VIA WINDOWS RUN REGISTRY KEY
	IF EXIST "C:\Program Files\Kapish\User Settings" GOTO USERCONFIGFILE
	MKDIR "C:\Program Files\Kapish\User Settings"
	:USERCONFIGFILE
	COPY "%ROOTPATH%\WSDoM\CM93-WSDoM-User-Settings-PROD-43-x86-x64.vbs" "C:\Program Files\Kapish\User Settings\CM93-WSDoM-User-Settings-PROD-43-x86-x64.vbs" /Y
	REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /V "CM93-WSDoM-User-Settings-PROD-43-x86-x64" /T "REG_SZ" /D "wscript.exe \"C:\Program Files\Kapish\User Settings\CM93-WSDoM-User-Settings-PROD-43-x86-x64.vbs"" /F /REG:64

																																							
REM WRITE TO THE REGISTRY TO SAY THIS VERSION OF THE CMD HAS RAN 
	REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\Micro Focus\Content Manager" /V CM93-WSDoM-Client-INSTALL-Version /T REG_SZ /D "10.0" /F /REG:32
	REG ADD "HKEY_LOCAL_MACHINE\SOFTWARE\Micro Focus\Content Manager" /V CM93-WSDoM-Client-INSTALL-Version /T REG_SZ /D "10.0" /F /REG:64

REM CLEAR WINDOWS 10 ICON CACHE
	%SYSTEMROOT%\SYSTEM32\ie4uinit.exe -SHOW
	
EXIT
